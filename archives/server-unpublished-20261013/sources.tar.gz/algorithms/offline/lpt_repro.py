"""LPT on HCMR: original versus episode-terminal rewards, paired seed zero.

See docs/lpt_reproduction.md for the official recipe and audited repairs.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import signal
import sys
import time

import h5py
import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import lpt_compat as compat

PROJECT = Path(__file__).resolve().parents[2]
DATA = '/labmount/users/202615385/.d4rl/datasets/halfcheetah_medium_replay-v2.hdf5'
COMMIT = 'c4e77cb464c6360733a9ce76d8870f076c76d0aa'


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def array_sha(a):
    return hashlib.sha256(np.asarray(a).tobytes()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(path)


def read(path):
    return json.loads(Path(path).read_text())


def append(path, value):
    with open(path, 'a') as f:
        f.write(json.dumps(value, allow_nan=False) + '\n')
        f.flush()


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def rng_state():
    return dict(python=random.getstate(), numpy=np.random.get_state(), torch=torch.get_rng_state(),
                cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None)


def restore_rng(state):
    random.setstate(state['python'])
    np.random.set_state(state['numpy'])
    torch.set_rng_state(state['torch'].cpu())
    if state['cuda'] is not None:
        torch.cuda.set_rng_state_all([v.cpu() for v in state['cuda']])


def model_sha(model):
    h = hashlib.sha256()
    for name, value in model.state_dict().items():
        h.update(name.encode())
        h.update(value.detach().cpu().numpy().tobytes())
    return h.hexdigest()


def delayed_rewards(rewards):
    delayed = np.zeros_like(rewards, dtype=np.float64)
    delayed[:, -1] = np.asarray(rewards, dtype=np.float64).sum(1)
    return delayed


def returns_to_go(rewards):
    return np.flip(np.cumsum(np.flip(rewards, axis=1), axis=1), axis=1).copy()


def prepare(root):
    if (root / 'protocol.json').exists():
        raise FileExistsError('A frozen campaign already exists')
    root.mkdir(parents=True, exist_ok=True)
    upstream = PROJECT / 'third_party/Latent-Plan-Transformer'
    with h5py.File(DATA, 'r') as f:
        obs = f['observations'][:].astype(np.float64)
        actions = f['actions'][:].astype(np.float32)
        rewards = f['rewards'][:].astype(np.float64).reshape(-1)
        terminals, timeouts = f['terminals'][:].astype(bool), f['timeouts'][:].astype(bool)
    ends = np.flatnonzero(terminals | timeouts) + 1
    lengths = np.diff(np.r_[0, ends])
    assert len(lengths) == 202 and np.all(lengths == 1000) and ends[-1] == len(obs)
    assert not terminals.any()
    # HF Dataset returns Python floats in the released collator; float64 stats
    # reproduce that calculation before the final float32 tensor conversion.
    mean, std = obs.mean(0), obs.std(0) + 1e-6
    states = ((obs - mean) / std).astype(np.float32).reshape(202, 1000, 17)
    rewards = rewards.reshape(202, 1000)
    delayed = delayed_rewards(rewards)
    dense_total = rewards.sum(1).astype(np.float32) / np.float32(1000)
    delayed_total = delayed.sum(1).astype(np.float32) / np.float32(1000)
    np.testing.assert_array_equal(dense_total, delayed_total)
    np.testing.assert_array_equal(delayed[:, :-1], 0)
    np.savez(root / 'dataset.npz', states=states, actions=actions.reshape(202, 1000, 6),
             dense_totals=dense_total, delayed_totals=delayed_total,
             dense_rtg=(returns_to_go(rewards) / 1000).astype(np.float32),
             delayed_rtg=(returns_to_go(delayed) / 1000).astype(np.float32),
             mean=mean, std=std)
    np.savez(root / 'reward_audit.npz', original=rewards, delayed=delayed, lengths=lengths)
    files = ['model/lpt.py', 'model/unet1d.py', 'model/utils_train.py',
             'model/utils_eval.py', 'scripts/config.py', 'scripts/train.py', 'scripts/constants.py', 'README.md']
    for name in files:
        dest = root / 'source/upstream' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(upstream / name, dest)
    for name in ['lpt_repro.py', 'lpt_compat.py']:
        shutil.copy2(Path(__file__).parent / name, root / 'source' / name)
    hashes = {str(x.relative_to(root)): sha(x) for x in (root / 'source').rglob('*') if x.is_file()}
    p = dict(method='LPT', recipe='official-HalfCheetah-with-audited-correctness-portability-fixes',
             upstream_commit=COMMIT, env_name='halfcheetah-medium-replay-v2', eval_env='HalfCheetah-v3',
             arms=['dense', 'delayed'], seed=0, trajectories=202, max_len=1000, window_size=32,
             hidden_size=128, n_layer=3, n_head=1, n_latent=4, langevin_step_size=.3,
             train_langevin_steps=3, eval_langevin_steps=20, target_return=6000, scale=1000.,
             reward_weight=.25, omega_cg=1, gamma=1., learning_rate=1e-4, weight_decay=1e-4,
             grad_clip=.25, warmup_ratio=.1, epochs=2000, nominal_batch_size=500,
             effective_batch_size=202, microbatch_size=4, total_updates=2000,
             attention_backend='portable-blocked-local-attention', eval_updates=[500, 1000, 1500, 2000],
             eval_episodes=10, final_episodes=50, eval_seed_start=271828, final_seed_start=161803,
             eval_model_seed_start=8675309, log_every=10, save_every=50,
             data_path=DATA, data_sha256=sha(DATA), dataset_sha256=sha(root / 'dataset.npz'), source_hashes=hashes,
             wandb_entity='2820402607-shandong-university', wandb_project='CORL-DDR',
             wandb_group='LPT-HCMR-dense-vs-delayed-seed0-20261002',
             repairs=['Local causal attention operator replaces unavailable FlashAttention; upstream softmax_scale=1 and inclusive left window=32 retained',
                      'PMC buffer, best trajectory index, optimizer and all RNG states checkpointed',
                      'Best latent index maps batch position to dataset trajectory ID',
                      'Deterministic last-occurrence PMC updates after complete logical batch',
                      'Inference uses aligned executed-action history and dropout disabled after latent inference',
                      'Evaluation uses training normalization and preserves training RNG'],
             limitations=['One training seed; base LPT only, not the separate LPT-EI extension',
                          'Released code uses 3 training Langevin steps, paper text says 2 with persistent chains',
                          'Local attention fallback is mathematically matched, not bitwise the FlashAttention GPU kernel',
                          'Microbatching changes floating point reduction and random draw ordering versus an unchunked official run',
                          'Dense and terminal-delayed rewards produce the same consumed labels, so these are equivalent-input controls, not independent evidence'])
    write(root / 'protocol.json', p)
    write(root / 'data_audit.json', dict(trajectories=202, lengths=lengths.tolist(),
          returns_identical=True, labels_sha256=array_sha(dense_total),
          raw_return_quantiles=np.quantile(rewards.sum(1), [0, .5, .9, 1]).tolist(),
          dense_rtg_differs_from_delayed=bool(np.any(returns_to_go(rewards) != returns_to_go(delayed))),
          states_sha256=array_sha(states), actions_sha256=array_sha(actions),
          nominal_batch_size=500, actual_official_single_device_batch_size=202,
          updates_per_epoch=math.ceil(202 / 500), total_updates=2000))
    print('Prepared LPT: 202 full trajectories; reward totals identical; 2000 completed updates per arm', flush=True)


def verify(root, p):
    assert sha(root / 'dataset.npz') == p['dataset_sha256']
    for path, expected in p['source_hashes'].items():
        assert sha(root / path) == expected, path


def load_data(root):
    with np.load(root / 'dataset.npz') as z:
        return {k: z[k] for k in z.files}


def evaluate(model, data, p, directory, completed, smoke_steps=None, count_override=None):
    saved, was_training = rng_state(), model.training
    weights_before = model_sha(model)
    latent_before = compat.latent_state(model)
    device = next(model.parameters()).device
    started, episodes = time.monotonic(), []
    env = None
    try:
        import gym
        import d4rl
        from d4rl.infos import REF_MIN_SCORE, REF_MAX_SCORE
        env = gym.make(p['eval_env'])
        count = count_override or (p['final_episodes'] if completed == p['total_updates'] else p['eval_episodes'])
        if smoke_steps is not None:
            count = 1
        first_seed = p['final_seed_start'] if completed == p['total_updates'] else p['eval_seed_start']
        mean = torch.as_tensor(data['mean'], dtype=torch.float32, device=device)
        std = torch.as_tensor(data['std'], dtype=torch.float32, device=device)
        for i in range(count):
            seed = first_seed + i
            seed_all(p['eval_model_seed_start'] + i)
            env.seed(seed)
            env.action_space.seed(seed)
            state = env.reset()
            target = torch.tensor([[p['target_return'] / p['scale']]], dtype=torch.float32, device=device)
            # infer_z_given_y computes gradients w.r.t. z and switches to train()
            # at exit in upstream; explicitly restore eval() before action generation.
            z, _ = model.infer_z_given_y(target, omega_cg=p['omega_cg'])
            model.eval()
            states = torch.as_tensor(state, dtype=torch.float32, device=device).reshape(1, 1, -1)
            actions = torch.zeros(1, 1, 6, device=device)
            total, digest, finished = 0., hashlib.sha256(), False
            for t in range(smoke_steps or p['max_len']):
                _, predicted, _ = model.generate(z=z, states=(states - mean) / std, actions=actions,
                                                timesteps=torch.tensor([t], device=device))
                action = predicted[:, -1, :]
                if not torch.isfinite(action).all():
                    raise FloatingPointError('Nonfinite evaluation action')
                # Fill the current placeholder with the executed action; next
                # state gets a fresh placeholder. No one-step shift of history.
                actions[:, -1] = action
                action_np = action[0].cpu().numpy()
                next_state, reward, finished, _ = env.step(action_np)
                total += reward
                digest.update(np.asarray(next_state).tobytes())
                digest.update(action_np.tobytes())
                if finished:
                    break
                next_tensor = torch.as_tensor(next_state, dtype=torch.float32, device=device).reshape(1, 1, -1)
                states = torch.cat([states, next_tensor], dim=1)
                actions = torch.cat([actions, torch.zeros(1, 1, 6, device=device)], dim=1)
            if smoke_steps is None:
                assert finished and t + 1 == 1000
            score = 100 * (total - REF_MIN_SCORE[p['env_name']]) / (REF_MAX_SCORE[p['env_name']] - REF_MIN_SCORE[p['env_name']])
            episodes.append(dict(episode_seed=seed, model_seed=p['eval_model_seed_start'] + i,
                                 raw_return=float(total), normalized_score=float(score), length=t + 1,
                                 rollout_sha256=digest.hexdigest()))
            print(f'EVAL step={completed} episode={i+1}/{count} return={total:.3f} score={score:.4f}', flush=True)
        result = dict(completed_updates=completed, episodes=episodes,
                      mean_score=float(np.mean([x['normalized_score'] for x in episodes])),
                      std_score=float(np.std([x['normalized_score'] for x in episodes])),
                      target_return=p['target_return'], elapsed_seconds=time.monotonic() - started,
                      smoke=smoke_steps is not None)
        assert model_sha(model) == weights_before
        after = compat.latent_state(model)
        assert torch.equal(after['buffer'], latent_before['buffer'])
        assert after['best_index'] == latent_before['best_index'] and after['y_max'] == latent_before['y_max']
        write(directory / f'eval_{completed:06d}.json', result)
        return result
    finally:
        if env is not None:
            env.close()
        model.train(was_training)
        restore_rng(saved)


def checkpoint(path, model, optimizer, scheduler, sampler, completed, elapsed, chain, p):
    tmp = path.with_suffix('.tmp')
    torch.save(dict(model=model.state_dict(), latent=compat.latent_state(model), optimizer=optimizer.state_dict(),
                    scheduler=scheduler.state_dict(), sampler=sampler.get_state(), rng=rng_state(),
                    completed_updates=completed, elapsed_seconds=elapsed, sample_stream_sha256=chain, protocol=p), tmp)
    tmp.replace(path)


def smoke(root, device):
    p = read(root / 'protocol.json')
    verify(root, p)
    data = load_data(root)
    out = root / 'cpu_smoke'
    out.mkdir(exist_ok=True)
    seed_all(p['seed'])
    model = compat.make_model(p, root / 'source/upstream', device)
    optimizer = compat.optimizer_for(model, p['learning_rate'])
    initial, latent, random_state = copy.deepcopy(model.state_dict()), compat.latent_state(model), rng_state()
    # Two full 1000-step trajectories per physical microbatch; duplicate index
    # exercises the transaction semantics used by the replacement sampler.
    ids = np.array([1, 17, 1, 201])
    results = []
    first_grads = None
    for arm in ['dense', 'delayed']:
        model.load_state_dict(initial)
        compat.restore_latents(model, latent)
        restore_rng(random_state)
        optimizer.zero_grad()
        start = time.monotonic()
        loss = compat.logical_backward(model, data, ids, arm, 2, device)
        grads = {n: x.grad.detach().clone() for n, x in model.named_parameters() if x.grad is not None}
        if first_grads is None:
            first_grads = grads
            first_latent = compat.latent_state(model)
        else:
            assert grads.keys() == first_grads.keys()
            for name in grads:
                torch.testing.assert_close(grads[name], first_grads[name], rtol=0, atol=0)
            torch.testing.assert_close(compat.latent_state(model)['buffer'], first_latent['buffer'], rtol=0, atol=0)
        results.append(dict(arm=arm, loss=loss, elapsed_seconds=time.monotonic() - start))
        print('SMOKE', results[-1], flush=True)
    assert results[0]['loss'] == results[1]['loss']
    torch.nn.utils.clip_grad_norm_(model.parameters(), p['grad_clip'])
    optimizer.step()
    before = rng_state()
    first = evaluate(model, data, p, out, 0, smoke_steps=3)
    second = evaluate(model, data, p, out, 1, smoke_steps=3)
    assert first['episodes'] == second['episodes']
    assert torch.equal(before['torch'], torch.get_rng_state())
    # Verify official HalfCheetah-v3 and our historical D4RL environment have
    # matching seeded transitions, so score comparisons use the same dynamics.
    import gym
    environments = [gym.make(name) for name in [p['eval_env'], p['env_name']]]
    try:
        observations = []
        for env in environments:
            env.seed(525252)
            observations.append(env.reset())
        np.testing.assert_allclose(*observations, atol=1e-12, rtol=0)
        for _ in range(3):
            values = [env.step(np.full(6, .1)) for env in environments]
            np.testing.assert_allclose(values[0][0], values[1][0], atol=1e-12, rtol=0)
            np.testing.assert_allclose(values[0][1], values[1][1], atol=1e-12, rtol=0)
    finally:
        for env in environments:
            env.close()
    write(out / 'audit.json', dict(passed=True, full_model=True, full_trajectory_length=1000,
          dense_delayed_loss_equal=True, dense_delayed_gradients_equal=True, dense_delayed_pmc_equal=True,
          seeded_rollout_repeat_exact=True, eval_weights_pmc_rng_preserved=True,
          official_eval_env_matches_historical_d4rl=True, measurements=results))


def train(root, arm, device):
    import fcntl
    p = read(root / 'protocol.json')
    verify(root, p)
    out = root / arm
    out.mkdir(exist_ok=True)
    lock = open(out / 'lock', 'w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    seed_all(p['seed'])
    model = compat.make_model(p, root / 'source/upstream', device)
    init_hash = model_sha(model)
    init_latent = array_sha(compat.latent_state(model)['buffer'].numpy())
    optimizer = compat.optimizer_for(model, p['learning_rate'])
    from transformers.optimization import get_linear_schedule_with_warmup
    scheduler = get_linear_schedule_with_warmup(optimizer, math.ceil(p['warmup_ratio'] * p['total_updates']), p['total_updates'])
    sampler = np.random.RandomState(p['seed'])
    completed, previous, chain = 0, 0., '0' * 64
    data = load_data(root)
    latest = out / 'latest.pt'
    if latest.exists():
        value = torch.load(latest, map_location='cpu')
        assert value['protocol'] == p
        model.load_state_dict(value['model'])
        compat.restore_latents(model, value['latent'])
        optimizer.load_state_dict(value['optimizer'])
        scheduler.load_state_dict(value['scheduler'])
        sampler.set_state(value['sampler'])
        completed, previous, chain = value['completed_updates'], value['elapsed_seconds'], value['sample_stream_sha256']
        restore_rng(value['rng'])
        del value
    else:
        write(out / 'initialization.json', dict(model_sha256=init_hash, latent_sha256=init_latent,
              parameters=sum(x.numel() for x in model.parameters()), torch_version=torch.__version__,
              gpu=torch.cuda.get_device_name() if device.startswith('cuda') else 'cpu'))
    stop = []
    signal.signal(signal.SIGUSR1, lambda *_: stop.append('walltime_warning'))
    signal.signal(signal.SIGTERM, lambda *_: stop.append('terminated'))
    start = time.monotonic()

    def elapsed():
        return previous + time.monotonic() - start

    def save():
        checkpoint(latest, model, optimizer, scheduler, sampler, completed, elapsed(), chain, p)

    def eval_due():
        if completed in p['eval_updates'] and not (out / f'eval_{completed:06d}.json').exists():
            result = evaluate(model, data, p, out, completed)
            append(out / 'evaluations.jsonl', result)

    write(out / 'status.json', dict(status='running', completed_updates=completed, job_id=os.environ.get('SLURM_JOB_ID')))
    eval_due()
    while completed < p['total_updates'] and not stop:
        # Official Trainer sees 202 dataset rows with nominal batch 500 and
        # drop_last=False, then the collator resamples len(features)=202 IDs.
        ids = sampler.choice(np.arange(p['trajectories']), size=p['effective_batch_size'], replace=True,
                             p=np.full(p['trajectories'], 1 / p['trajectories']))
        chain = hashlib.sha256(bytes.fromhex(chain) + ids.tobytes()).hexdigest()
        optimizer.zero_grad()
        before_update = time.monotonic()
        loss = compat.logical_backward(model, data, ids, arm, p['microbatch_size'], device)
        norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), p['grad_clip']))
        if not math.isfinite(norm):
            raise FloatingPointError('Nonfinite LPT gradient norm')
        optimizer.step()
        scheduler.step()
        completed += 1
        append(out / 'sample_indices.jsonl', dict(completed_updates=completed, trajectory_ids=ids.tolist()))
        if completed <= 3 or completed % p['log_every'] == 0:
            row = dict(completed_updates=completed, loss=loss, gradient_norm=norm,
                       learning_rate=scheduler.get_last_lr()[0], elapsed_seconds=elapsed(),
                       update_seconds=time.monotonic() - before_update,
                       sample_stream_sha256=chain,
                       cuda_peak_mib=torch.cuda.max_memory_allocated() / 2**20 if device.startswith('cuda') else None)
            append(out / 'metrics.jsonl', row)
            write(out / 'status.json', dict(status='running', completed_updates=completed,
                       elapsed_seconds=elapsed(), job_id=os.environ.get('SLURM_JOB_ID')))
            print(json.dumps(row), flush=True)
        if completed % p['save_every'] == 0:
            save()
        if completed in p['eval_updates']:
            # Include PMC in every evaluation checkpoint, not just nn weights.
            shutil.copy2(latest, out / f'step{completed:06d}.pt')
            eval_due()
    save()
    assert sha(p['data_path']) == p['data_sha256']
    finished = completed == p['total_updates']
    write(out / 'status.json', dict(status='completed' if finished else 'interrupted', completed_updates=completed,
          elapsed_seconds=elapsed(), sample_stream_sha256=chain, model_sha256=model_sha(model),
          latent_sha256=array_sha(compat.latent_state(model)['buffer'].numpy()), original_dataset_unchanged=True,
          job_id=os.environ.get('SLURM_JOB_ID'), stop_reason=stop))
    if not finished:
        raise SystemExit(75)


def summarize(root):
    p = read(root / 'protocol.json')
    result = dict(method=p['method'], arms={})
    for arm in p['arms']:
        out = root / arm
        result['arms'][arm] = dict(status=read(out / 'status.json') if (out / 'status.json').exists() else {'status': 'pending'},
                                  evaluations=[read(path) for path in sorted(out.glob('eval_*.json'))])
    inits = [root / arm / 'initialization.json' for arm in p['arms']]
    if all(path.exists() for path in inits):
        result['paired_initial_weights'] = len({read(path)['model_sha256'] for path in inits}) == 1
        result['paired_initial_latents'] = len({read(path)['latent_sha256'] for path in inits}) == 1
        assert result['paired_initial_weights'] and result['paired_initial_latents']
    write(root / 'summary.json', result)
    lines = ['# LPT 原始奖励 / 整局延迟奖励复现', '',
             'HalfCheetah-medium-replay-v2，202 条完整轨迹，seed 0。官方 LPT 基础方法，不包含 LPT-EI。', '',
             '两组用于检验奖励时序不变性：模型只使用总回报，实际消费的训练标签相同。不能视为独立训练种子。', '',
             '官方 2000 epochs，nominal batch 500；本数据只有 202 条轨迹，实际为每次 202 条、总计 2000 次更新。', '',
             '完整 1000 步轨迹参与训练；注意力窗口参数 32，4 个 128 维潜变量，目标回报 6000。', '',
             '| 设置 | 已完成更新 | 状态 | 最近 normalized score |', '|---|---:|---|---:|']
    for arm, value in result['arms'].items():
        last = value['evaluations'][-1]['mean_score'] if value['evaluations'] else '尚无结果'
        lines.append(f"| {arm} | {value['status'].get('completed_updates', 0)} | {value['status']['status']} | {last} |")
    lines += ['', '论文 LPT 参考为 39.64±0.83（5 个训练 seeds，标准差）；LPT-EI 的 40.66±0.12 不属于本轮对标方法。',
              '本轮使用官方模型并修复潜变量索引/持久化、评测动作历史和 dropout，使用经验证的局部注意力替代内核。',
              '配置、修复、数据和源码哈希均保存在本地；单种子不能证明复现了论文的统计结果。']
    (root / 'report_zh.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(result, indent=2, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['prepare', 'smoke', 'train', 'summarize'])
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--arm', choices=['dense', 'delayed'])
    parser.add_argument('--device', default='cuda:0')
    args = parser.parse_args()
    torch.set_num_threads(2)
    root = args.root.resolve()
    if args.mode == 'prepare':
        prepare(root)
    elif args.mode == 'smoke':
        smoke(root, args.device)
    elif args.mode == 'train':
        if not args.arm:
            parser.error('--arm is required')
        train(root, args.arm, args.device)
    else:
        summarize(root)


if __name__ == '__main__':
    main()
