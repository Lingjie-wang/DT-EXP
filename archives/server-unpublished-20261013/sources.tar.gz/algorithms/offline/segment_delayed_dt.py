"""Seed-0 DT with the return of each sampled context as its constant condition.

Uses original dense rewards to construct segment labels. This is richer feedback
than episode-terminal-only DT, not a method using the same reward information.
The original DT backbone, sampler, padded MSE and historical results are reused.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import time

import h5py
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

import threshold_dt as common

PROJECT = Path('/labmount/users/202615385/code/DT-EXP')
BASELINE = PROJECT / 'results/threshold-dt-seed0-3090-20261001/pilot/seed0/dt'
DATA = Path('/labmount/users/202615385/.d4rl/datasets/halfcheetah_medium_replay-v2.hdf5')
WINDOW = [30000, 35000, 40000, 45000, 50000]
SOURCES = [
    'algorithms/offline/segment_delayed_dt.py', 'algorithms/offline/threshold_dt.py',
    'algorithms/offline/dt.py', 'scripts/dt_experiments/run_segment_delayed_dt.sbatch',
    'scripts/dt_experiments/sync_segment_delayed_dt.py',
    'tests/test_segment_delayed_dt.py', 'docs/segment_delayed_dt.md',
]


def segment_returns(rewards, horizon=20):
    """One episode only: exact valid suffix sum for every start, including tails."""
    rewards = np.asarray(rewards, np.float32)
    if rewards.ndim != 1 or not len(rewards) or horizon < 1 or not np.isfinite(rewards).all():
        raise ValueError('Expected a finite nonempty reward episode and positive horizon')
    padded = np.pad(rewards, (0, horizon - 1))
    return np.lib.stride_tricks.sliding_window_view(padded, horizon).sum(1, dtype=np.float64)


def load_dense(path):
    with h5py.File(path, 'r') as f:
        rewards = np.asarray(f['rewards'][:], np.float32)
        ends = np.flatnonzero(f['terminals'][:] | f['timeouts'][:])
    starts = np.r_[0, ends[:-1] + 1]
    if len(ends) != 202 or not np.all(ends - starts + 1 == 1000) or ends[-1] + 1 != len(rewards):
        raise AssertionError('Expected verified 202 complete 1000-step trajectories')
    return rewards.reshape(202, 1000)


class SegmentDataset(Dataset):
    def __init__(self, base, labels):
        self.base, self.labels = base, labels

    def __len__(self):
        return len(self.base.dataset)

    def __getitem__(self, index):
        trajectory, start, _ = index
        sample = list(self.base._SequenceDataset__prepare_sample(trajectory, start))
        condition = self.labels[trajectory, start] * self.base.reward_scale
        sample[2] = np.full_like(sample[2], condition)
        sample[2][sample[4] == 0] = 0
        return (*sample, np.asarray(index, dtype=np.int64))


def prepare(root):
    root.mkdir(parents=True, exist_ok=False)
    config = common.read_json(BASELINE / 'config.json')
    baseline = common.read_json(BASELINE / 'summary.json')
    assert baseline['complete'] and baseline['completed_updates'] == 50000
    assert baseline['selection']['target_return'] == 12000
    dense = load_dense(DATA)
    labels = np.stack([segment_returns(r) for r in dense])
    complete = labels[:, :981].reshape(-1)
    q90 = float(np.quantile(complete, .9))
    stats = dict(full_windows=len(complete), all_sample_starts=int(labels.size),
                 padded_tail_starts=202*19, quantile_levels=[0, .5, .8, .9, .95, 1],
                 full_window_quantiles=np.quantile(complete, [0, .5, .8, .9, .95, 1]).tolist(),
                 all_start_quantiles=np.quantile(labels, [0, .5, .8, .9, .95, 1]).tolist(),
                 evaluation_target=q90, scaled_evaluation_target=q90*.001)
    np.savez_compressed(root / 'segment_labels.npz', returns=labels)
    common.write_json(root / 'segment_statistics.json', stats)
    source_hashes = {}
    for name in SOURCES:
        dest = root / 'source' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(PROJECT / name, dest)
        source_hashes[name] = common.file_hash(dest)
    baseline_files = ['config.json', 'partition.json', 'training_summary.json',
                      'summary.json', 'pairing_audit.json', 'metrics.jsonl',
                      'step000000.pt', *[f'step{s:06d}.pt' for s in WINDOW]]
    baseline_hashes = {name: common.file_hash(BASELINE/name) for name in baseline_files}
    ignored = {'source_sha256', 'initial_model_sha256', 'dataset_sha256', 'normalization_sha256',
               'torch_version', 'numpy_version', 'cuda_version', 'cuda_module_loading',
               'git_commit', 'slurm_job_id', 'gpu', 'expected_gpu'}
    config = {k: v for k, v in config.items() if k not in ignored}
    config.update(arm='segment_delayed_dt', reward_mode='segment_delayed',
                  group='Segment-delayed-DT-HCMR-seed0-50k-20261002', num_workers=0,
                  target_returns=[q90], segment_length=20)
    protocol = dict(version=1, training_config=config, baseline=str(BASELINE),
        baseline_sha256=baseline_hashes, dataset=str(DATA), dataset_file_sha256=common.file_hash(DATA),
        labels_sha256=common.file_hash(root/'segment_labels.npz'), source_sha256=source_hashes,
        statistics_sha256=common.file_hash(root/'segment_statistics.json'),
        train_seed=0, updates=50000, primary_window=WINDOW, evaluation_seed=271828,
        evaluation_episodes=100, evaluation_target=q90, target_rule='q90 of all complete 20-step windows; fixed before training',
        reward_information='original per-step rewards, richer supervision than terminal-total baseline',
        label_rule='sum original rewards of sampled context; constant RTG at valid positions; zero padding',
        tail_rule='preserve baseline starts, sum only existing steps without crossing episodes',
        inference='rolling context20, fixed q90 at all valid tokens; no reward subtraction or context resets',
        baseline_reused=True, baseline_target=12000,
        baseline_url='https://wandb.ai/2820402607-shandong-university/CORL-DDR/runs/b459d5e5e36d1a5c',
        sampler='historical PairedBatchSampler arm=dt, seed0; exact input stream audits',
        initialization='same from-scratch seed0 initialization; verify initial model hash',
        hardware='any available NVIDIA GPU; report hardware differences and dropout RNG hashes',
        runtime='torch1.13.1+cu117, CUDA_MODULE_LOADING=LAZY, 2 CPU threads',
        wandb_entity='2820402607-shandong-university', wandb_project='CORL-DDR',
        wandb_group=config['group'], automatic_extension=False, created_unix=time.time())
    common.write_json(root/'protocol.json', protocol)
    common.write_json(root/'baseline_reference.json', dict(primary_score=baseline['primary_score'],
        last_score=baseline['last_score'], target_return=12000, url=protocol['baseline_url']))
    print(json.dumps(dict(prepared=str(root), **stats)), flush=True)


def verify(root):
    p = common.read_json(root/'protocol.json')
    for name, digest in p['source_sha256'].items():
        assert common.file_hash(root/'source'/name) == digest, name
    for name, digest in p['baseline_sha256'].items():
        assert common.file_hash(Path(p['baseline'])/name) == digest, name
    assert common.file_hash(p['dataset']) == p['dataset_file_sha256']
    assert common.file_hash(root/'segment_labels.npz') == p['labels_sha256']
    assert common.file_hash(root/'segment_statistics.json') == p['statistics_sha256']
    return p


def validate_labels(base, root, p):
    dense = load_dense(p['dataset'])
    labels = np.load(root/'segment_labels.npz')['returns']
    np.testing.assert_array_equal(labels, np.stack([segment_returns(r) for r in dense]))
    assert base.seq_len == 20 and len(base.dataset) == 202
    for i, row in enumerate(base.dataset):
        assert len(row['actions']) == 1000
        assert float(row['returns'][0]) == float(dense[i].sum())
    partition = common.dataset_metadata(base)
    previous = common.read_json(Path(p['baseline'])/'partition.json')
    assert partition == previous, 'Baseline data, normalization or trajectory indexing mismatch'
    return labels, partition


def train(root, device, smoke=False):
    from dt import set_seed
    p = verify(root)
    config = dict(p['training_config'], device=device)
    steps = 3 if smoke else p['updates']
    output = root / ('smoke' if smoke else 'run')
    output.mkdir(exist_ok=False)
    torch.set_num_threads(2)
    assert torch.__version__ == '1.13.1+cu117'
    if not smoke:
        assert device.startswith('cuda'), 'Formal 50k training requires allocated GPU'
        assert common.read_json(root/'smoke/audit.json')['passed']
    base = common.load_base(config)
    labels, partition = validate_labels(base, root, p)
    dataset = SegmentDataset(base, labels)
    sampler = common.PairedBatchSampler(partition, 'dt', config['batch_size'], 0, steps)
    generator = torch.Generator().manual_seed(0)
    loader = DataLoader(dataset, batch_sampler=sampler, num_workers=0,
                        pin_memory=device.startswith('cuda'), generator=generator)
    set_seed(0, deterministic_torch=config['deterministic_torch'])
    model = common.make_model(config, base)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config['learning_rate'],
                                  betas=config['betas'], weight_decay=config['weight_decay'])
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer,
        lambda step: min((step+1)/config['warmup_steps'], 1))
    previous_config = common.read_json(Path(p['baseline'])/'config.json')
    initial = common.model_hash(model)
    assert initial == previous_config['initial_model_sha256'], 'Initialization mismatch'
    provenance = dict(config, initial_model_sha256=initial, source_sha256=p['source_sha256'],
        dataset_sha256=partition['dataset_sha256'], normalization_sha256=partition['normalization_sha256'],
        torch_version=torch.__version__, numpy_version=np.__version__, cuda_version=torch.version.cuda,
        gpu=torch.cuda.get_device_name() if device.startswith('cuda') else 'cpu',
        slurm_job_id=os.environ.get('SLURM_JOB_ID'), protocol_sha256=common.file_hash(root/'protocol.json'),
        smoke=smoke, planned_updates=steps)
    common.write_json(output/'config.json', provenance)
    prior_audits = {r['completed_updates']: r for r in common.read_json(Path(p['baseline'])/'pairing_audit.json')}
    stream = hashlib.sha256()
    counts = np.zeros(202, np.int64)
    audits = []

    def save(step):
        path = output/f'step{step:06d}.pt'
        torch.save(dict(model_state=model.state_dict(), optimizer_state=optimizer.state_dict(),
            scheduler_state=scheduler.state_dict(), completed_updates=step, next_step=step,
            config=config, state_mean=base.state_mean, state_std=base.state_std,
            rng_state=common.rng_state(), sampler_numpy_state=sampler.np_rng.get_state(),
            sampler_python_state=sampler.py_rng.getstate(), loader_generator_state=generator.get_state(),
            sample_stream_sha256=stream.hexdigest(), resume_note='from scratch only'), str(path)+'.tmp')
        os.replace(str(path)+'.tmp', path)

    save(0)
    started = time.monotonic()
    with (output/'metrics.jsonl').open('w', buffering=1) as metrics:
        for step, batch in enumerate(loader, 1):
            states, actions, returns, times, mask, indices = batch
            stream.update(indices.numpy().tobytes())
            counts += np.bincount(indices[:, 0].numpy(), minlength=202)
            row = None
            if step <= 3 or step % 5000 == 0 or step == steps:
                ids, starts = indices[:, 0].numpy(), indices[:, 1].numpy()
                expected = (labels[ids, starts]*config['reward_scale']).astype(np.float32)
                np.testing.assert_array_equal(returns.numpy(), np.where(mask.numpy()>0, expected[:, None], 0))
                row = dict(completed_updates=step-1,
                    batch_sha256=common.array_digest([states, actions, times, mask, indices]),
                    condition_sha256=common.array_digest([returns]),
                    torch_rng_sha256=common.torch_rng_hash(), sample_stream_sha256=stream.hexdigest())
                old = prior_audits[step-1]
                for key in ['batch_sha256', 'sample_stream_sha256']:
                    assert row[key] == old[key], f'Historical baseline pairing failed: {key}'
                row['dropout_rng_matches_baseline'] = row['torch_rng_sha256'] == old['torch_rng_sha256']
                if provenance['gpu'] == previous_config['gpu']:
                    assert row['dropout_rng_matches_baseline']
                row['labels_passed'] = True
            values = [v.to(device, non_blocking=True) for v in batch[:5]]
            states, actions, returns, times, mask = values
            prediction = model(states, actions, returns, times, ~mask.bool())
            loss = common.action_loss(prediction, actions, mask)
            if not torch.isfinite(loss):
                raise FloatingPointError(f'Nonfinite loss at update {step}')
            optimizer.zero_grad()
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), config['clip_grad'], error_if_nonfinite=True)
            optimizer.step()
            scheduler.step()
            if row is not None:
                row['loss'] = loss.item()
                audits.append(row)
                common.write_json(output/'pairing_audit.json', audits)
            if step <= 3 or step % 100 == 0:
                record = dict(completed_updates=step, train_loss=loss.item(), gradient_norm=float(norm),
                    learning_rate=scheduler.get_last_lr()[0], elapsed_seconds=time.monotonic()-started,
                    host_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                    cuda_peak_allocated_mib=torch.cuda.max_memory_allocated()/1024**2 if device.startswith('cuda') else 0)
                metrics.write(json.dumps(record, allow_nan=False)+'\n')
                if step <= 3 or step % 1000 == 0:
                    print(json.dumps(record), flush=True)
            if step in set(WINDOW+[10000, 20000, steps]):
                save(step)
    if not smoke:
        previous = common.read_json(Path(p['baseline'])/'training_summary.json')
        assert stream.hexdigest() == previous['sample_stream_sha256']
        assert counts.tolist() == previous['trajectory_sample_counts']
    summary = dict(completed_updates=steps, sample_stream_sha256=stream.hexdigest(),
        trajectory_sample_counts=counts.tolist(), initial_model_sha256=initial,
        final_model_sha256=common.model_hash(model), baseline_input_pairing_passed=True,
        dropout_rng_matches_baseline=all(a['dropout_rng_matches_baseline'] for a in audits),
        gpu=provenance['gpu'], baseline_gpu=previous_config['gpu'], smoke=smoke)
    common.write_json(output/'training_summary.json', summary)
    if smoke:
        result = common.evaluate_target(model, base, config, p['evaluation_target'], 123456, 1)
        common.write_json(output/'evaluation.json', result)
        verify(root)
        common.write_json(output/'audit.json', dict(passed=True, updates=steps,
            protocol_sha256=common.file_hash(root/'protocol.json'), **summary))
    else:
        del model, optimizer, scheduler, loader
        torch.cuda.empty_cache()
        evaluate(root, base, config, p)


def evaluate(root, base, config, p):
    output = root/'run'
    directory = output/'evaluation'
    directory.mkdir(exist_ok=False)
    target = p['evaluation_target']
    common.write_json(directory/'selection.json', dict(target_return=target, rule=p['target_rule'],
        protocol_sha256=common.file_hash(root/'protocol.json'), environment_based_selection=False))
    model = common.make_model(config, base)
    results = []
    for step in WINDOW:
        path = output/f'step{step:06d}.pt'
        checkpoint = torch.load(path, map_location='cpu')
        assert checkpoint['completed_updates'] == step
        common.check_checkpoint(checkpoint, base)
        model.load_state_dict(checkpoint['model_state'])
        before = common.model_hash(model)
        result = common.evaluate_target(model, base, config, target, p['evaluation_seed'], p['evaluation_episodes'])
        assert common.model_hash(model) == before
        result.update(completed_updates=step, checkpoint_sha256=common.file_hash(path))
        results.append(result)
        common.write_json(directory/f'heldout-{step:06d}.json', result)
        print(json.dumps(dict(evaluated_updates=step, mean_score=result['mean_score'])), flush=True)
    baseline = common.read_json(Path(p['baseline'])/'summary.json')
    for new, old in zip(results, baseline['evaluations']):
        assert new['completed_updates'] == old['completed_updates']
        assert [e['episode_seed'] for e in new['episodes']] == [e['episode_seed'] for e in old['episodes']]
    primary = float(np.mean([r['mean_score'] for r in results]))
    summary = dict(complete=True, completed_updates=50000, seed=0, arm='segment_delayed_dt',
        primary_window=WINDOW, target_return=target, primary_score=primary, last_score=results[-1]['mean_score'],
        baseline_primary_score=baseline['primary_score'], baseline_last_score=baseline['last_score'],
        primary_delta=primary-baseline['primary_score'], final_delta=results[-1]['mean_score']-baseline['last_score'],
        evaluations=results, training=common.read_json(output/'training_summary.json'),
        same_episode_seeds=True, richer_reward_supervision=True, automatic_extension=False)
    verify(root)
    common.write_json(output/'summary.json', summary)
    lines = ['# 片段级 delayed DT：seed 0 实验', '',
        '训练条件为采样片段原始奖励和，context20；末尾不足20步按实际长度求和并padding。',
        '使用原始逐步奖励构造标签，监督比整局终局回报更细；不是同等奖励信息下的方法对比。',
        f'从头训练50k，推理条件固定为完整20步片段q90={target:.6f}，reward_scale=.001。',
        '普通DT复用既有seed0基线，RTG=12000（此前通过开发集选定）。',
        '主指标为30/35/40/45/50k均分，每点100个episode，seeds271828+i。', '',
        '| 完成更新数 | 普通DT | 片段delayed DT | 差值 |', '|---|---:|---:|---:|']
    for new, old in zip(results, baseline['evaluations']):
        lines.append(f"| {new['completed_updates']} | {old['mean_score']:.4f} | {new['mean_score']:.4f} | {new['mean_score']-old['mean_score']:+.4f} |")
    lines += ['', f"后期均分：{primary:.4f}；基线：{baseline['primary_score']:.4f}；差值：{summary['primary_delta']:+.4f}。",
        f"硬件：新实验 {summary['training']['gpu']}，历史基线 {summary['training']['baseline_gpu']}。",
        '初始化和全部采样索引/抽查状态动作与历史基线匹配；硬件差异及dropout RNG审计见training_summary.json。',
        '这是单训练seed探索；不把episode数量当作训练seed，不自动延长或搜索条件。']
    (root/'report_zh.md').write_text('\n'.join(lines)+'\n')
    common.write_json(root/'completion.json', dict(complete=True, primary_score=primary,
        primary_delta=summary['primary_delta'], protocol_sha256=common.file_hash(root/'protocol.json')))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'smoke', 'train'])
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--device', default='cuda:0')
    args = parser.parse_args()
    root = args.root.resolve()
    if args.mode == 'prepare':
        prepare(root)
    else:
        train(root, args.device, smoke=args.mode == 'smoke')


if __name__ == '__main__':
    main()
