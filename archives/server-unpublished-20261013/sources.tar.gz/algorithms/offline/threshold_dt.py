"""Terminal-return threshold conditioning with matched exact-return controls.

Training never uses evaluation outcomes. Historical DT implementations are read
only. Evaluation/calibration happens after training, on saved checkpoints.
"""

import argparse
import hashlib
import json
import os
import random
import resource
import subprocess
import time
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader, Dataset

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG = ROOT / "configs/offline/dt/halfcheetah/medium_replay_v2.yaml"
ARMS = ("dt", "matched_dt", "threshold_dt", "top_bc")
QUANTILES = (0.0, 0.5, 0.8, 0.9)
PROFILES = {
    "smoke": {"updates": 3, "window": [1, 2, 3], "development_episodes": 1,
              "evaluation_episodes": 1, "evaluation_seed": 271828},
    "pilot": {"updates": 50000, "window": [30000, 35000, 40000, 45000, 50000],
              "development_episodes": 20, "evaluation_episodes": 100,
              "evaluation_seed": 271828},
    "confirm": {"updates": 100000, "window": [80000, 85000, 90000, 95000, 100000],
                "development_episodes": 20, "evaluation_episodes": 100,
                "evaluation_seed": 161803},
}


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, path)


def file_hash(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def array_digest(arrays):
    digest = hashlib.sha256()
    for item in arrays:
        if isinstance(item, torch.Tensor):
            item = item.detach().cpu().numpy()
        array = np.ascontiguousarray(item)
        digest.update(str((array.dtype.str, array.shape)).encode())
        digest.update(array.tobytes())
    return digest.hexdigest()


def model_hash(model):
    return array_digest(list(model.state_dict().values()))


def rng_state():
    return {"python": random.getstate(), "numpy": np.random.get_state(),
            "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if state["cuda"]:
        torch.cuda.set_rng_state_all(state["cuda"])


def torch_rng_hash():
    states = [torch.get_rng_state()]
    if torch.cuda.is_available():
        states += torch.cuda.get_rng_state_all()
    return array_digest(states)


@contextmanager
def isolated_evaluation(model):
    state, training = rng_state(), model.training
    try:
        model.eval()
        with torch.no_grad():
            yield
    finally:
        model.train(training)
        restore_rng(state)


def return_partition(returns, lengths):
    returns = np.asarray(returns, dtype=np.float64)
    lengths = np.asarray(lengths, dtype=np.int64)
    if (returns.ndim != 1 or returns.shape != lengths.shape or not len(returns)
            or not np.isfinite(returns).all() or np.any(lengths <= 0)):
        raise ValueError("Expected finite trajectory returns and positive lengths")
    thresholds = np.quantile(returns, QUANTILES)
    pools = [np.flatnonzero(returns >= value) for value in thresholds]
    # BC uses exactly ceil(10% * N), resolving tied returns by trajectory index.
    top = np.argsort(-returns, kind="stable")[:max(1, int(np.ceil(.1 * len(returns))))]
    candidates = list(dict.fromkeys(
        np.quantile(returns, [0.5, 0.8, 0.9, 0.95, 1.0]).tolist() + [6000., 12000.]
    ))
    return {"quantiles": list(QUANTILES), "thresholds": thresholds.tolist(),
            "eligible_trajectory_ids": [pool.tolist() for pool in pools],
            "eligible_counts": [len(pool) for pool in pools],
            "trajectory_returns": returns.tolist(),
            "trajectory_lengths": lengths.tolist(),
            "top_bc_trajectory_ids": top.tolist(), "candidate_returns": candidates,
            "primary_threshold": float(thresholds[-1]),
            "boundary": "return >= threshold; ties included",
            "top_bc_rule": "ceil(0.1*N), stable descending return rank"}


class PairedBatchSampler:
    """Main-process private RNG; no dependence on loader workers or model RNG.

    matched_dt and threshold_dt generate identical balanced minibatch indices.
    dt keeps CORL's length-proportional trajectory/uniform-start distribution.
    """

    def __init__(self, partition, arm, batch_size, seed, batches):
        if arm not in ARMS or batch_size < 1 or batches < 1:
            raise ValueError("Invalid sampler configuration")
        if arm in ("matched_dt", "threshold_dt") and batch_size % len(QUANTILES):
            raise ValueError("Balanced minibatch size must be divisible by four")
        self.partition, self.arm = partition, arm
        self.batch_size, self.batches = batch_size, batches
        self.np_rng, self.py_rng = np.random.RandomState(seed), random.Random(seed)
        self.lengths = np.asarray(partition["trajectory_lengths"], dtype=np.int64)
        if arm in ("matched_dt", "threshold_dt"):
            self.pools = [np.asarray(pool)
                          for pool in partition["eligible_trajectory_ids"]]
        else:
            self.pools = [np.arange(len(self.lengths)) if arm == "dt" else
                          np.asarray(partition["top_bc_trajectory_ids"])]
        self.probabilities = [self.lengths[pool] / self.lengths[pool].sum()
                              for pool in self.pools]

    def __len__(self):
        return self.batches

    def __iter__(self):
        for _ in range(self.batches):
            if self.arm in ("matched_dt", "threshold_dt"):
                groups = np.repeat(np.arange(4), self.batch_size // 4)
                groups = self.np_rng.permutation(groups)
            else:
                groups = np.full(self.batch_size, -1, dtype=np.int64)
            trajectories = np.empty(self.batch_size, dtype=np.int64)
            for group, (pool, probability) in enumerate(
                zip(self.pools, self.probabilities)
            ):
                positions = (np.flatnonzero(groups == group) if len(self.pools) > 1
                             else np.arange(self.batch_size))
                trajectories[positions] = self.np_rng.choice(
                    pool, len(positions), p=probability
                )
            batch = []
            for trajectory, group in zip(trajectories, groups):
                start = self.py_rng.randint(0, int(self.lengths[trajectory]) - 1)
                batch.append((int(trajectory), start, int(group)))
            yield batch


class ConditionedDataset(Dataset):
    def __init__(self, base, partition, arm):
        self.base, self.partition, self.arm = base, partition, arm

    def __len__(self):
        return len(self.base.dataset)

    def __getitem__(self, index):
        trajectory, start, group = index
        # Reuse precisely the original state normalization, sequence and padding.
        sample = list(self.base._SequenceDataset__prepare_sample(trajectory, start))
        if self.arm in ("threshold_dt", "top_bc"):
            value = (
                self.partition["thresholds"][group] if self.arm == "threshold_dt"
                else self.partition["primary_threshold"]
            )
            sample[2] = np.full_like(sample[2], value * self.base.reward_scale)
            sample[2][sample[4] == 0] = 0
        return (*sample, np.asarray(index, dtype=np.int64))


def action_loss(prediction, actions, mask):
    return (F.mse_loss(prediction, actions.detach(), reduction="none")
            * mask.unsqueeze(-1)).mean()


def make_model(config, base):
    from dt import DecisionTransformer
    return DecisionTransformer(
        state_dim=base.dataset[0]["observations"].shape[-1],
        action_dim=base.dataset[0]["actions"].shape[-1],
        **{key: config[key] for key in (
            "embedding_dim", "num_layers", "num_heads", "seq_len", "episode_len",
            "attention_dropout", "residual_dropout", "embedding_dropout", "max_action",
        )},
    ).to(config["device"])


def load_base(config):
    from dt import SequenceDataset
    return SequenceDataset(config["env_name"], config["seq_len"],
                           config["reward_scale"], "delayed")


def dataset_metadata(base):
    returns = [float(row["returns"][0]) for row in base.dataset]
    lengths = [len(row["actions"]) for row in base.dataset]
    partition = return_partition(returns, lengths)
    partition["dataset_sha256"] = array_digest([
        value for row in base.dataset
        for value in (row["observations"], row["actions"], row["returns"])
    ])
    partition["normalization_sha256"] = array_digest([base.state_mean, base.state_std])
    return partition


def evaluate_target(model, base, config, target, first_seed, episodes):
    import gym
    from dt import eval_rollout, wrap_env
    records = []
    # A fresh environment and explicit reset seed for every episode, shared
    # across targets/arms/checkpoints. Returned dense rewards are summed only.
    with isolated_evaluation(model):
        env = wrap_env(gym.make(config["env_name"]), base.state_mean, base.state_std,
                       config["reward_scale"])
        try:
            for index in range(episodes):
                seed = first_seed + index
                env.seed(seed)
                env.action_space.seed(seed)
                value, length = eval_rollout(
                    model, env, target * config["reward_scale"],
                    config["device"], "delayed",
                )
                raw = value / config["reward_scale"]
                records.append({
                    "episode_seed": seed, "return": float(raw),
                    "normalized_score": float(env.get_normalized_score(raw) * 100),
                    "length": int(length),
                })
        finally:
            env.close()
    return {"target_return": float(target), "episodes": records,
            "mean_score": float(np.mean([row["normalized_score"] for row in records]))}


def select_target(development):
    if not development or not all(np.isfinite(row["mean_score"]) for row in development):
        raise ValueError("Missing/nonfinite development results")
    # Stable candidate-order tie break, independent of held-out evaluations.
    return max(development, key=lambda row: row["mean_score"])["target_return"]


def check_checkpoint(checkpoint, base):
    for key in ("state_mean", "state_std"):
        np.testing.assert_allclose(
            checkpoint[key], getattr(base, key), rtol=0, atol=1e-6
        )


def evaluate_run(output, base, config, partition):
    profile = PROFILES[config["profile"]]
    directory = output / "evaluation"
    directory.mkdir(exist_ok=False)
    model = make_model(config, base)
    endpoint = output / f"step{profile['updates']:06d}.pt"
    checkpoint = torch.load(endpoint, map_location="cpu")
    check_checkpoint(checkpoint, base)
    model.load_state_dict(checkpoint["model_state"])
    development = []
    if config["arm"] in ("dt", "matched_dt"):
        for index, target in enumerate(partition["candidate_returns"]):
            result = evaluate_target(model, base, config, target, 31415,
                                     profile["development_episodes"])
            development.append(result)
            write_json(directory / f"development-{index}.json", result)
            print(f"DEVELOPMENT {target}: {result['mean_score']:.4f}", flush=True)
        target = select_target(development)
    else:
        target = partition["primary_threshold"]
    selection = {"target_return": target,
                 "rule": "development_argmax" if development else "fixed_q90",
                 "checkpoint_sha256": file_hash(endpoint),
                 "completed_updates": profile["updates"],
                 "development_seed": 31415,
                 "development_episodes": profile["development_episodes"],
                 "candidates": development}
    # Commit the selection before accessing ANY held-out episode outcomes.
    write_json(directory / "selection.json", selection)
    evaluations = []
    for step in profile["window"]:
        path = output / f"step{step:06d}.pt"
        checkpoint = torch.load(path, map_location="cpu")
        if checkpoint["completed_updates"] != step:
            raise ValueError("Checkpoint update count mismatch")
        model.load_state_dict(checkpoint["model_state"])
        result = evaluate_target(model, base, config, target, profile["evaluation_seed"],
                                 profile["evaluation_episodes"])
        result.update({"completed_updates": step, "checkpoint_sha256": file_hash(path)})
        evaluations.append(result)
        write_json(directory / f"heldout-{step:06d}.json", result)
        print(f"HELDOUT {step}: {result['mean_score']:.4f}", flush=True)
    training = read_json(output / "training_summary.json")
    primary = float(np.mean([row["mean_score"] for row in evaluations]))
    summary = {**training, "selection": selection,
               "evaluation_seed": profile["evaluation_seed"],
               "evaluation_episodes": profile["evaluation_episodes"],
               "window": profile["window"], "evaluations": evaluations,
               "primary_score": primary,
               "last_score": evaluations[-1]["mean_score"], "complete": True}
    write_json(output / "summary.json", summary)
    return summary


def source_hashes():
    return {name: file_hash(Path(__file__).with_name(name))
            for name in ("threshold_dt.py", "dt.py")}


def runtime_config(args):
    config = yaml.safe_load(Path(args.config).read_text())
    config.update({"arm": getattr(args, "arm", "dt"), "train_seed": args.seed,
                   "reward_mode": "delayed", "profile": args.profile,
                   "device": args.device, "num_workers": args.num_workers,
                   "expected_gpu": args.expected_gpu})
    config["update_steps"] = PROFILES[args.profile]["updates"]
    config["gpu"] = (torch.cuda.get_device_name(torch.device(args.device))
                     if args.device.startswith("cuda") else "cpu")
    if args.expected_gpu and args.expected_gpu not in config["gpu"]:
        raise ValueError(f"Expected {args.expected_gpu}, got {config['gpu']}")
    if config["batch_size"] % 4:
        raise ValueError("Use a batch size divisible by four")
    return config


def train(args):
    from dt import set_seed
    config = runtime_config(args)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(args.cpu_threads)
    base = load_base(config)
    partition = dataset_metadata(base)
    write_json(output / "partition.json", partition)
    dataset = ConditionedDataset(base, partition, args.arm)
    profile = PROFILES[args.profile]
    sampler = PairedBatchSampler(partition, args.arm, config["batch_size"],
                                 args.seed, profile["updates"])
    loader_generator = torch.Generator().manual_seed(args.seed)
    loader = DataLoader(dataset, batch_sampler=sampler, num_workers=args.num_workers,
                        pin_memory=args.device.startswith("cuda"),
                        generator=loader_generator)
    set_seed(args.seed, deterministic_torch=config["deterministic_torch"])
    model = make_model(config, base)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config["learning_rate"],
        betas=config["betas"], weight_decay=config["weight_decay"],
    )
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer, lambda step: min((step + 1) / config["warmup_steps"], 1)
    )
    provenance = {
        **config, "source_sha256": source_hashes(),
        "initial_model_sha256": model_hash(model),
        "dataset_sha256": partition["dataset_sha256"],
        "normalization_sha256": partition["normalization_sha256"],
        "torch_version": torch.__version__, "numpy_version": np.__version__,
        "cuda_version": torch.version.cuda,
        "cuda_module_loading": os.environ.get("CUDA_MODULE_LOADING"),
        "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT,
                                               text=True).strip(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
    }
    write_json(output / "config.json", provenance)
    sample_digest = hashlib.sha256()
    trajectory_counts = np.zeros(len(base.dataset), dtype=np.int64)
    condition_counts = np.zeros(4, dtype=np.int64)
    audits = []

    def save(step):
        path = output / f"step{step:06d}.pt"
        checkpoint = {"model_state": model.state_dict(),
                    "optimizer_state": optimizer.state_dict(),
                    "scheduler_state": scheduler.state_dict(), "completed_updates": step,
                    "next_step": step, "config": config, "state_mean": base.state_mean,
                    "state_std": base.state_std, "rng_state": rng_state(),
                    "sampler_numpy_state": sampler.np_rng.get_state(),
                    "sampler_python_state": sampler.py_rng.getstate(),
                    "loader_generator_state": loader_generator.get_state(),
                    "sample_stream_sha256": sample_digest.hexdigest(),
                    "resume_note": "From-scratch only; sampler prefetch may be ahead. "
                    "Snapshots do not promise an exact continuation."}
        torch.save(checkpoint, str(path) + ".tmp")
        os.replace(str(path) + ".tmp", path)

    save(0)
    started = time.monotonic()
    checkpoints = set(profile["window"]) | {10000, 20000}
    with (output / "metrics.jsonl").open("w", buffering=1) as metrics:
        for step, batch in enumerate(loader, 1):
            states, actions, returns, times, mask, indices = batch
            sample_digest.update(indices.numpy().tobytes())
            trajectory_counts += np.bincount(
                indices[:, 0].numpy(), minlength=len(base.dataset)
            )
            if args.arm in ("matched_dt", "threshold_dt"):
                counts = np.bincount(indices[:, 2].numpy(), minlength=4)
                if not np.all(counts == config["batch_size"] // 4):
                    raise AssertionError("Unbalanced threshold minibatch")
                condition_counts += counts
            audit = step <= 3 or step % 5000 == 0 or step == profile["updates"]
            row = None
            if audit:
                row = {"completed_updates": step - 1,
                       "batch_sha256": array_digest(
                           [states, actions, times, mask, indices]),
                       "condition_sha256": array_digest([returns]),
                       "torch_rng_sha256": torch_rng_hash(),
                       "sample_stream_sha256": sample_digest.hexdigest()}
            states, actions, returns, times, mask = [
                value.to(args.device, non_blocking=True) for value in batch[:5]
            ]
            prediction = model(states, actions, returns, times, ~mask.bool())
            loss = action_loss(prediction, actions, mask)
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Nonfinite loss at update {step}")
            optimizer.zero_grad()
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(
                model.parameters(), config["clip_grad"], error_if_nonfinite=True
            )
            optimizer.step()
            scheduler.step()
            if row is not None:
                row["loss"] = loss.item()
                audits.append(row)
                write_json(output / "pairing_audit.json", audits)
            if step <= 3 or step % 100 == 0:
                values = {"completed_updates": step, "train_loss": loss.item(),
                          "gradient_norm": float(norm),
                          "learning_rate": scheduler.get_last_lr()[0],
                          "elapsed_seconds": time.monotonic() - started,
                          "host_peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                          "cuda_peak_allocated_mib": (
                              torch.cuda.max_memory_allocated(args.device) / 1024 ** 2
                              if args.device.startswith("cuda") else 0)}
                metrics.write(json.dumps(values, allow_nan=False) + "\n")
                if step <= 3 or step % 1000 == 0:
                    print(json.dumps(values), flush=True)
            if step in checkpoints:
                save(step)
    training = {"arm": args.arm, "seed": args.seed, "profile": args.profile,
                "completed_updates": profile["updates"],
                "initial_model_sha256": provenance["initial_model_sha256"],
                "final_model_sha256": model_hash(model),
                "sample_stream_sha256": sample_digest.hexdigest(),
                "trajectory_sample_counts": trajectory_counts.tolist(),
                "condition_sample_counts": condition_counts.tolist()}
    write_json(output / "training_summary.json", training)
    del model, optimizer, scheduler, loader
    if args.device.startswith("cuda"):
        torch.cuda.empty_cache()
    summary = evaluate_run(output, base, config, partition)
    print(f"COMPLETE {args.arm}: {summary['primary_score']:.4f}", flush=True)


def sweep(args):
    config = runtime_config(args)
    torch.set_num_threads(args.cpu_threads)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    base = load_base(config)
    partition = dataset_metadata(base)
    before = file_hash(args.checkpoint)
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    check_checkpoint(checkpoint, base)
    saved_config = checkpoint.get("config", {})
    for key in ("env_name", "reward_mode", "seq_len", "reward_scale", "train_seed"):
        if key in saved_config and saved_config[key] != config[key]:
            raise ValueError(f"Historical checkpoint mismatch: {key}")
    if checkpoint.get("next_step") != 50000:
        raise ValueError("The preregistered diagnostic requires the 50k checkpoint")
    model = make_model(config, base)
    model.load_state_dict(checkpoint["model_state"])
    records = []
    for index, target in enumerate(partition["candidate_returns"]):
        result = evaluate_target(model, base, config, target, 31415,
                                 PROFILES[args.profile]["development_episodes"])
        records.append(result)
        write_json(output / f"target-{index}.json", result)
        print(f"SWEEP {target}: {result['mean_score']:.4f}", flush=True)
    if file_hash(args.checkpoint) != before:
        raise AssertionError("Historical checkpoint changed")
    write_json(output / "summary.json", {
        "checkpoint_sha256": before, "checkpoint": str(args.checkpoint),
        "config": config, "partition": partition, "evaluations": records,
        "optimizer_updates": 0, "complete": True,
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("train", "sweep"))
    parser.add_argument("--arm", choices=ARMS, default="dt")
    parser.add_argument("--profile", choices=PROFILES, default="pilot")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--expected-gpu", default="")
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--cpu-threads", type=int, default=2)
    parser.add_argument("--checkpoint", type=Path)
    args = parser.parse_args()
    if args.command == "sweep" and args.checkpoint is None:
        parser.error("sweep requires --checkpoint")
    (train if args.command == "train" else sweep)(args)


if __name__ == "__main__":
    main()
