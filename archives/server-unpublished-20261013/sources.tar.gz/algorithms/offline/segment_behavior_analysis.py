"""Descriptive continuous-segment analysis using states/actions/terminal totals.

No simulator, policy training, dense reward labels or learned reward model.
Matching is a fixed discovery-reference smoother, not a causal estimator.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import time

import h5py
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
DATA = Path('/labmount/users/202615385/.d4rl/datasets/halfcheetah_medium_replay-v2.hdf5')
FEATURES = [
    ('speed_mean', 'Mean forward velocity', 'm/s'),
    ('speed_gain', 'Mean velocity minus initial velocity', 'm/s'),
    ('speed_end_delta', 'Final minus initial velocity', 'm/s'),
    ('speed_std', 'Velocity standard deviation', 'm/s'),
    ('height_mean', 'Mean torso height', 'm'),
    ('pitch_abs_mean', 'Mean absolute wrapped torso pitch', 'rad'),
    ('pitch_std', 'Circular torso pitch standard deviation', 'rad'),
    ('joint_angle_std', 'Mean joint-angle standard deviation', 'rad'),
    ('action_rms', 'Action RMS', 'control units'),
    ('action_change_rms', 'Consecutive-action difference RMS', 'control units'),
    ('thigh_action_corr', 'Back/front thigh action correlation', 'correlation'),
    ('shin_action_corr', 'Back/front shin action correlation', 'correlation'),
    ('foot_action_corr', 'Back/front foot action correlation', 'correlation'),
]
RULES = dict(split_seed=20261002, discovery_trajectories=141,
             high_return_quantile=.8, primary_horizon=20, sensitivity_horizon=50,
             window_stride='equal to horizon; nonoverlapping query windows',
             time_radius=5, state_rmse_radius=.5, max_neighbors=32,
             min_neighbors=12, min_high_neighbors=4, min_other_neighbors=4,
             minimum_supported_window_fraction=.2,
             minimum_trajectories_per_group=10, bootstrap_repetitions=10000,
             bootstrap_seed=20261005, control_interval_seconds=.05,
             torso_base_height=.7)


def write(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    tmp.replace(path)


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    h = hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def load_data(path):
    with h5py.File(path,'r') as f:
        obs, nxt, act = f['observations'][:], f['next_observations'][:], f['actions'][:]
        ends = np.flatnonzero(f['terminals'][:] | f['timeouts'][:])
        rewards = f['rewards'][:]
    starts = np.r_[0,ends[:-1]+1]
    if len(ends)!=202 or not np.all(ends-starts+1==1000) or ends[-1]+1!=len(obs):
        raise AssertionError('Expected the verified complete 202 x 1000 dataset')
    totals = np.asarray([rewards[s:e+1].astype(np.float32).sum()
                         for s,e in zip(starts,ends)],np.float64)
    del rewards
    obs, nxt, act = obs.reshape(202,1000,17), nxt.reshape(202,1000,17), act.reshape(202,1000,6)
    np.testing.assert_array_equal(nxt[:,:-1],obs[:,1:])
    states = np.concatenate([obs[:,:1],nxt],axis=1)
    if not all(np.isfinite(x).all() for x in [states,act,totals]):
        raise AssertionError('Nonfinite data')
    return states,act,totals


def segment_features(states, actions, horizon):
    """All legal starts in ONE episode: H actions and their H resulting states."""
    n = len(actions)-horizon+1
    if len(states)!=len(actions)+1 or n<1 or horizon<2:
        raise ValueError('Need H >= 2 and T+1 states for T actions')
    sw = np.lib.stride_tricks.sliding_window_view(states[1:],horizon,axis=0).transpose(0,2,1)
    aw = np.lib.stride_tricks.sliding_window_view(actions,horizon,axis=0).transpose(0,2,1)
    vx = sw[:,:,8]
    pitch = np.arctan2(np.sin(sw[:,:,1]),np.cos(sw[:,:,1]))
    resultant = np.sqrt(np.sin(pitch).mean(1)**2+np.cos(pitch).mean(1)**2)
    centered = aw-aw.mean(1,keepdims=True)
    corr = []
    for back,front in [(0,3),(1,4),(2,5)]:
        x,y = centered[:,:,back],centered[:,:,front]
        denominator = np.sqrt((x*x).sum(1)*(y*y).sum(1))
        corr.append(np.divide((x*y).sum(1),denominator,
                              out=np.zeros(n,dtype=np.float64),where=denominator>1e-12))
    values = [vx.mean(1),vx.mean(1)-states[:n,8],states[horizon:,8]-states[:n,8],
              vx.std(1),sw[:,:,0].mean(1)+.7,np.abs(pitch).mean(1),
              np.sqrt(-2*np.log(np.clip(resultant,1e-12,1))),sw[:,:,2:8].std(1).mean(1),
              np.sqrt((aw*aw).mean((1,2))),np.sqrt((np.diff(aw,axis=1)**2).mean((1,2))),*corr]
    return np.stack(values,axis=1).astype(np.float64)


def nearest_start(states_normalized, discovery, query, step, horizon, exclude=-1):
    lo,hi = max(0,step-5),min(1001-horizon,step+6)
    distances = np.mean((states_normalized[:,lo:hi]-query)**2,axis=-1)
    offset = distances.argmin(1)
    rmse = np.sqrt(distances[np.arange(len(discovery)),offset])
    eligible = np.flatnonzero((rmse<=.5)&(discovery!=exclude))
    local = eligible[np.lexsort((discovery[eligible],rmse[eligible]))[:32]]
    return discovery[local],offset[local]+lo,rmse[local]


def support_reason(ids, high):
    if len(ids)<12:
        return 'fewer_than_12_distinct_trajectories'
    if high[ids].sum()<4:
        return 'fewer_than_4_high_trajectories'
    if (~high[ids]).sum()<4:
        return 'fewer_than_4_other_trajectories'
    return 'supported'


def group_statistics(values, high, seed=20261005):
    """One row per trajectory; stratified trajectory bootstrap, never windows."""
    values = np.asarray(values,np.float64)
    high = np.asarray(high,bool)
    nh,nl = int(high.sum()),int((~high).sum())
    if nh<2 or nl<2:
        return dict(high_trajectories=nh,other_trajectories=nl,features={},support_sufficient=False)
    a,b = values[high],values[~high]
    rng = np.random.default_rng(seed)
    wa = rng.multinomial(nh,np.full(nh,1/nh),size=10000)/nh
    wb = rng.multinomial(nl,np.full(nl,1/nl),size=10000)/nl
    boot = wa@a-wb@b
    difference = a.mean(0)-b.mean(0)
    ci = np.quantile(boot,[.025,.975],axis=0)
    se = boot.std(0,ddof=1)
    standardized = np.abs(boot-difference)/np.maximum(se,1e-12)
    critical = float(np.quantile(standardized.max(1),.95))
    simultaneous = np.stack([difference-critical*se,difference+critical*se])
    stats = {}
    for j,(key,_,unit) in enumerate(FEATURES):
        stats[key] = dict(high_mean=float(a[:,j].mean()),other_mean=float(b[:,j].mean()),
                          difference=float(difference[j]),ci95=ci[:,j].tolist(),
                          simultaneous_ci95=simultaneous[:,j].tolist(),unit=unit)
    return dict(high_trajectories=nh,other_trajectories=nl,features=stats,
                support_sufficient=min(nh,nl)>=10,
                simultaneous_method='bootstrap max absolute standardized deviation across all 13 fixed features',
                bootstrap_unit='trajectory; group-stratified',
                reference_uncertainty='conditional on the fixed discovery neighbor reference')


def signs(stats, simultaneous=True):
    result = {}
    if not stats['support_sufficient']:
        return result
    for key,values in stats['features'].items():
        lo,hi = values['simultaneous_ci95' if simultaneous else 'ci95']
        if lo>0 or hi<0:
            result[key] = 1 if lo>0 else -1
    return result


def analyze_split(states,actions,totals,features,mean,std,discovery,ids,high,horizon,out,split):
    starts = np.arange(0,1001-horizon,horizon)
    normalized = (states[discovery]-mean)/std
    count = len(ids)*len(starts)
    neighbor_ids = np.full((count,32),-1,np.int16)
    neighbor_steps = np.full_like(neighbor_ids,-1)
    neighbor_rmse = np.full((count,32),np.nan,np.float32)
    raw = features[ids][:,starts]
    residual = np.full_like(raw,np.nan)
    initial_residual = np.full((len(ids),len(starts),17),np.nan,np.float64)
    supported = np.zeros((len(ids),len(starts)),bool)
    records, reasons = [],Counter()
    for i,tid in enumerate(ids):
        for j,step in enumerate(starts):
            ni,nt,nd = nearest_start(normalized,discovery,(states[tid,step]-mean)/std,
                                    int(step),horizon,int(tid))
            assert len(set(ni))==len(ni) and tid not in ni and set(ni)<=set(discovery)
            assert np.all(nt+horizon<=1000) and np.all(np.abs(nt-step)<=5)
            row=i*len(starts)+j
            neighbor_ids[row,:len(ni)],neighbor_steps[row,:len(ni)],neighbor_rmse[row,:len(ni)]=ni,nt,nd
            reason=support_reason(ni,high)
            reasons[reason]+=1
            records.append(dict(trajectory=int(tid),step=int(step),reason=reason,
                                neighbors=len(ni),high_neighbors=int(high[ni].sum())))
            if reason=='supported':
                supported[i,j]=True
                reference=features[ni,nt].mean(0)
                residual[i,j]=raw[i,j]-reference
                initial_residual[i,j]=states[tid,step]-states[ni,nt].mean(0)
    minimum=int(np.ceil(.2*len(starts)))
    counts=supported.sum(1)
    included=counts>=minimum
    supported_ids=ids[included]
    raw_matched=np.asarray([raw[i,supported[i]].mean(0) for i in np.flatnonzero(included)])
    adjusted=np.asarray([residual[i,supported[i]].mean(0) for i in np.flatnonzero(included)])
    initial=np.asarray([initial_residual[i,supported[i]].mean(0) for i in np.flatnonzero(included)])
    np.savez_compressed(out/f'{split}_h{horizon}_windows.npz',trajectory_ids=ids,starts=starts,
        high=high[ids],raw_features=raw,residual_features=residual,supported=supported,
        included_trajectories=included,neighbor_ids=neighbor_ids,neighbor_steps=neighbor_steps,
        neighbor_rmse=neighbor_rmse,initial_state_residual=initial_residual)
    with open(out/f'{split}_h{horizon}_queries.jsonl','w') as f:
        for row in records:
            f.write(json.dumps(row)+'\n')
    group_count=lambda mask:dict(trajectories=int(mask.sum()),
        matched_trajectories=int((mask&included).sum()),
        supported_windows=int(supported[mask].sum()),total_windows=int(mask.sum()*len(starts)))
    balance={}
    if len(initial) and high[supported_ids].any() and (~high[supported_ids]).any():
        for column,key in [(8,'initial_speed'),(0,'initial_root_z'),(1,'initial_pitch')]:
            hmean=float(initial[high[supported_ids],column].mean())
            lmean=float(initial[~high[supported_ids],column].mean())
            balance[key]=dict(high_query_minus_reference=hmean,other_query_minus_reference=lmean,
                              high_minus_other_residual=hmean-lmean)
    summary=dict(horizon=horizon,split=split,window_count=count,windows_per_trajectory=len(starts),
        support_reasons=dict(reasons),minimum_windows_per_included_trajectory=minimum,
        high_coverage=group_count(high[ids]),other_coverage=group_count(~high[ids]),
        included_trajectory_ids=supported_ids.tolist(),
        excluded_trajectory_ids=ids[~included].tolist(),
        included_return_range=[float(totals[supported_ids].min()),float(totals[supported_ids].max())] if len(supported_ids) else None,
        initial_balance=balance,
        all_windows=group_statistics(raw.mean(1),high[ids]),
        matched_windows_raw=group_statistics(raw_matched,high[supported_ids]),
        matched_residual=group_statistics(adjusted,high[supported_ids]))
    return summary


def freeze(args):
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=True)
    if (out/'protocol.json').exists():
        raise FileExistsError('Existing protocol; choose a fresh directory')
    sources=['algorithms/offline/segment_behavior_analysis.py',
             'scripts/dt_experiments/plot_segment_behavior.py',
             'scripts/dt_experiments/upload_segment_behavior.py',
             'tests/test_segment_behavior_analysis.py',
             'docs/segment_behavior_analysis.md']
    hashes={}
    for name in sources:
        dest=out/'source'/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/name,dest)
        hashes[name]=digest(dest)
    gym_root=Path('/labmount/users/202615385/miniforge3/envs/adt-delayed/lib/python3.9/site-packages/gym/envs/mujoco')
    for name in ['half_cheetah.py','assets/half_cheetah.xml']:
        dest=out/'source/environment'/Path(name).name
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(gym_root/name,dest)
        hashes['environment/'+Path(name).name]=digest(dest)
    protocol=dict(rules=RULES,features=FEATURES,dataset=str(args.dataset.resolve()),
        dataset_sha256=digest(args.dataset),source_sha256=hashes,created_unix=time.time(),
        matching='Full 17D normalized state at segment start; other discovery trajectories only. One nearest start per trajectory, +/-5 steps, RMSE <=0.5, at most32.',
        adjustment='Each observed feature minus mean feature of discovery neighbors; compare trajectory means between high and other query groups.',
        validation_status='Exploratory: these 61 trajectories appeared in the previous action-consensus diagnostic; not a fresh confirmatory holdout.',
        bootstrap='10000 stratified trajectory resamples; discovery reference fixed, its sampling uncertainty is not included.',
        pattern_rule='Freeze signs whose discovery H20 adjusted simultaneous95 interval excludes zero. Check same signs in validation H20 simultaneous95 intervals; H50 pointwise95 is sensitivity only.',
        insufficient_support='Fewer than10 included query trajectories in either group; descriptive results only.',
        noncausal='Residual matching does not remove all confounding. No key-action, causality or AWR effectiveness claims.',
        no_training=True,no_simulator=True,no_dense_reward_labels=True,
        next_state_alignment='All 201798 within-episode next observations must equal following observations exactly.',
        reward_handling='Reduce rewards once to float32 episode totals, then discard. Do not reconstruct dense rewards.',
        constant_action_correlation='zero by convention when either centered action norm is zero; not evidence of coordination',
        wandb_entity='2820402607-shandong-university',wandb_project='CORL-DDR',
        wandb_group='Segment-behavior-HCMR-delayed-20261002')
    write(out/'protocol.json',protocol)
    return out,protocol


def run(args):
    started=time.time()
    out,protocol=freeze(args)
    states,actions,totals=load_data(args.dataset)
    order=np.random.default_rng(20261002).permutation(202)
    discovery,validation=order[:141],order[141:]
    reference=states[discovery,:1000].reshape(-1,17)
    mean,std=reference.mean(0),reference.std(0)+1e-6
    threshold=float(np.quantile(totals[discovery],.8))
    high=totals>=threshold
    preprocessing=dict(discovery=discovery.tolist(),validation=validation.tolist(),
        state_mean=mean.tolist(),state_std=std.tolist(),trajectory_returns=totals.tolist(),
        high_return_threshold=threshold,discovery_high=int(high[discovery].sum()),
        validation_high=int(high[validation].sum()))
    # Require exact reuse of the promised split, but no old branch outcomes are read.
    old=read(ROOT/'results/action-consensus-20261002/preprocessing.json')
    assert preprocessing['discovery']==old['discovery'] and preprocessing['validation']==old['validation']
    write(out/'preprocessing.json',preprocessing)
    features={h:np.stack([segment_features(s,a,h) for s,a in zip(states,actions)]) for h in [20,50]}
    summary={'discovery':{},'validation':{}}
    for h in [20,50]:
        summary['discovery'][str(h)]=analyze_split(states,actions,totals,features[h],mean,std,
            discovery,discovery,high,h,out,'discovery')
        print(json.dumps(dict(stage='discovery',horizon=h,elapsed_seconds=time.time()-started)),flush=True)
    locked=signs(summary['discovery']['20']['matched_residual'])
    write(out/'discovery_lock.json',dict(pattern_signs=locked,
        discovery=summary['discovery'],frozen_before_validation_statistics=True,created_unix=time.time()))
    for h in [20,50]:
        summary['validation'][str(h)]=analyze_split(states,actions,totals,features[h],mean,std,
            discovery,validation,high,h,out,'validation')
        print(json.dumps(dict(stage='validation',horizon=h,elapsed_seconds=time.time()-started)),flush=True)
    val=signs(summary['validation']['20']['matched_residual'])
    sens=signs(summary['validation']['50']['matched_residual'],False)
    replicated=[key for key,sign in locked.items() if val.get(key)==sign]
    stable=[key for key in replicated if sens.get(key)==locked[key]]
    summary['findings']=dict(discovery_patterns=locked,replicated_h20=replicated,
        same_direction_h50_pointwise95=stable,
        action_patterns_h20=[key for key in replicated if key in [f[0] for f in FEATURES[8:]]],
        exploratory_only=True,causal_evidence=False,awr_effectiveness_tested=False)
    # Descriptive location of positive forward-speed gaps, NOT local rewards or weights.
    time_profiles={}
    for split,ids in [('discovery',discovery),('validation',validation)]:
        raw=features[20][ids][:,np.arange(0,981,20),0]
        gap=raw[high[ids]].mean(0)-raw[~high[ids]].mean(0)
        positive=np.maximum(gap,0)
        total=float(positive.sum())
        time_profiles[split]=dict(positive_gap_window_fraction=float((gap>0).mean()),
            top_20pct_windows_positive_gap_share=float(np.sort(positive)[-10:].sum()/total) if total else None,
            first_200_steps_positive_gap_share=float(positive[:10].sum()/total) if total else None,
            speed_gap_first_200=float(gap[:10].mean()),speed_gap_after_200=float(gap[10:].mean()))
    summary['temporal_speed_gap']=time_profiles
    summary['audit']=dict(split_disjoint=True,one_neighbor_per_trajectory=True,
        discovery_only_normalization=True,discovery_only_high_threshold=True,
        discovery_only_reference=True,query_trajectory_excluded=True,
        no_window_crosses_episode_boundary=True,next_state_alignment_exact=True,
        bootstrap_unit='trajectory',reference_fixed=True,no_training=True,
        no_branch_outcomes_read=True,no_dense_reward_labels=True)
    summary['elapsed_seconds']=time.time()-started
    write(out/'summary.json',summary)
    names=['protocol.json','preprocessing.json','discovery_lock.json','summary.json']
    names += [p.name for p in out.glob('*.npz')]+[p.name for p in out.glob('*.jsonl')]
    write(out/'analysis_manifest.json',{name:digest(out/name) for name in names})
    print(json.dumps(summary['findings']),flush=True)
    print(json.dumps(time_profiles),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset',type=Path,default=DATA)
    parser.add_argument('--output',type=Path,required=True)
    run(parser.parse_args())
