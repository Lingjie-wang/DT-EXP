"""Audited portability/correctness adapters for the official LPT implementation.

The Transformer, U-Net, objectives and Langevin equations remain upstream.
FlashAttention's local causal operator is evaluated in bounded query blocks.
"""
import importlib.util
from pathlib import Path
import sys
import types

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F


def local_attention(query, key, value, window, dropout=0., scale=1., block=64):
    """[B,T,H,D], keys in [t-window,t]; matches FA window=(window,-1), causal.

    All dataset trajectories are full length. Padding and cached unequal lengths
    are deliberately rejected by the caller rather than approximated.
    """
    if query.shape != key.shape or key.shape != value.shape:
        raise ValueError('Only equal-length self attention is used in this reproduction')
    q, k, v = [x.transpose(1, 2) for x in (query, key, value)]
    output = []
    length = q.shape[2]
    for start in range(0, length, block):
        end = min(length, start + block)
        first = max(0, start - window) if window >= 0 else 0
        # FP32 accumulation also supports CPU smoke; upstream Q/K/V casts are retained.
        scores = q[:, :, start:end].float() @ k[:, :, first:end].float().transpose(-1, -2)
        scores = scores * scale
        qi = torch.arange(start, end, device=q.device)[:, None]
        ki = torch.arange(first, end, device=q.device)[None, :]
        valid = ki <= qi
        if window >= 0:
            valid = valid & (ki >= qi - window)
        scores = scores.masked_fill(~valid, -torch.inf)
        probs = F.dropout(scores.softmax(-1), p=dropout, training=dropout > 0)
        result = probs @ v[:, :, first:end].float()
        output.append(result.to(value.dtype))
    return torch.cat(output, dim=2).transpose(1, 2).contiguous()


def portable_flash(self, query_states, key_states, value_states, attention_mask,
                   query_length, dropout=0., softmax_scale=None):
    if attention_mask is not None and not bool(torch.all(attention_mask == 1)):
        raise ValueError('The full-trajectory reproduction does not permit padding')
    if not self.is_causal or query_length != key_states.shape[1]:
        raise ValueError('Unsupported attention path')
    # Upstream only supplies the local window on its non-null mask path.
    window = self.window_size if attention_mask is not None else -1
    return local_attention(query_states, key_states, value_states, window,
                           dropout=dropout, scale=softmax_scale or query_states.shape[-1] ** -.5).float()


def load_official(source):
    source = Path(source)
    if 'lpt_official.lpt' in sys.modules:
        return sys.modules['lpt_official.lpt']
    package = types.ModuleType('lpt_official')
    package.__path__ = [str(source / 'model')]
    sys.modules['lpt_official'] = package
    for name in ['unet1d', 'lpt']:
        spec = importlib.util.spec_from_file_location('lpt_official.' + name, source / 'model' / (name + '.py'))
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        setattr(package, name, module)
    module.DecisionTransformerGPT2FlashAttention._flash_attention_forward = portable_flash
    return module


def make_model(p, source, device):
    upstream = load_official(source)

    class ReproLPT(upstream.LPT):
        def __init__(self, config):
            # Preserve the random draw and initialization order of a single CUDA
            # device also for CPU tests. Upstream drops its initial draw on CPU.
            saved = torch.get_rng_state()
            super().__init__(config)
            if not self.z_buffers:
                # Recover that draw by reconstructing the same CPU initialization;
                # capture randn(shape) only at the persistent buffer allocation.
                after = torch.get_rng_state()
                torch.set_rng_state(saved)
                calls = []
                original = torch.randn

                def capture(*shape, **kwargs):
                    value = original(*shape, **kwargs)
                    if shape == (config.n_traj, config.n_latent, config.hidden_size):
                        calls.append(value.clone())
                    return value

                torch.randn = capture
                try:
                    temporary = upstream.LPT(config)
                    del temporary
                finally:
                    torch.randn = original
                    torch.set_rng_state(after)
                if len(calls) != 1:
                    raise RuntimeError('Could not recover upstream CPU latent initialization')
                self.z_buffers = {torch.device('cpu'): calls[0]}
            self._pending = None
            self._defer_commit = False

        def update_and_broadcast(self, device_index, batch_inds, z):
            ids = batch_inds.reshape(-1).detach().cpu().numpy()
            values = z.detach().reshape(-1, self.n_latent, self.hidden_size)
            if self._defer_commit:
                self._pending.append((ids.copy(), values.clone()))
            else:
                commit_latents(self, ids, values)

        def forward(self, **kwargs):
            # Correct the upstream batch-offset / dataset-index confusion, after
            # preserving the previous best across microbatches.
            previous_y = float(self.y_max)
            previous_id = int(self.z_best_idx)
            result = super().forward(**kwargs)
            target = kwargs['rewards'].reshape(-1)
            maximum, offset = target.max(dim=0)
            if float(maximum) > previous_y:
                self.y_max = float(maximum)
                self.z_best_idx = int(kwargs['batch_inds'].reshape(-1)[offset])
            else:
                self.y_max, self.z_best_idx = previous_y, previous_id
            return result

    config = upstream.DecisionTransformerConfig(
        state_dim=17, act_dim=6, n_traj=p['trajectories'], add_cross_attention=True,
        max_ep_len=p['max_len'], window_size=p['window_size'], langevin_step_size=.3,
        reward_weight=.25, hidden_size=p['hidden_size'], n_layer=p['n_layer'], n_head=1,
        per_device_train_batch_size=p['nominal_batch_size'], num_train_epochs=p['epochs'],
        n_latent=4, omega_cg=1, nonlinearity='ReLU', use_cache=False)
    model = ReproLPT(config)
    # CUDA_VISIBLE_DEVICES exposes one GPU. Move the PMC explicitly; it is not an
    # nn.Module buffer in the released implementation.
    values = next(iter(model.z_buffers.values())).detach().clone()
    model = model.to(device)
    model.z_buffers = {torch.device(device): values.to(device)}
    return model


def commit_latents(model, ids, values):
    # Repeated trajectory IDs are common with replacement sampling. Advanced
    # index assignment with duplicates is not deterministic on CUDA. Define
    # ordered last-occurrence semantics explicitly, once per logical batch.
    last = {int(index): position for position, index in enumerate(ids)}
    device = next(model.parameters()).device
    keys = torch.tensor(list(last), device=device, dtype=torch.long)
    positions = torch.tensor(list(last.values()), device=device, dtype=torch.long)
    model.z_buffers[device][keys] = values[positions].to(device)


def latent_state(model):
    return dict(buffer=next(iter(model.z_buffers.values())).detach().cpu().clone(),
                best_index=int(model.z_best_idx), y_max=float(model.y_max))


def restore_latents(model, state):
    device = next(model.parameters()).device
    model.z_buffers = {device: state['buffer'].to(device).clone()}
    model.z_best_idx, model.y_max = state['best_index'], state['y_max']


def optimizer_for(model, lr):
    # Same decay exclusion as transformers Trainer's AdamW: bias and LayerNorm.
    excluded = {id(p) for module in model.modules() if isinstance(module, nn.LayerNorm)
                for p in module.parameters()}
    decay, no_decay = [], []
    for name, param in model.named_parameters():
        (no_decay if name.endswith('bias') or id(param) in excluded else decay).append(param)
    return torch.optim.AdamW([dict(params=decay, weight_decay=1e-4),
                             dict(params=no_decay, weight_decay=0.)], lr=lr, betas=(.9, .999), eps=1e-8)


def logical_backward(model, data, ids, arm, microbatch, device):
    """Full-trajectory microbatches share a frozen PMC until the optimizer step.

    This preserves per-example Langevin gradients and the batch-mean objective.
    Dropout/noise draw order differs from an unchunked implementation, but is
    identical between the two reward arms. No state/action window is shortened.
    """
    model.train()
    model._defer_commit, model._pending = True, []
    total = 0.
    try:
        for start in range(0, len(ids), microbatch):
            selected = ids[start:start + microbatch]
            fields = make_batch(data, selected, arm, device)
            output = model(**fields)
            loss = output['loss']
            if not torch.isfinite(loss):
                raise FloatingPointError('Nonfinite LPT loss')
            weight = len(selected) / len(ids)
            (loss * weight).backward()
            total += float(loss.detach()) * weight
        all_ids = np.concatenate([x[0] for x in model._pending])
        all_values = torch.cat([x[1] for x in model._pending])
        commit_latents(model, all_ids, all_values)
    finally:
        model._defer_commit, model._pending = False, None
    return total


def make_batch(data, ids, arm, device):
    count, length = len(ids), data['states'].shape[1]
    return dict(states=torch.as_tensor(data['states'][ids], device=device),
                actions=torch.as_tensor(data['actions'][ids], device=device),
                rewards=torch.as_tensor(data[arm + '_totals'][ids], device=device),
                returns_to_go=torch.as_tensor(data[arm + '_rtg'][ids, :, None], device=device),
                timesteps=torch.arange(length, device=device).repeat(count, 1),
                attention_mask=torch.ones(count, length, device=device),
                batch_inds=torch.as_tensor(ids[:, None], dtype=torch.long, device=device))
