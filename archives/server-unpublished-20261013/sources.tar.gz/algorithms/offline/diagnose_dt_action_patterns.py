"""Frozen DT action-pattern reproduction: offline history vs real rollouts.

No optimizer, intervention, reward predictor, or policy training. CPU preparation
and summarization do not import MuJoCo. GPU workers use the existing DT helpers.
"""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import shutil
import time

import numpy as np
from segment_behavior_analysis import load_data, segment_features

ROOT=Path(__file__).resolve().parents[2]
DATA=Path('/labmount/users/202615385/.d4rl/datasets/halfcheetah_medium_replay-v2.hdf5')
CHECKPOINT=ROOT/'results/threshold-dt-seed0-3090-20261001/pilot/seed0/dt/step050000.pt'
PREPROCESSING=ROOT/'results/segment-behavior-20261002/preprocessing.json'
RULES=dict(context=20,horizons=[20,50],conditions=['actual_return','rtg12000'],batch_size=256,
    episode_seed=535353,episodes=20,time_radius=5,state_radius=.5,speed_radius=.25,
    max_neighbors=32,min_high_neighbors=4,min_supported_episodes=10,
    min_supported_windows={'20':100,'50':40},correlation_std_floor=1e-6,
    ratio_denominator_floor=1e-6,bootstrap_seed=20261006,bootstrap_repetitions=10000,
    minimum_metric_units=10,ratio_threshold=.90,correlation_shift_threshold=.05,
    repeat_tolerance=1e-6,batch_prediction_atol=2e-5,causal_atol=1e-6)
PRIMARY=('change_ratio','corr_difference')
METRICS=('action_mse','model_rms','reference_rms','amplitude_ratio','model_change_rms',
         'reference_change_rms','change_ratio','model_corr','reference_corr','corr_difference')
SOURCES=('algorithms/offline/diagnose_dt_action_patterns.py',
         'algorithms/offline/segment_behavior_analysis.py','algorithms/offline/oracle_branching_dt.py',
         'algorithms/offline/dt.py','scripts/dt_experiments/run_dt_action_patterns.sbatch',
         'scripts/dt_experiments/finish_dt_action_patterns.py',
         'scripts/dt_experiments/plot_dt_action_patterns.py',
         'tests/test_dt_action_patterns.py','docs/dt_action_patterns.md')


def write(path,obj):
    path=Path(path)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
    tmp.replace(path)


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def finite_mean(values):
    a=np.asarray(values,dtype=np.float64)
    a=a[np.isfinite(a)]
    return float(a.mean()) if len(a) else None


def action_features(actions,horizon):
    """Reuse previous RMS/correlation formulas, but never fill undefined corr with zero."""
    actions=np.asarray(actions,np.float64)
    original=segment_features(np.zeros((len(actions)+1,17)),actions,horizon)
    result=original[:,[8,9,10]].copy()
    windows=np.lib.stride_tricks.sliding_window_view(actions,horizon,axis=0)
    defined=(windows[:,0].std(1)>=1e-6)&(windows[:,3].std(1)>=1e-6)
    result[~defined,2]=np.nan
    return result


def pack_history(states,actions,targets,trajectory_ids,steps,length):
    trajectory_ids=np.asarray(trajectory_ids,dtype=np.int64)
    steps=np.asarray(steps,dtype=np.int64)
    times=steps[:,None]-length+1+np.arange(length)[None,:]
    if np.any(times<0) or np.any(times>=states.shape[1]) or not 1<=length<=20:
        raise ValueError('History outside episode or context')
    s=states[trajectory_ids[:,None],times].copy()
    a=actions[trajectory_ids[:,None],times].copy()
    a[:,-1]=0
    returns=np.broadcast_to(targets[trajectory_ids,None],times.shape).copy().astype(np.float32)
    return s,a,returns,times


def select_neighbors(states,normalized,ids,query,mean,std,step,horizon):
    lo,hi=max(0,step-5),min(1001-horizon,step+6)
    squared=np.mean((normalized[:,lo:hi]-(query-mean)/std)**2,-1)
    # Apply both calipers BEFORE picking one nearest start per trajectory.
    speed_ok=np.abs(states[:,lo:hi,8]-query[8])<=.25
    valid=speed_ok&(squared<=.5**2)
    masked=np.where(valid,squared,np.inf)
    offsets=masked.argmin(1)
    best=masked[np.arange(len(ids)),offsets]
    eligible=np.flatnonzero(np.isfinite(best))
    chosen=eligible[np.lexsort((ids[eligible],best[eligible]))[:32]]
    return ids[chosen],offsets[chosen]+lo,np.sqrt(best[chosen])


def window_metrics(model,reference,mse=np.nan):
    rms,change,corr=map(float,model)
    ref_rms,ref_change,ref_corr=map(float,reference)
    return np.asarray([mse,rms,ref_rms,rms/ref_rms if ref_rms>1e-6 else np.nan,
        change,ref_change,change/ref_change if ref_change>1e-6 else np.nan,
        corr,ref_corr,corr-ref_corr if np.isfinite(corr) and np.isfinite(ref_corr) else np.nan])


def aggregate_unit(unit_id,values):
    values=np.asarray(values,np.float64).reshape(-1,len(METRICS))
    return dict(id=int(unit_id),windows=len(values),
        metrics={k:finite_mean(values[:,j]) for j,k in enumerate(METRICS)},
        valid_windows={k:int(np.isfinite(values[:,j]).sum()) for j,k in enumerate(METRICS)},
        undefined_model_corr=int(np.isnan(values[:,7]).sum()),
        undefined_reference_corr=int(np.isnan(values[:,8]).sum()))


def bootstrap_units(units,coverage_ok=True):
    """Shared cluster resamples; missing units stay missing, never zero intervention."""
    n=len(units)
    values=np.asarray([[u['metrics'][k] if u['metrics'][k] is not None else np.nan
                        for k in PRIMARY] for u in units],np.float64).reshape(n,2)
    valid=np.isfinite(values)
    counts=valid.sum(0)
    means=np.divide(np.nansum(values,0),counts,out=np.full(2,np.nan),where=counts>0)
    boot=np.full((10000,2),np.nan)
    if n:
        weights=np.random.default_rng(20261006).multinomial(n,np.full(n,1/n),size=10000)
        denominators=weights@valid.astype(float)
        np.divide(weights@np.nan_to_num(values),denominators,out=boot,where=denominators>0)
    available=counts>=2
    simultaneous=np.full((2,2),np.nan)
    if available.any():
        complete=np.isfinite(boot[:,available]).all(1)
        se=boot[complete][:,available].std(0,ddof=1)
        maxima=np.max(np.abs(boot[complete][:,available]-means[available])/np.maximum(se,1e-12),1)
        critical=np.quantile(maxima,.95)
        simultaneous[:,available]=np.stack([means[available]-critical*se,means[available]+critical*se])
    primary={}
    for j,key in enumerate(PRIMARY):
        draws=boot[np.isfinite(boot[:,j]),j]
        primary[key]=dict(mean=float(means[j]) if counts[j] else None,units=int(counts[j]),
            ci95=np.quantile(draws,[.025,.975]).tolist() if counts[j]>=2 else None,
            simultaneous_ci95=simultaneous[:,j].tolist() if available[j] else None)
    descriptive={k:finite_mean([u['metrics'][k] if u['metrics'][k] is not None else np.nan for u in units]) for k in METRICS}
    ratio,corr=primary['change_ratio'],primary['corr_difference']
    ratio_support=coverage_ok and ratio['units']>=10
    corr_support=coverage_ok and corr['units']>=10
    # Reference sign is evaluated on precisely the units/windows with a defined paired difference.
    paired_reference=[]
    for u in units:
        if u['metrics']['corr_difference'] is not None:
            paired_reference.append(u.get('paired_reference_corr',u['metrics']['reference_corr']))
    ref_corr=finite_mean(paired_reference)
    return dict(units=n,primary=primary,descriptive=descriptive,coverage_sufficient=bool(coverage_ok),
        change_metric_supported=bool(ratio_support),correlation_metric_supported=bool(corr_support),
        change_compressed=bool(ratio_support and ratio['mean']<=.9 and ratio['simultaneous_ci95'][1]<1),
        negative_correlation_weakened=bool(corr_support and ref_corr is not None and ref_corr<0
            and corr['mean']>=.05 and corr['simultaneous_ci95'][0]>0),
        paired_reference_corr=ref_corr,
        undefined_model_corr_windows=sum(u['undefined_model_corr'] for u in units),
        undefined_reference_corr_windows=sum(u['undefined_reference_corr'] for u in units),
        interval_method='simultaneous95 bootstrap maximum standardized deviation for two fixed primary metrics',
        reference_fixed=True)


def prepare(args):
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=True)
    if (out/'protocol.json').exists():raise FileExistsError('Frozen protocol already exists')
    hashes={}
    for relative in SOURCES:
        dest=out/'source'/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/relative,dest)
        hashes[relative]=digest(dest)
    prep=read(args.preprocessing)
    states,actions,returns=load_data(args.dataset)
    order=np.random.default_rng(20261002).permutation(202)
    assert prep['discovery']==order[:141].tolist() and prep['validation']==order[141:].tolist()
    np.testing.assert_array_equal(returns,prep['trajectory_returns'])
    assert prep['high_return_threshold']==float(np.quantile(returns[order[:141]],.8))
    write(out/'preprocessing.json',prep)
    p=dict(rules=RULES,source_sha256=hashes,dataset=str(args.dataset.resolve()),
        dataset_sha256=digest(args.dataset),checkpoint=str(args.checkpoint.resolve()),
        checkpoint_sha256=digest(args.checkpoint),preprocessing_sha256=digest(out/'preprocessing.json'),
        created_unix=time.time(),no_training=True,no_interventions=True,
        offline_primary='validation subset high-return trajectories, H20; all 202 were DT training data',
        offline_history='ground-truth past actions; current action zero; last output of sliding context only',
        aggregation='window metric ratios/differences -> equal-window mean per trajectory/episode -> equal-unit mean',
        correlation_undefined='either thigh action temporal std < 1e-6; NaN retained and counted',
        rollout_reference='discovery high-return only; start-state/speed/time filters precede per-trajectory nearest selection',
        reference_correlation='need >=4 defined high-neighbor correlations; no reference-output pairing across different states for action MSE',
        bootstrap='10000 trajectory/episode resamples; fixed discovery reference; no-match episode excluded and reported',
        interpretation='Exploration noise may explain lower variation. Pattern loss is not proof of MSE averaging or chunk-policy gains.',
        wandb_entity='2820402607-shandong-university',wandb_project='CORL-DDR',
        wandb_group='DT-action-patterns-seed0-50k-20261002')
    write(out/'protocol.json',p)
    print(json.dumps(dict(prepared=str(out),protocol_sha256=digest(out/'protocol.json'))),flush=True)


def verify(out):
    p=read(out/'protocol.json')
    assert p['rules']==RULES
    for name,h in p['source_sha256'].items():assert digest(out/'source'/name)==h,name
    assert digest(__file__)==p['source_sha256'][SOURCES[0]],'Use frozen source'
    assert digest(p['dataset'])==p['dataset_sha256']
    assert digest(p['checkpoint'])==p['checkpoint_sha256']
    assert digest(out/'preprocessing.json')==p['preprocessing_sha256']
    return p


def model_digest(model):
    h=hashlib.sha256()
    for name,value in model.state_dict().items():
        h.update(name.encode());h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def setup_model(p,device):
    import torch
    import oracle_branching_dt as ob
    for name in ['oracle_branching_dt.py','dt.py']:
        assert digest(Path(ob.__file__).parent/name)==p['source_sha256']['algorithms/offline/'+name]
    torch.set_num_threads(2)
    torch.manual_seed(20261006)
    torch.backends.cudnn.benchmark=False
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    ckpt=torch.load(p['checkpoint'],map_location='cpu')
    assert ckpt['completed_updates']==50000 and ckpt['config']['arm']=='dt'
    assert ckpt['config']['train_seed']==0 and ckpt['config']['seq_len']==20
    model,config=ob.build_model(ckpt,device)
    runtime=dict(torch=torch.__version__,device=device,
        gpu=torch.cuda.get_device_name() if device.startswith('cuda') else None,
        slurm_job=os.environ.get('SLURM_JOB_ID'),started_unix=time.time())
    return torch,ob,ckpt,model,config,runtime


def predict_batch(torch,model,batch,device,all_outputs=False):
    tensors=[torch.as_tensor(x,device=device) for x in batch]
    result=model(*tensors).detach().cpu().numpy()
    return result if all_outputs else result[:,-1]


def audit_inference(torch,model,states,actions,targets,device):
    batch=pack_history(states,actions,targets,[0,1,2,3],[49]*4,20)
    full=predict_batch(torch,model,batch,device,True)
    rng=np.random.default_rng(20261006)
    altered=[a.copy() for a in batch]
    altered[1][:,5:]=rng.uniform(-1,1,altered[1][:,5:].shape)
    altered[0][:,6:]=rng.normal(size=altered[0][:,6:].shape)
    altered[2][:,6:]=0
    after=predict_batch(torch,model,altered,device,True)
    causal=float(np.max(np.abs(full[:,:6]-after[:,:6])))
    assert causal<=1e-6,causal
    errors=[]
    for step in [0,1,18,19,20,49,999]:
        count=202 if step<19 else 256
        batch=pack_history(states,actions,targets,np.arange(count)%202,np.full(count,step),min(20,step+1))
        together=predict_batch(torch,model,batch,device)
        selected=[0,1,count//2,count-1]
        alone=np.stack([predict_batch(torch,model,[a[i:i+1] for a in batch],device)[0] for i in selected])
        errors.append(float(np.max(np.abs(together[selected]-alone))))
    assert max(errors)<=2e-5,errors
    return dict(causal_current_future_max_error=causal,batch_vs_individual_max_error=max(errors),
                checked_steps=[0,1,18,19,20,49,999],passed=True)


def offline(args):
    if args.prepare_only:
        prepare(args);return
    out=args.output.resolve();p=verify(out)
    dest=out/'offline';dest.mkdir(exist_ok=True)
    if (dest/'audit.json').exists():raise FileExistsError('Offline stage already complete')
    torch,ob,ckpt,model,config,runtime=setup_model(p,args.device)
    write(dest/'runtime.json',runtime)
    before=model_digest(model)
    states,actions,totals=load_data(p['dataset'])
    flat=states[:,:1000].reshape(-1,17)
    np.testing.assert_allclose(flat.mean(0),np.asarray(ckpt['state_mean']).reshape(-1),rtol=0,atol=1e-6)
    np.testing.assert_allclose(flat.std(0)+1e-6,np.asarray(ckpt['state_std']).reshape(-1),rtol=0,atol=1e-6)
    states=((states[:,:1000]-np.asarray(ckpt['state_mean'],np.float32))/np.asarray(ckpt['state_std'],np.float32)).astype(np.float32)
    predictions={};checks={}
    with torch.inference_mode():
        for condition in RULES['conditions']:
            targets=(totals if condition=='actual_return' else np.full(202,12000.))*config['reward_scale']
            targets=targets.astype(np.float32)
            checks[condition]=audit_inference(torch,model,states,actions,targets,args.device)
            pred=np.full_like(actions,np.nan)
            for step in range(19):
                batch=pack_history(states,actions,targets,np.arange(202),np.full(202,step),step+1)
                pred[:,step]=predict_batch(torch,model,batch,args.device)
            total=202*981
            for start in range(0,total,256):
                flat=np.arange(start,min(start+256,total))
                ids,steps=flat//981,flat%981+19
                batch=pack_history(states,actions,targets,ids,steps,20)
                pred[ids,steps]=predict_batch(torch,model,batch,args.device)
                if start%(256*200)==0:
                    print(json.dumps(dict(stage='offline',condition=condition,completed_positions=start+len(flat)+202*19,
                        total_positions=202000,elapsed_seconds=time.time()-runtime['started_unix'])),flush=True)
            assert np.isfinite(pred).all()
            assert np.max(np.abs(pred))<=config['max_action']+1e-6
            predictions[condition]=pred
    np.savez_compressed(dest/'predictions.npz',**predictions)
    after=model_digest(model);assert after==before
    assert digest(p['checkpoint'])==p['checkpoint_sha256'] and digest(p['dataset'])==p['dataset_sha256']
    write(dest/'audit.json',dict(passed=True,model_before=before,model_after=after,
        protocol_sha256=digest(out/'protocol.json'),predictions_sha256=digest(dest/'predictions.npz'),
        checkpoint_unchanged=True,dataset_unchanged=True,checks=checks,trajectories=202,
        predictions_per_condition=202000,elapsed_seconds=time.time()-runtime['started_unix']))


def one_episode(torch,ob,model,config,ckpt,seed,device):
    import gym
    env=ob.wrap_env(gym.make(config['env_name']),ckpt['state_mean'],ckpt['state_std'],config['reward_scale'])
    env.seed(seed);env.action_space.seed(seed)
    first=env.reset()
    s,a,r,ts=ob.allocate_policy_tensors(model,12000*config['reward_scale'],first,device)
    raw_states=[np.asarray(env.unwrapped._get_obs()).copy()]
    actions=[];rewards=[]
    for step in range(1000):
        action=ob.predict_action(model,s,a,r,ts,step)
        next_state,reward,done,_=env.step(action)
        ob.update_policy_tensors(s,a,r,step,action,next_state,reward,'delayed')
        raw_states.append(np.asarray(env.unwrapped._get_obs()).copy())
        actions.append(action);rewards.append(float(reward)/config['reward_scale'])
        if done:break
    raw_return=float(np.sum(rewards,dtype=np.float64))
    result=dict(episode_seed=seed,length=len(actions),raw_return=raw_return,
                normalized_score=ob.normalized_score(env,raw_return))
    env.close()
    assert len(actions)==1000
    return np.asarray(raw_states),np.asarray(actions),np.asarray(rewards),result


def rollout(args):
    out=args.output.resolve();p=verify(out)
    offline_audit=read(out/'offline/audit.json');assert offline_audit['passed']
    dest=out/'rollout';dest.mkdir(exist_ok=True)
    if (dest/'audit.json').exists():raise FileExistsError('Rollout stage already complete')
    torch,ob,ckpt,model,config,runtime=setup_model(p,args.device)
    write(dest/'runtime.json',runtime)
    before=model_digest(model);assert before==offline_audit['model_before']
    episodes=[];hashes={};repeat=None
    with torch.inference_mode():
        for i in range(20):
            states,actions,rewards,info=one_episode(torch,ob,model,config,ckpt,535353+i,args.device)
            if i==0:
                s2,a2,r2,info2=one_episode(torch,ob,model,config,ckpt,535353,args.device)
                repeat=dict(state_max_error=float(np.max(np.abs(states-s2))),
                    action_max_error=float(np.max(np.abs(actions-a2))),
                    reward_max_error=float(np.max(np.abs(rewards-r2))),
                    score_error=abs(info['normalized_score']-info2['normalized_score']))
                assert max(repeat.values())<=1e-6,repeat
                write(dest/'repeat_audit.json',dict(passed=True,**repeat))
            filename=f'episode{i:02d}.npz'
            np.savez_compressed(dest/filename,states=states,actions=actions,rewards=rewards)
            hashes[filename]=digest(dest/filename)
            episodes.append(dict(episode=i,**info))
            write(dest/'episodes.json',episodes)
            print(json.dumps(dict(stage='rollout',episode=i,**info,
                elapsed_seconds=time.time()-runtime['started_unix'])),flush=True)
    after=model_digest(model);assert after==before
    assert digest(p['checkpoint'])==p['checkpoint_sha256'] and digest(p['dataset'])==p['dataset_sha256']
    write(dest/'audit.json',dict(passed=True,completed_episodes=20,episode_files=hashes,
        episodes_sha256=digest(dest/'episodes.json'),repeat=repeat,model_before=before,model_after=after,
        protocol_sha256=digest(out/'protocol.json'),no_interventions=True,no_training=True,
        checkpoint_unchanged=True,dataset_unchanged=True,elapsed_seconds=time.time()-runtime['started_unix']))


def add_paired_reference(unit,metrics):
    values=np.asarray(metrics).reshape(-1,len(METRICS))
    unit['paired_reference_corr']=finite_mean(values[np.isfinite(values[:,9]),8])
    return unit


def summarize(args):
    out=args.output.resolve();p=verify(out)
    prep=read(out/'preprocessing.json')
    oa,ra=read(out/'offline/audit.json'),read(out/'rollout/audit.json')
    assert oa['passed'] and ra['passed'] and ra['completed_episodes']==20
    for a in [oa,ra]:assert a['protocol_sha256']==digest(out/'protocol.json')
    assert digest(out/'offline/predictions.npz')==oa['predictions_sha256']
    assert digest(out/'rollout/episodes.json')==ra['episodes_sha256']
    for name,h in ra['episode_files'].items():assert digest(out/'rollout'/name)==h
    states,actions,totals=load_data(p['dataset'])
    with np.load(out/'offline/predictions.npz') as archive:
        predictions={condition:archive[condition] for condition in RULES['conditions']}
    discovery=np.asarray(prep['discovery']);validation=np.asarray(prep['validation'])
    high=totals>=prep['high_return_threshold']
    reference_ids=discovery[high[discovery]]
    mean,std=np.asarray(prep['state_mean']),np.asarray(prep['state_std'])
    reference_states=states[reference_ids]
    normalized=(reference_states-mean)/std
    groups={}
    for label,ids in [('discovery',discovery),('validation',validation),('all',np.arange(202))]:
        groups[label+'_high']=ids[high[ids]];groups[label+'_other']=ids[~high[ids]];groups[label+'_all']=ids
    summary=dict(offline={},rollout={},protocol_sha256=digest(out/'protocol.json'),no_training=True,
                 main_offline_group='validation_high',all_offline_trajectories_seen_during_training=True)
    records_dir=out/'statistics';records_dir.mkdir(exist_ok=True)
    for h in [20,50]:
        starts=np.arange(0,1001-h,h)
        data_features=np.stack([action_features(a,h) for a in actions])
        for condition in RULES['conditions']:
            units=[];window_rows=[]
            for tid in range(202):
                pred=predictions[condition][tid]
                pred_features=action_features(pred,h)
                rows=[]
                for step in starts:
                    mse=float(np.mean((pred[step:step+h]-actions[tid,step:step+h])**2))
                    row=window_metrics(pred_features[step],data_features[tid,step],mse)
                    rows.append(row);window_rows.append(row)
                unit=aggregate_unit(tid,rows);units.append(add_paired_reference(unit,rows))
            write(records_dir/f'offline_{condition}_h{h}_units.json',units)
            np.savez_compressed(records_dir/f'offline_{condition}_h{h}_windows.npz',
                trajectory_ids=np.repeat(np.arange(202),len(starts)),steps=np.tile(starts,202),
                metrics=np.asarray(window_rows),metric_names=np.asarray(METRICS))
            summary['offline'].setdefault(condition,{})[str(h)]={group:bootstrap_units([units[i] for i in ids])
                                                               for group,ids in groups.items()}
        rollout_units=[];queries=[];window_rows=[];neighbor_records=[];balances=[]
        for ep in range(20):
            saved=np.load(out/'rollout'/f'episode{ep:02d}.npz')
            s,a=saved['states'],saved['actions']
            feats=action_features(a,h)
            rows=[]
            for step in starts:
                ids,times,dist=select_neighbors(reference_states,normalized,reference_ids,s[step],mean,std,int(step),h)
                assert len(ids)==len(set(ids)) and set(ids)<=set(reference_ids)
                if len(ids):
                    assert np.all(np.abs(states[ids,times,8]-s[step,8])<=.25)
                    assert np.all(np.abs(times-step)<=5) and np.all(times+h<=1000)
                reason='supported' if len(ids)>=4 else 'fewer_than_four_high_neighbors'
                queries.append(dict(episode=ep,step=int(step),neighbors=len(ids),reason=reason))
                if len(ids)<4:continue
                neighbor_features=data_features[ids,times]
                ref=np.asarray([neighbor_features[:,0].mean(),neighbor_features[:,1].mean(),np.nan])
                defined=np.isfinite(neighbor_features[:,2])
                if defined.sum()>=4:ref[2]=neighbor_features[defined,2].mean()
                row=window_metrics(feats[step],ref)
                rows.append(row);window_rows.append([ep,int(step),*row])
                neighbor_records.append(dict(episode=ep,step=int(step),trajectory_ids=ids.tolist(),
                    steps=times.tolist(),state_rmse=dist.tolist(),defined_reference_corr=int(defined.sum())))
                balance=dict(episode=ep,step=int(step),speed_difference=float(s[step,8]-states[ids,times,8].mean()),
                    pitch_difference=float(s[step,1]-states[ids,times,1].mean()),
                    normalized_state_difference=((s[step]-states[ids,times].mean(0))/std).tolist())
                balances.append(balance)
            rollout_units.append(add_paired_reference(aggregate_unit(ep,rows),rows))
        write(records_dir/f'rollout_h{h}_units.json',rollout_units)
        write(records_dir/f'rollout_h{h}_queries.json',queries)
        write(records_dir/f'rollout_h{h}_neighbors.json',neighbor_records)
        write(records_dir/f'rollout_h{h}_balance.json',balances)
        np.savez_compressed(records_dir/f'rollout_h{h}_windows.npz',
            values=np.asarray(window_rows,dtype=float).reshape(-1,len(METRICS)+2),
            columns=np.asarray(['episode','step',*METRICS]))
        included=[u for u in rollout_units if u['windows']>0]
        support=len(included)>=10 and len(window_rows)>=RULES['min_supported_windows'][str(h)]
        stats=bootstrap_units(included,support)
        stats.update(supported_episodes=len(included),supported_windows=len(window_rows),total_windows=20*len(starts),
                     missing_episode_ids=[u['id'] for u in rollout_units if not u['windows']],
                     exclusion_counts=dict(Counter(q['reason'] for q in queries)),
                     mean_start_speed_difference=finite_mean([b['speed_difference'] for b in balances]),
                     mean_start_pitch_difference=finite_mean([b['pitch_difference'] for b in balances]))
        summary['rollout'][str(h)]=stats
    actual=summary['offline']['actual_return']['20']['validation_high']
    deploy=summary['offline']['rtg12000']['20']['validation_high']
    live=summary['rollout']['20']
    interpretations={}
    for flag,support_key in [('change_compressed','change_metric_supported'),
                              ('negative_correlation_weakened','correlation_metric_supported')]:
        if not actual[support_key] or not deploy[support_key] or not live[support_key]:
            value='insufficient_support_for_full_comparison'
        elif not actual[flag] and deploy[flag]:value='condition_dependence_candidate'
        elif actual[flag] and deploy[flag] and live[flag]:value='reproduction_gap_in_offline_and_rollout'
        elif not actual[flag] and not deploy[flag] and live[flag]:value='execution_distribution_shift_candidate'
        elif not actual[flag] and not deploy[flag] and not live[flag]:value='no_predefined_gap_detected'
        else:value='mixed_pattern_across_conditions_or_execution'
        interpretations[flag]=value
    summary['interpretation']=interpretations
    summary['episodes']=read(out/'rollout/episodes.json')
    summary['audit']=dict(passed=True,offline=oa,rollout=ra)
    write(out/'summary.json',summary)
    names=['summary.json','offline/audit.json','offline/predictions.npz','rollout/audit.json','rollout/episodes.json']
    names += [str(f.relative_to(out)) for f in records_dir.iterdir() if f.is_file()]
    write(out/'result_manifest.json',{name:digest(out/name) for name in names})
    print(json.dumps(dict(interpretation=interpretations,rollout_h20=live)),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['offline','rollout','summarize'])
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--dataset',type=Path,default=DATA)
    parser.add_argument('--checkpoint',type=Path,default=CHECKPOINT)
    parser.add_argument('--preprocessing',type=Path,default=PREPROCESSING)
    parser.add_argument('--prepare-only',action='store_true')
    parser.add_argument('--device',default='cuda:0')
    args=parser.parse_args()
    if args.prepare_only and args.mode!='offline':parser.error('--prepare-only requires offline')
    globals()[args.mode](args)
