"""Offline action consensus and frozen-DT single-action branching; no training.

The analyze path imports only NumPy/h5py. Discovery data alone define neighbors,
normalization, return labels and selection rules. Simulator outcomes are read
only by summarize, never by the candidate selector.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import shutil
import time

import h5py
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
DATASET = Path('/labmount/users/202615385/.d4rl/datasets/halfcheetah_medium_replay-v2.hdf5')
CHECKPOINT = ROOT / 'results/threshold-dt-seed0-3090-20261001/pilot/seed0/dt/step050000.pt'
RULES = dict(split_seed=20261002, discovery_count=141, trajectory_count=202,
             episode_length=1000, high_quantile=.8, state_radius=.5,
             time_radius=5, max_neighbors=32, min_neighbors=12,
             min_high=4, min_other=4, query_start=20, query_end=945,
             offline_query_stride=5, disagreement_quantile=.75,
             action_radius=.25, min_cluster_high=3, min_high_fraction=.6,
             min_fraction_gap=.3, min_displacement=.05, max_displacement=.25,
             episode_seed=424242, episodes=20, bin_width=100,
             random_seed=20261003, random_attempts=256, target_return=12000.,
             bootstrap_seed=20261004, bootstrap_reps=10000,
             min_branch_positions=40, min_branch_episodes=10,
             min_score_gain=.1, restore_tolerance=1e-6)
SOURCES = ('algorithms/offline/action_consensus_diagnostic.py',
           'algorithms/offline/oracle_branching_dt.py', 'algorithms/offline/dt.py',
           'scripts/dt_experiments/run_action_consensus.sbatch')


def write(path, obj):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def read(path):
    return json.loads(Path(path).read_text())


def file_hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def append(path, obj):
    with open(path, 'a') as f:
        f.write(json.dumps(obj, allow_nan=False) + '\n')
        f.flush()
        os.fsync(f.fileno())


def load_dataset(path):
    # Dense rewards are reduced once to terminal totals, then discarded.
    with h5py.File(path, 'r') as f:
        obs, act = f['observations'][:], f['actions'][:]
        ends = np.flatnonzero(f['terminals'][:] | f['timeouts'][:])
        rewards = f['rewards'][:]
    starts = np.r_[0, ends[:-1] + 1]
    lengths = ends - starts + 1
    if len(ends) != RULES['trajectory_count'] or not np.all(lengths == 1000):
        raise ValueError('Expected exactly 202 complete 1000-step trajectories')
    totals = np.array([rewards[s:e + 1].astype(np.float32).sum()
                       for s, e in zip(starts, ends)], dtype=np.float64)
    states = np.stack([obs[s:e + 1] for s, e in zip(starts, ends)])
    actions = np.stack([act[s:e + 1] for s, e in zip(starts, ends)])
    if states.shape != (202, 1000, 17) or actions.shape != (202, 1000, 6):
        raise ValueError('Unexpected state/action shape')
    if not all(np.isfinite(x).all() for x in (states, actions, totals)):
        raise ValueError('Nonfinite offline inputs')
    return states, actions, totals, dict(bounds=np.stack([starts, ends], 1).tolist(),
                                       incomplete_tail_steps=int(len(obs) - ends[-1] - 1))


class DiscoveryIndex:
    def __init__(self, states, actions, totals, discovery, mean=None, std=None, high=None):
        self.ids = np.asarray(discovery, dtype=np.int64)
        data = states[self.ids]
        self.mean = data.reshape(-1, data.shape[-1]).mean(0) if mean is None else np.asarray(mean)
        self.std = data.reshape(-1, data.shape[-1]).std(0) + 1e-6 if std is None else np.asarray(std)
        self.states = (data - self.mean) / self.std
        self.actions = actions[self.ids]
        self.totals = totals[self.ids]
        self.high_threshold = float(np.quantile(self.totals, .8)) if high is None else high
        self.high = self.totals >= self.high_threshold

    def neighbors(self, raw_state, step, exclude=-1):
        lo, hi = max(0, step - 5), min(self.states.shape[1], step + 6)
        q = (np.asarray(raw_state) - self.mean) / self.std
        distances = np.mean((self.states[:, lo:hi] - q) ** 2, axis=-1)
        times = distances.argmin(1)
        closest = np.sqrt(distances[np.arange(len(self.ids)), times])
        eligible = np.flatnonzero((closest <= .5) & (self.ids != exclude))
        # Deterministic distance, trajectory-id tie breaking; one vote/trajectory.
        order = np.lexsort((self.ids[eligible], closest[eligible]))[:32]
        local = eligible[order]
        steps = times[local] + lo
        return dict(ids=self.ids[local], steps=steps, distances=closest[local],
                    actions=self.actions[local, steps], high=self.high[local],
                    totals=self.totals[local])


def describe(neighbors):
    n, h = len(neighbors['ids']), int(neighbors['high'].sum())
    row = dict(neighbors=n, high=h, other=n - h, supported=False, variance=None,
               medoid_trajectory=None, medoid_step=None, cluster_high=0,
               high_fraction=0., other_fraction=0., reason='insufficient_neighbors')
    if n < 12:
        return row
    if h < 4:
        row['reason'] = 'insufficient_high'
        return row
    if n - h < 4:
        row['reason'] = 'insufficient_other'
        return row
    a, mask = neighbors['actions'], neighbors['high']
    high_positions = np.flatnonzero(mask)
    ah = a[mask]
    cost = np.mean((ah[:, None] - ah[None, :]) ** 2, axis=(1, 2))
    order = np.lexsort((neighbors['steps'][high_positions],
                        neighbors['ids'][high_positions], cost))
    medoid = high_positions[order[0]]
    cluster = np.sqrt(np.mean((a - a[medoid]) ** 2, axis=-1)) <= .25
    row.update(supported=True, variance=float(a.var(0).mean()),
               medoid_trajectory=int(neighbors['ids'][medoid]),
               medoid_step=int(neighbors['steps'][medoid]),
               medoid_action=a[medoid].tolist(),
               cluster_high=int((cluster & mask).sum()),
               high_fraction=float(cluster[mask].mean()),
               other_fraction=float(cluster[~mask].mean()), reason='supported')
    return row


def candidate_reason(row, cutoff):
    if not row['supported']:
        return row['reason']
    if row['variance'] < cutoff:
        return 'low_disagreement'
    if row['cluster_high'] < 3:
        return 'cluster_high_below_3'
    if row['high_fraction'] < .6:
        return 'high_fraction_below_0.6'
    if row['high_fraction'] - row['other_fraction'] < .3:
        return 'fraction_gap_below_0.3'
    return 'candidate'


def proportions(neighbors, actual_action):
    high = neighbors['high']
    cluster = np.sqrt(np.mean((neighbors['actions'] - actual_action) ** 2, -1)) <= .25
    return ((float(high.sum()) + 1) / (len(high) + 2),
            (float(high[cluster].sum()) + 1) / (int(cluster.sum()) + 2),
            int(cluster.sum()))


def bootstrap(values):
    values = np.asarray(values, np.float64)
    if not len(values):
        return dict(mean=None, ci95=None, units=0)
    rng = np.random.default_rng(RULES['bootstrap_seed'])
    means = values[rng.integers(len(values), size=(10000, len(values)))].mean(1)
    return dict(mean=float(values.mean()), ci95=np.quantile(means, [.025, .975]).tolist(),
                units=len(values))


def freeze(args):
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'protocol.json').exists():
        raise FileExistsError('Use a fresh output directory; frozen protocols are never overwritten')
    hashes = {}
    for relative in SOURCES:
        source = ROOT / relative
        dest = out / 'source' / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
        hashes[relative] = file_hash(dest)
    protocol = dict(rules=RULES, source_sha256=hashes, dataset=str(args.dataset.resolve()),
                    dataset_sha256=file_hash(args.dataset), checkpoint=str(args.checkpoint.resolve()),
                    checkpoint_sha256=file_hash(args.checkpoint),
                    validation_reference='discovery trajectories only',
                    validation_primary='all supported validation queries; trajectory-balanced Brier',
                    validation_subgroups=['high_disagreement', 'consensus_candidates'],
                    validation_missing='exclude trajectories without supported queries; report count',
                    branch_query_stride=1, branch_query_range=[20, 945],
                    offline_rewards='float32 terminal total, matching delayed DT preprocessing',
                    tie_break='distance/cost then original trajectory id then timestep',
                    zero_intervention_episodes='included with zero gain in all 20 episode means',
                    no_training=True, no_branch_outcomes_in_selection=True,
                    wandb_entity='2820402607-shandong-university', wandb_project='CORL-DDR',
                    wandb_group='Action-consensus-HCMR-delayed-seed0-20261002',
                    created_unix=time.time())
    write(out / 'protocol.json', protocol)
    return out, protocol


def verify(out, analysis=True):
    p = read(out / 'protocol.json')
    if p['rules'] != RULES:
        raise AssertionError('Rules differ from frozen protocol')
    for relative, digest in p['source_sha256'].items():
        if file_hash(out / 'source' / relative) != digest:
            raise AssertionError('Frozen source changed: ' + relative)
    if file_hash(__file__) != p['source_sha256'][SOURCES[0]]:
        raise AssertionError('Run the frozen diagnostic source')
    if file_hash(p['dataset']) != p['dataset_sha256']:
        raise AssertionError('Dataset changed')
    if file_hash(p['checkpoint']) != p['checkpoint_sha256']:
        raise AssertionError('Checkpoint changed')
    if analysis:
        manifest = read(out / 'analysis_manifest.json')
        for name, digest in manifest.items():
            if file_hash(out / name) != digest:
                raise AssertionError('Offline analysis changed: ' + name)
    return p


def analyze(args):
    started = time.time()
    out, protocol = freeze(args)
    states, actions, totals, bounds = load_dataset(args.dataset)
    order = np.random.default_rng(20261002).permutation(202)
    discovery, validation = order[:141], order[141:]
    assert not set(discovery) & set(validation)
    index = DiscoveryIndex(states, actions, totals, discovery)
    preprocessing = dict(discovery=discovery.tolist(), validation=validation.tolist(),
                         state_mean=index.mean.tolist(), state_std=index.std.tolist(),
                         high_return_threshold=index.high_threshold,
                         trajectory_returns=totals.tolist(), **bounds)
    write(out / 'preprocessing.json', preprocessing)
    rows, archives = [], []
    for split, ids in [('discovery', discovery), ('validation', validation)]:
        for sequence, trajectory in enumerate(ids):
            for step in range(20, 946, 5):
                nb = index.neighbors(states[trajectory, step], step, int(trajectory))
                row = describe(nb)
                assert len(nb['ids']) == len(set(nb['ids']))
                assert trajectory not in nb['ids'] and set(nb['ids']) <= set(discovery)
                row.update(split=split, trajectory=int(trajectory), step=step)
                if row['supported']:
                    assert np.array_equal(actions[row['medoid_trajectory'], row['medoid_step']],
                                          np.asarray(row['medoid_action'], dtype=actions.dtype))
                    if split == 'validation':
                        ps, pa, count = proportions(nb, actions[trajectory, step])
                        y = int(totals[trajectory] >= index.high_threshold)
                        row.update(state_probability=ps, action_probability=pa,
                                   action_neighbors=count, high_label=y,
                                   state_brier=(ps-y)**2, action_brier=(pa-y)**2)
                rows.append(row)
                archives.append((nb['ids'], nb['steps'], nb['distances']))
            if sequence % 20 == 0:
                print(json.dumps(dict(stage='analyze', split=split, completed_trajectories=sequence+1,
                                      elapsed_seconds=time.time()-started)), flush=True)
    variances = [r['variance'] for r in rows if r['split']=='discovery' and r['supported']]
    if not variances:
        raise ValueError('No supported discovery queries; cannot define disagreement cutoff')
    cutoff = float(np.quantile(variances, .75))
    for row in rows:
        row['reason'] = candidate_reason(row, cutoff)
    # Aligned compressed arrays retain all distinct neighbors, including rejected queries.
    ids = np.full((len(rows), 32), -1, np.int16)
    steps = np.full_like(ids, -1)
    distances = np.full((len(rows), 32), np.nan, np.float32)
    for i, (ni, nt, nd) in enumerate(archives):
        ids[i, :len(ni)], steps[i, :len(nt)], distances[i, :len(nd)] = ni, nt, nd
    np.savez_compressed(out / 'neighbors.npz', trajectory_ids=ids, steps=steps, state_rmse=distances)
    with open(out / 'queries.jsonl', 'w') as f, open(out / 'candidates.jsonl', 'w') as candidates:
        for row in rows:
            line = json.dumps(row, allow_nan=False) + '\n'
            f.write(line)
            if row['reason'] == 'candidate':
                candidates.write(line)
    validation_stats = {}
    for label in ['all_supported', 'high_disagreement', 'consensus_candidates']:
        filtered = [r for r in rows if r['split']=='validation' and r['supported']
                    and (label=='all_supported' or r['variance'] >= cutoff)
                    and (label!='consensus_candidates' or r['reason']=='candidate')]
        trajectories = []
        for tid in validation:
            local = [r for r in filtered if r['trajectory']==tid]
            if local:
                bs = float(np.mean([r['state_brier'] for r in local]))
                ba = float(np.mean([r['action_brier'] for r in local]))
                trajectories.append(dict(trajectory=int(tid), queries=len(local), state_brier=bs,
                                         action_brier=ba, improvement=bs-ba))
        validation_stats[label] = dict(queries=len(filtered), trajectories=trajectories,
            missing_trajectories=61-len(trajectories),
            empty_action_neighborhoods=sum(r['action_neighbors']==0 for r in filtered),
            improvement=bootstrap([r['improvement'] for r in trajectories]),
            state_brier=float(np.mean([r['state_brier'] for r in trajectories])) if trajectories else None,
            action_brier=float(np.mean([r['action_brier'] for r in trajectories])) if trajectories else None)
    stats = dict(disagreement_cutoff=cutoff, high_return_threshold=index.high_threshold,
                 discovery_high=int(index.high.sum()),
                 validation_high=int((totals[validation]>=index.high_threshold).sum()),
                 counts={s: dict(Counter(r['reason'] for r in rows if r['split']==s))
                         for s in ['discovery','validation']}, validation=validation_stats,
                 audit=dict(split_disjoint=True, discovery_only_neighbors=True,
                            one_vote_per_trajectory=True, recorded_medoid_provenance=True,
                            no_simulator_import=True), elapsed_seconds=time.time()-started)
    write(out / 'analysis.json', stats)
    names = ['preprocessing.json','queries.jsonl','candidates.jsonl','neighbors.npz','analysis.json']
    write(out / 'analysis_manifest.json', {name: file_hash(out/name) for name in names})
    print(json.dumps({k:v for k,v in stats.items() if k!='validation'}), flush=True)
    print(json.dumps(validation_stats['all_supported']['improvement']), flush=True)


def controls(row, nb, original, low, high, seed, step):
    """Pure selection: offline neighbors, DT action and private RNG; no branch outcomes."""
    consensus = np.asarray(row['medoid_action'], np.float32)
    displacement = float(np.sqrt(np.mean((consensus-original)**2)))
    if not .05 <= displacement <= .25:
        return None, 'consensus_displacement_outside_range'
    dist = np.sqrt(np.mean((nb['actions']-original)**2, axis=-1))
    valid = np.flatnonzero(nb['high'] & (dist>=.05) & (dist<=.25))
    if not len(valid):
        return None, 'no_distance_matched_high_neighbor'
    nearest = int(valid[0])  # neighbors already ordered by state distance
    rng = np.random.default_rng(np.random.SeedSequence([RULES['random_seed'], seed, step]))
    delta_norm = np.linalg.norm(consensus-original)
    for attempt in range(256):
        direction = rng.normal(size=original.shape)
        norm = np.linalg.norm(direction)
        if norm == 0:
            continue
        random_action = (original + delta_norm * direction/norm).astype(np.float32)
        if np.all(random_action >= low) and np.all(random_action <= high):
            break
    else:
        return None, 'random_control_out_of_bounds_256_attempts'
    result = dict(actions=dict(dt=original.tolist(), consensus=consensus.tolist(),
                               nearest_high=nb['actions'][nearest].tolist(),
                               random=random_action.tolist()),
                  consensus_displacement=displacement,
                  nearest_displacement=float(dist[nearest]),
                  random_displacement=float(np.sqrt(np.mean((random_action-original)**2))),
                  random_attempts=attempt+1, nearest_trajectory=int(nb['ids'][nearest]),
                  nearest_step=int(nb['steps'][nearest]))
    for action in result['actions'].values():
        assert np.all(np.asarray(action)>=low) and np.all(np.asarray(action)<=high)
    assert abs(result['random_displacement']-displacement) < 1e-6
    return result, 'selected'


def model_hash(model):
    h = hashlib.sha256()
    for key, value in model.state_dict().items():
        h.update(key.encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def global_rng():
    import random
    import torch
    return (random.getstate(), np.random.get_state(), torch.get_rng_state(),
            torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [])


def restore_global_rng(state):
    import random
    import torch
    random.setstate(state[0])
    np.random.set_state(state[1])
    torch.set_rng_state(state[2])
    if state[3]:
        torch.cuda.set_rng_state_all(state[3])


def branch(args):
    out = args.output.resolve()
    protocol = verify(out)
    import torch
    import gym
    import oracle_branching_dt as ob
    for name in ['oracle_branching_dt.py', 'dt.py']:
        if file_hash(Path(ob.__file__).parent / name) != protocol['source_sha256']['algorithms/offline/'+name]:
            raise AssertionError('Imported helper differs from frozen source')
    torch.set_num_threads(2)
    torch.manual_seed(20261002)
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True)
    ckpt = torch.load(protocol['checkpoint'], map_location='cpu')
    if ckpt['completed_updates'] != 50000 or ckpt['config']['arm'] != 'dt':
        raise AssertionError('Expected ordinary DT, 50k')
    model, config = ob.build_model(ckpt, args.device)
    before = model_hash(model)
    env = ob.wrap_env(gym.make(config['env_name']), ckpt['state_mean'], ckpt['state_std'],
                      config['reward_scale'])
    scale = config['reward_scale']
    prep, analysis = read(out/'preprocessing.json'), read(out/'analysis.json')
    states_data, actions_data, totals, _ = load_dataset(protocol['dataset'])
    index = DiscoveryIndex(states_data, actions_data, totals, prep['discovery'],
                           np.array(prep['state_mean'], np.float32),
                           np.array(prep['state_std'], np.float32), prep['high_return_threshold'])
    dest = out / ('smoke' if args.smoke else 'branch')
    dest.mkdir(exist_ok=True)
    if (dest/'audit.json').exists():
        raise FileExistsError('Completed branch result exists')
    if not args.smoke:
        smoke = read(out/'smoke/audit.json')
        if not smoke['passed'] or smoke['protocol_sha256'] != file_hash(out/'protocol.json'):
            raise AssertionError('Matching restoration smoke required before formal episodes')
    runtime = dict(device=args.device, gpu=torch.cuda.get_device_name() if 'cuda' in args.device else None,
                   torch=torch.__version__, slurm_job=os.environ.get('SLURM_JOB_ID'),
                   model_before=before, started_unix=time.time(), smoke=args.smoke)
    write(dest/'runtime.json', runtime)
    episode_count = 1 if args.smoke else 20
    audits = []
    with torch.inference_mode():
        for episode in range(episode_count):
            seed = 424241 if args.smoke else 424242+episode
            epdir = dest / f'episode{episode:02d}'
            epdir.mkdir(exist_ok=True)
            if (epdir/'result.json').exists():
                audits.append(read(epdir/'result.json'))
                continue
            # Interrupted incomplete episodes are replayed deterministically from reset.
            for name in ['queries.jsonl','selections.jsonl','branches.jsonl']:
                (epdir/name).write_text('')
            env.seed(seed)
            env.action_space.seed(seed)
            state = env.reset()
            s, a, r, ts = ob.allocate_policy_tensors(model, 12000*scale, state, args.device)
            prefix, anchors, used_bins, rejection = 0., [], set(), Counter()
            for step in range(model.episode_len):
                original = ob.predict_action(model,s,a,r,ts,step)
                selected = None
                if args.smoke and step == 500:
                    selected = dict(actions={'dt':original.tolist()})
                elif not args.smoke and 20 <= step <= 945 and step//100 not in used_bins:
                    raw_state = np.asarray(env.unwrapped._get_obs()).copy()
                    nb = index.neighbors(raw_state, step)
                    row = describe(nb)
                    reason = candidate_reason(row, analysis['disagreement_cutoff'])
                    if reason == 'candidate':
                        selected, reason = controls(row, nb, original, env.action_space.low,
                                                    env.action_space.high, seed, step)
                    row.update(step=step, reason=reason)
                    rejection[reason] += 1
                    append(epdir/'queries.jsonl', row)
                    if selected is not None:
                        selected.update(neighborhood=row, neighbor_ids=nb['ids'].tolist(),
                                        neighbor_steps=nb['steps'].tolist(),
                                        neighbor_state_rmse=nb['distances'].tolist(),
                                        raw_state=raw_state.tolist())
                        assert np.array_equal(actions_data[row['medoid_trajectory'],row['medoid_step']],
                                              np.asarray(selected['actions']['consensus'],np.float32))
                if selected is not None:
                    used_bins.add(step//100)
                    selected.update(episode=episode, episode_seed=seed, step=step)
                    # This append is durably written before any branch outcome exists.
                    append(epdir/'selections.jsonl', selected)
                    anchors.append((selected, ob.capture_env_snapshot(env),
                                    ob.PolicySnapshot(s.clone(),a.clone(),r.clone(),prefix,step),
                                    global_rng()))
                next_state, reward, done, _ = env.step(original)
                ob.update_policy_tensors(s,a,r,step,original,next_state,reward,'delayed')
                prefix += float(reward)
                if done:
                    break
            base_score = ob.normalized_score(env,prefix/scale)
            selection_hash = file_hash(epdir/'selections.jsonl')
            write(epdir/'baseline.json',dict(raw_return=prefix/scale, normalized_score=base_score,
                                           length=step+1, selections_sha256=selection_hash))
            max_error, records = 0., []
            for selected, snapshot, history, rng in anchors:
                scores = {}
                for method, action in selected['actions'].items():
                    restore_global_rng(rng)
                    result = ob.branch_rollout(env=env,env_snapshot=snapshot,policy_snapshot=history,
                        first_action=np.asarray(action,np.float32),model=model,time_steps=ts,
                        reward_scale=scale,reward_mode='delayed')
                    scores[method] = dict(raw_return=result.full_raw_return,
                                          normalized_score=result.normalized_score,
                                          length=result.episode_length)
                error = abs(scores['dt']['normalized_score']-base_score)
                max_error = max(max_error,error)
                if error > 1e-6:
                    raise AssertionError(f'Original branch restoration error {error} > 1e-6')
                record = dict(episode=episode,episode_seed=seed,step=selected['step'],
                              scores=scores,baseline_error=error,selections_sha256=selection_hash)
                append(epdir/'branches.jsonl',record)
                records.append(record)
            assert selection_hash == file_hash(epdir/'selections.jsonl')
            assert before == model_hash(model)
            result = dict(episode=episode,episode_seed=seed,positions=len(records),
                          baseline_score=base_score,restoration_max_error=max_error,
                          rejection_counts=dict(rejection),model_unchanged=True,
                          selections_sha256=selection_hash,
                          branches_sha256=file_hash(epdir/'branches.jsonl'))
            write(epdir/'result.json', result)
            audits.append(result)
            print(json.dumps(dict(stage='smoke' if args.smoke else 'branch', **result,
                                  elapsed_seconds=time.time()-runtime['started_unix'])),flush=True)
    env.close()
    assert model_hash(model)==before and file_hash(protocol['checkpoint'])==protocol['checkpoint_sha256']
    audit = dict(passed=True,episodes=audits,model_before=before,model_after=model_hash(model),
                 protocol_sha256=file_hash(out/'protocol.json'),
                 analysis_manifest_sha256=file_hash(out/'analysis_manifest.json'),
                 checkpoint_unchanged=True,no_training=True,
                 completed_episodes=len(audits),elapsed_seconds=time.time()-runtime['started_unix'])
    if args.smoke and audits[0]['positions'] != 1:
        raise AssertionError('Smoke must actually test restoration')
    write(dest/'audit.json',audit)


def summarize(args):
    out = args.output.resolve()
    protocol = verify(out)
    analysis = read(out/'analysis.json')
    audit = read(out/'branch/audit.json')
    if not audit['passed'] or audit['completed_episodes'] != 20:
        raise AssertionError('Require all 20 completed episodes')
    if audit['protocol_sha256'] != file_hash(out/'protocol.json'):
        raise AssertionError('Branch protocol mismatch')
    if audit['analysis_manifest_sha256'] != file_hash(out/'analysis_manifest.json'):
        raise AssertionError('Branch analysis mismatch')
    rows, episodes, selections = [], [], []
    for i in range(20):
        epdir = out/'branch'/f'episode{i:02d}'
        ep = read(epdir/'result.json')
        if ep['episode_seed'] != 424242+i or ep['restoration_max_error'] > 1e-6:
            raise AssertionError('Seed/restoration audit failed')
        for name, key in [('selections.jsonl','selections_sha256'),('branches.jsonl','branches_sha256')]:
            if file_hash(epdir/name) != ep[key]:
                raise AssertionError('Branch evidence changed')
        selected = [json.loads(x) for x in (epdir/'selections.jsonl').read_text().splitlines()]
        local = [json.loads(x) for x in (epdir/'branches.jsonl').read_text().splitlines()]
        if len(local) != ep['positions'] or len(local) != len(selected):
            raise AssertionError('Incomplete positions')
        selections.extend(selected)
        rows.extend(local)
        for control in ['dt','random','nearest_high']:
            gains = [r['scores']['consensus']['normalized_score']-r['scores'][control]['normalized_score']
                     for r in local]
            ep['consensus_minus_'+control] = float(np.mean(gains)) if gains else 0.
        episodes.append(ep)
    comparisons = {c:bootstrap([e['consensus_minus_'+c] for e in episodes])
                   for c in ['dt','random','nearest_high']}
    support_episodes = sum(e['positions']>0 for e in episodes)
    supported = support_episodes>=10 and len(rows)>=40
    improvement = analysis['validation']['all_supported']['improvement']
    offline_positive = improvement['mean'] is not None and improvement['mean']>0
    branch_positive = all(comparisons[c]['mean']>=.1 and comparisons[c]['ci95'][0]>0
                          for c in ['dt','random'])
    useful = supported and offline_positive and branch_positive
    result = dict(positions=len(rows),episodes_with_positions=support_episodes,episodes=episodes,
                  support_sufficient=supported,offline_action_improves_prediction=offline_positive,
                  branch_signal_passed=branch_positive,preliminary_useful_signal=useful,
                  consensus_beats_nearest_mean=comparisons['nearest_high']['mean']>0,
                  comparisons=comparisons,validation_brier=analysis['validation'],
                  decision='preliminary_signal' if useful else ('insufficient_support' if not supported else 'screen_failed'),
                  audit_passed=True,no_training=True,
                  coverage=dict(selected_positions=len(rows),total_baseline_steps=20000,
                                candidate_queries=sum(e['rejection_counts'].get('selected',0)+
                                    e['rejection_counts'].get('consensus_displacement_outside_range',0)+
                                    e['rejection_counts'].get('no_distance_matched_high_neighbor',0)+
                                    e['rejection_counts'].get('random_control_out_of_bounds_256_attempts',0)
                                    for e in episodes),
                                queried_positions=sum(sum(e['rejection_counts'].values()) for e in episodes)),
                  displacement_mean=float(np.mean([s['consensus_displacement'] for s in selections])) if selections else None,
                  independent_neighbor_support_mean=float(np.mean([s['neighborhood']['neighbors'] for s in selections])) if selections else None)
    write(out/'summary.json',result)
    lines = ['# 动作共识可行性诊断', '',
             '冻结普通 DT seed 0 / 50k，RTG=12000；只做离线分析与单步动作替换，没有训练。', '',
             f"- 发现集/验证集：141/61 条；高回报门槛 {analysis['high_return_threshold']:.6f}；分歧门槛 {analysis['disagreement_cutoff']:.6f}。",
             f"- 离线候选：发现集 {analysis['counts']['discovery'].get('candidate',0)}/26226，验证集 {analysis['counts']['validation'].get('candidate',0)}/11346。",
             f"- 验证集 Brier 改善（状态减状态+动作，正值较好）：{improvement['mean']}，轨迹 bootstrap 95% CI={improvement['ci95']}。",
             f"- 分支覆盖：{len(rows)} 个位置，{support_episodes}/20 个 episode；支持量达标：{supported}。", '',
             '| 共识相对对照 | episode 均衡 normalized-score 差值 | 95% CI |',
             '|---|---:|---|']
    for c, v in comparisons.items():
        lines.append(f"| {c} | {v['mean']:+.6f} | [{v['ci95'][0]:+.6f}, {v['ci95'][1]:+.6f}] |")
    lines += ['',f"筛选结论：{result['decision']}。没有合格位置的 episode 以零干预收益进入全部 20 条的统计。",
              '仅评价冻结 DT 下这些位置的单步替换；不将轨迹关联解释为普遍关键动作，不生成 AWR 权重。',
              '验证主指标为所有受支持验证查询；高分歧区域和共识区域分别作为子组保存。',
              '分支前所有本 episode 动作选择已写盘并校验哈希；原动作恢复误差 ≤1e-6，模型权重未变。']
    (out/'report_zh.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['episodes','validation_brier']}),flush=True)
    if args.upload:
        upload(out,protocol,result,rows)


def upload(out, protocol, result, branches):
    import wandb
    entity, project = protocol['wandb_entity'], protocol['wandb_project']
    api = wandb.Api(timeout=45)
    if api.default_entity != entity:
        raise AssertionError('Unexpected W&B account')
    api.project(project,entity=entity)
    runid = hashlib.sha256(file_hash(out/'protocol.json').encode()).hexdigest()[:16]
    dest = out/'wandb_upload'
    dest.mkdir(exist_ok=True)
    if (dest/'verification.json').exists():
        remote = api.run(f'{entity}/{project}/{runid}')
        if remote.summary.get('diagnostic/complete'):
            print('Already uploaded: '+remote.url,flush=True)
            return
    run = wandb.init(entity=entity,project=project,group=protocol['wandb_group'],
                     id=runid,resume='allow',dir=str(dest),mode='online',
                     name='action-consensus-frozen-DT-seed0-50k',job_type='feasibility-diagnostic',
                     config=protocol,tags=['action-consensus','delayed-reward','no-training'],
                     settings=wandb.Settings(_disable_stats=True,_disable_meta=True,
                        disable_code=True,disable_git=True,console='off',start_method='thread'))
    write(dest/'manifest.json',dict(id=runid,url=run.url,group=protocol['wandb_group'],complete=False))
    try:
        run.define_metric('episode')
        run.define_metric('eval/*',step_metric='episode')
        for ep in result['episodes']:
            run.log(dict(episode=ep['episode'],**{'eval/positions':ep['positions'],
                         'eval/baseline_score':ep['baseline_score'],
                         **{'eval/consensus_minus_'+c:ep['consensus_minus_'+c]
                            for c in ['dt','random','nearest_high']}}))
        table = wandb.Table(columns=['episode','episode_seed','step','method','raw_return','normalized_score'])
        for row in branches:
            for method, score in row['scores'].items():
                table.add_data(row['episode'],row['episode_seed'],row['step'],method,
                               score['raw_return'],score['normalized_score'])
        run.log({'tables/branches':table})
        artifact = wandb.Artifact('action-consensus-'+runid,type='diagnostic-results')
        for path in sorted(out.rglob('*')):
            if path.is_file() and 'wandb_upload' not in path.parts and '__pycache__' not in path.parts:
                artifact.add_file(str(path),name=str(path.relative_to(out)))
        run.log_artifact(artifact)
        summary = {'diagnostic/complete':True,'result/positions':result['positions'],
                   'result/episodes_with_positions':result['episodes_with_positions'],
                   'result/screen_passed':result['preliminary_useful_signal'],
                   'result/decision':result['decision'],'audit/passed':True,
                   'offline/brier_improvement':result['validation_brier']['all_supported']['improvement']['mean']}
        for control, stats in result['comparisons'].items():
            summary['result/consensus_minus_'+control] = stats['mean']
            summary['result/consensus_minus_'+control+'_ci95'] = stats['ci95']
        run.summary.update(summary)
        url = run.url
        run.finish(exit_code=0)
    except BaseException:
        run.finish(exit_code=1)
        raise
    remote = wandb.Api(timeout=45).run(f'{entity}/{project}/{runid}')
    for key,value in summary.items():
        actual = remote.summary.get(key)
        if isinstance(value,float):
            assert abs(actual-value)<1e-8,(key,actual,value)
        else:
            assert actual==value,(key,actual,value)
    verification = dict(id=runid,url=url,group=protocol['wandb_group'],complete=True,
                        remote_summary_verified=True,branches=len(branches),summary=summary)
    write(dest/'manifest.json',verification)
    write(dest/'verification.json',verification)
    print('W&B verified: '+url,flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['analyze','branch','summarize'])
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--dataset',type=Path,default=DATASET)
    p.add_argument('--checkpoint',type=Path,default=CHECKPOINT)
    p.add_argument('--device',default='cuda:0')
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--upload',action='store_true')
    args = p.parse_args()
    globals()[args.mode](args)


if __name__ == '__main__':
    main()
