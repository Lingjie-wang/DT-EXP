"""Protocol-level tests without importing MuJoCo or torch."""
import importlib.util
from pathlib import Path
import unittest

import numpy as np

PATH = Path(__file__).resolve().parents[1] / 'algorithms/offline/action_consensus_diagnostic.py'
SPEC = importlib.util.spec_from_file_location('consensus', PATH)
d = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(d)


class ConsensusProtocolTests(unittest.TestCase):
    def neighborhood(self):
        actions = np.zeros((12, 6), np.float32)
        actions[:4] = .15
        actions[4:8] = -.8
        actions[8:] = .8
        return dict(ids=np.arange(12), steps=np.full(12, 30), distances=np.arange(12)/100,
                    actions=actions, high=np.arange(12)<4, totals=np.arange(12))

    def test_nearest_is_distinct_other_discovery_trajectory(self):
        states = np.zeros((40, 40, 2), np.float32)
        states[:, :, 0] = np.arange(40)[:, None]/100
        states[:, 20, 1] = .1
        actions = np.zeros((40, 40, 1), np.float32)
        index = d.DiscoveryIndex(states, actions, np.arange(40), np.arange(35),
                                 np.zeros(2), np.ones(2), 25)
        neighbors = index.neighbors(np.zeros(2), 20, exclude=0)
        self.assertEqual(len(neighbors['ids']), 32)
        self.assertEqual(len(set(neighbors['ids'])), 32)
        self.assertNotIn(0, neighbors['ids'])
        self.assertTrue(set(neighbors['ids']) <= set(range(35)))
        self.assertTrue(np.all(abs(neighbors['steps']-20)<=5))
        self.assertTrue(np.all(neighbors['distances']<=.5))
        np.testing.assert_array_equal(neighbors['steps'], 15)

    def test_validation_cannot_change_discovery_normalizer_or_neighbors(self):
        rng = np.random.default_rng(1)
        states = rng.normal(size=(20, 30, 3)).astype(np.float32)
        actions = rng.normal(size=(20, 30, 2)).astype(np.float32)
        totals = np.arange(20.)
        first = d.DiscoveryIndex(states, actions, totals, np.arange(15))
        states[15:] += 1e6
        actions[15:] *= 100
        totals[15:] *= 10000
        second = d.DiscoveryIndex(states, actions, totals, np.arange(15))
        np.testing.assert_array_equal(first.mean, second.mean)
        np.testing.assert_array_equal(first.std, second.std)
        np.testing.assert_array_equal(first.states, second.states)
        self.assertEqual(first.high_threshold, second.high_threshold)

    def test_medoid_provenance_and_consensus(self):
        nb = self.neighborhood()
        row = d.describe(nb)
        self.assertEqual(d.candidate_reason(row, .1), 'candidate')
        self.assertEqual(row['medoid_trajectory'], 0)
        np.testing.assert_array_equal(np.array(row['medoid_action'],np.float32),nb['actions'][0])
        self.assertEqual(row['cluster_high'], 4)
        self.assertEqual(row['high_fraction'], 1.)
        self.assertEqual(row['other_fraction'], 0.)
        self.assertEqual(d.candidate_reason(row, 1.), 'low_disagreement')

    def test_random_control_matches_magnitude_and_is_deterministic(self):
        nb = self.neighborhood()
        row = d.describe(nb)
        original = np.zeros(6, np.float32)
        args = (row,nb,original,-np.ones(6),np.ones(6),424242,30)
        first, reason = d.controls(*args)
        second, _ = d.controls(*args)
        self.assertEqual(reason, 'selected')
        self.assertEqual(first, second)
        self.assertAlmostEqual(first['consensus_displacement'],first['random_displacement'],places=6)
        self.assertEqual(first['nearest_trajectory'],0)
        for action in first['actions'].values():
            self.assertTrue(np.all(np.abs(action)<=1))

    def test_reject_large_action_replacement(self):
        nb = self.neighborhood()
        result, reason = d.controls(d.describe(nb),nb,np.full(6,-.7,np.float32),
                                    -np.ones(6),np.ones(6),424242,30)
        self.assertIsNone(result)
        self.assertEqual(reason,'consensus_displacement_outside_range')

    def test_laplace_probabilities_and_empty_action_neighborhood(self):
        nb = self.neighborhood()
        ps, pa, n = d.proportions(nb,np.full(6,.15))
        self.assertAlmostEqual(ps,5/14)
        self.assertAlmostEqual(pa,5/6)
        self.assertEqual(n,4)
        _, pa, n = d.proportions(nb,np.full(6,.45))
        self.assertEqual(pa,.5)
        self.assertEqual(n,0)

    def test_bootstrap_keeps_zero_intervention_episodes(self):
        result = d.bootstrap([1.]+[0.]*19)
        self.assertEqual(result['units'],20)
        self.assertAlmostEqual(result['mean'],.05)
        self.assertEqual(result['ci95'][0],0.)


if __name__ == '__main__':
    unittest.main()
