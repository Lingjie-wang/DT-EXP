import importlib.util
from pathlib import Path
import unittest
import numpy as np

SPEC=importlib.util.spec_from_file_location('segments',Path(__file__).resolve().parents[1]/'algorithms/offline/segment_behavior_analysis.py')
m=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(m)


class SegmentTests(unittest.TestCase):
    def test_exact_post_action_endpoints(self):
        states=np.zeros((101,17))
        states[:,8]=np.arange(101)
        actions=np.zeros((100,6))
        f=m.segment_features(states,actions,20)
        self.assertEqual(f.shape,(81,13))
        self.assertAlmostEqual(f[0,0],10.5)
        self.assertAlmostEqual(f[0,1],10.5)
        self.assertAlmostEqual(f[0,2],20)
        self.assertAlmostEqual(f[-1,0],90.5)
        self.assertAlmostEqual(f[-1,1],10.5)

    def test_constant_velocity_is_not_acceleration(self):
        s=np.zeros((51,17));s[:,8]=7
        f=m.segment_features(s,np.zeros((50,6)),20)
        np.testing.assert_allclose(f[:,0],7)
        np.testing.assert_allclose(f[:,1:4],0)
        np.testing.assert_allclose(f[:,4],.7)
        np.testing.assert_allclose(f[:,8:],0)

    def test_motor_coordination_is_signed_and_recorded(self):
        a=np.tile(np.arange(50.)[:,None],(1,6))
        a[:,3]=-a[:,0]
        f=m.segment_features(np.zeros((51,17)),a,20)
        np.testing.assert_allclose(f[:,10],-1)
        np.testing.assert_allclose(f[:,11:],1)
        np.testing.assert_allclose(f[:,9],1)

    def test_neighborhood_deduplicates_and_respects_horizon(self):
        states=np.zeros((40,1001,17))
        states[:,:,0]=np.arange(40)[:,None]/100
        ids,steps,dist=m.nearest_start(states,np.arange(40),np.zeros(17),980,20,exclude=0)
        self.assertEqual(len(ids),32)
        self.assertEqual(len(set(ids)),32)
        self.assertNotIn(0,ids)
        self.assertTrue(np.all(steps+20<=1000))
        self.assertTrue(np.all(np.abs(steps-980)<=5))
        self.assertTrue(np.all(dist<=.5))

    def test_matching_has_no_actions_or_future_features_argument(self):
        states=np.zeros((15,1001,17));ids=np.arange(15)
        first=m.nearest_start(states,ids,np.zeros(17),100,20)
        states[:,106:120]=100
        second=m.nearest_start(states,ids,np.zeros(17),100,20)
        for a,b in zip(first,second):np.testing.assert_array_equal(a,b)

    def test_support_requires_both_return_groups(self):
        self.assertEqual(m.support_reason(np.arange(12),np.zeros(20,bool)),'fewer_than_4_high_trajectories')
        self.assertEqual(m.support_reason(np.arange(12),np.arange(20)<4),'supported')

    def test_bootstrap_rows_are_trajectories(self):
        values=np.r_[np.ones((10,13)),np.zeros((11,13))]
        result=m.group_statistics(values,np.arange(21)<10)
        self.assertEqual(result['high_trajectories'],10)
        self.assertEqual(result['other_trajectories'],11)
        self.assertEqual(result['features']['speed_gain']['difference'],1)
        np.testing.assert_allclose(result['features']['speed_gain']['ci95'],[1,1])


if __name__=='__main__':unittest.main()
