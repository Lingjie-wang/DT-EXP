"""Reward-boundary and matched-input tests; CPU only, no MuJoCo import."""
import sys
from pathlib import Path
import unittest

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'algorithms/offline'))
from segment_delayed_dt import SegmentDataset, segment_returns
from threshold_dt import action_loss, PairedBatchSampler, return_partition


class Base:
    reward_scale = .001
    dataset = [{}]

    def _SequenceDataset__prepare_sample(self, trajectory, start):
        valid = min(20, 25-start)
        mask = np.r_[np.ones(valid), np.zeros(20-valid)]
        return (np.arange(40, dtype=np.float32).reshape(20, 2),
                np.ones((20, 3), dtype=np.float32), np.full(20, 12., np.float32),
                np.arange(start, start+20), mask)


class SegmentTests(unittest.TestCase):
    def test_full_and_tail_returns_equal_delayed_cumsum(self):
        rewards = np.arange(-3, 22, dtype=np.float32)
        labels = segment_returns(rewards)
        for start in range(25):
            original = rewards[start:start+20]
            delayed = np.zeros(len(original), dtype=np.float64)
            delayed[-1] = original.sum(dtype=np.float64)
            rtg = np.cumsum(delayed[::-1])[::-1]
            np.testing.assert_array_equal(rtg, np.full(len(original), labels[start]))
        self.assertEqual(labels[-1], rewards[-1])

    def test_outside_context_rewards_cannot_change_label(self):
        rewards = np.arange(1000, dtype=np.float32)
        before = segment_returns(rewards)[100]
        rewards[:100] = -9999
        rewards[120:] = 9999
        self.assertEqual(segment_returns(rewards)[100], before)

    def test_episode_boundary_never_crosses(self):
        first, second = np.ones(25), np.full(25, 100.)
        labels = np.stack([segment_returns(first), segment_returns(second)])
        self.assertEqual(labels[0, -1], 1.)
        self.assertEqual(labels[1, 0], 2000.)

    def test_only_condition_changes_padding_and_original_preserved(self):
        base = Base()
        labels = segment_returns(np.arange(25))[None]
        dataset = SegmentDataset(base, labels)
        for start in [0, 5, 24]:
            sample = dataset[(0, start, -1)]
            original = base._SequenceDataset__prepare_sample(0, start)
            for k in [0, 1, 3, 4]:
                np.testing.assert_array_equal(sample[k], original[k])
            np.testing.assert_array_equal(sample[2], np.where(original[4]>0,
                np.float32(labels[0, start]*.001), np.float32(0)))
            np.testing.assert_array_equal(original[2], np.full(20, 12., np.float32))

    def test_padded_predictions_do_not_affect_loss_or_gradient(self):
        a = torch.ones(1, 20, 2)
        p = torch.zeros_like(a, requires_grad=True)
        mask = torch.zeros(1, 20)
        mask[:, :3] = 1
        loss = action_loss(p, a, mask)
        loss.backward()
        self.assertAlmostEqual(loss.item(), 3/20)
        self.assertEqual(p.grad[:, 3:].abs().sum().item(), 0)

    def test_sampler_unaffected_by_local_label_construction(self):
        partition = return_partition([10., 20.], [25, 25])
        first = list(PairedBatchSampler(partition, 'dt', 16, 0, 3))
        segment_returns(np.arange(1000))
        second = list(PairedBatchSampler(partition, 'dt', 16, 0, 3))
        self.assertEqual(first, second)

    def test_invalid_rewards_rejected(self):
        for rewards in [[], [np.nan], [[1, 2]]]:
            with self.assertRaises(ValueError):
                segment_returns(rewards)


if __name__ == '__main__':
    unittest.main()
