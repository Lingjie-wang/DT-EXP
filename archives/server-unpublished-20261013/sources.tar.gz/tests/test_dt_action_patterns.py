import importlib.util
from pathlib import Path
import sys
import unittest
import numpy as np

DIRECTORY=Path(__file__).resolve().parents[1]/'algorithms/offline'
sys.path.insert(0,str(DIRECTORY))
spec=importlib.util.spec_from_file_location('patterns',DIRECTORY/'diagnose_dt_action_patterns.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sys.path.pop(0)


class ActionPatternTests(unittest.TestCase):
    def test_history_slides_without_reset_and_zeroes_only_current_action(self):
        states=np.arange(2*1000*17,dtype=np.float32).reshape(2,1000,17)
        actions=np.arange(2*1000*6,dtype=np.float32).reshape(2,1000,6)
        batch=m.pack_history(states,actions,np.array([4.,12.]),[0,1],[20,49],20)
        np.testing.assert_array_equal(batch[3][0],np.arange(1,21))
        np.testing.assert_array_equal(batch[1][0,:-1],actions[0,1:20])
        np.testing.assert_array_equal(batch[1][:,-1],0)
        np.testing.assert_array_equal(batch[2][1],12)
        np.testing.assert_array_equal(actions[0,20],np.arange(120,126))

    def test_history_current_future_action_independence(self):
        s=np.zeros((1,1000,17));a=np.ones((1,1000,6));rtg=np.ones(1)
        first=m.pack_history(s,a,rtg,[0],[49],20)
        a[:,49:]=30
        second=m.pack_history(s,a,rtg,[0],[49],20)
        for x,y in zip(first,second):np.testing.assert_array_equal(x,y)

    def test_short_prefix_and_last_step(self):
        s=np.zeros((1,1000,17));a=np.ones((1,1000,6));rtg=np.ones(1)
        np.testing.assert_array_equal(m.pack_history(s,a,rtg,[0],[0],1)[3],[[0]])
        np.testing.assert_array_equal(m.pack_history(s,a,rtg,[0],[999],20)[3],np.arange(980,1000)[None])
        with self.assertRaises(ValueError):m.pack_history(s,a,rtg,[0],[0],20)

    def test_constant_correlation_is_missing(self):
        f=m.action_features(np.ones((50,6)),20)
        self.assertTrue(np.isnan(f[:,2]).all())
        np.testing.assert_array_equal(f[:,1],0)
        self.assertEqual(f.shape,(31,3))

    def test_amplitude_shrink_preserves_correlation(self):
        rng=np.random.default_rng(3);a=rng.normal(size=(100,6));a[:,3]=-a[:,0]
        reference=m.action_features(a,20);model=m.action_features(.7*a,20)
        row=m.window_metrics(model[0],reference[0])
        self.assertAlmostEqual(row[6],.7)
        self.assertAlmostEqual(row[9],0.)

    def test_speed_filter_precedes_closest_start(self):
        s=np.full((5,1001,17),10.)
        s[:,100]=0;s[:,100,8]=.3
        s[:,101]=0;s[:,101,0]=.4;s[:,101,8]=.1
        ids,times,dist=m.select_neighbors(s,s,np.arange(5),np.zeros(17),np.zeros(17),np.ones(17),100,20)
        self.assertEqual(len(ids),5)
        np.testing.assert_array_equal(times,101)
        self.assertEqual(len(set(ids)),5)

    def test_matching_cannot_cross_episode_end(self):
        s=np.zeros((5,1001,17))
        _,times,_=m.select_neighbors(s,s,np.arange(5),np.zeros(17),np.zeros(17),np.ones(17),980,20)
        self.assertTrue(np.all(times+20<=1000))

    def test_missing_units_are_not_zeros(self):
        row=m.window_metrics([.8,.8,-.5],[1,1,-.5])
        units=[m.aggregate_unit(i,[row]) for i in range(10)]+[m.aggregate_unit(10,[])]
        result=m.bootstrap_units(units)
        self.assertAlmostEqual(result['primary']['change_ratio']['mean'],.8)
        self.assertEqual(result['primary']['change_ratio']['units'],10)
        self.assertTrue(result['change_compressed'])
        self.assertFalse(result['negative_correlation_weakened'])

    def test_insufficient_coverage_cannot_pass(self):
        row=m.window_metrics([.8,.8,-.3],[1,1,-.5])
        units=[m.aggregate_unit(i,[row]) for i in range(20)]
        result=m.bootstrap_units(units,coverage_ok=False)
        self.assertFalse(result['change_compressed'])
        self.assertFalse(result['negative_correlation_weakened'])


if __name__=='__main__':unittest.main()
