"""CPU protocol tests; no MuJoCo import, dataset download or training job."""

import copy
import importlib.util
import io
import random
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "algorithms/offline"))
from threshold_dt import (
    action_loss,
    ARMS,
    ConditionedDataset,
    isolated_evaluation,
    PairedBatchSampler,
    PROFILES,
    read_json,
    return_partition,
    rng_state,
    select_target,
    torch_rng_hash,
    write_json,
)

spec = importlib.util.spec_from_file_location(
    "threshold_campaign", ROOT / "scripts/dt_experiments/threshold_campaign.py"
)
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)


class FixedSample:
    reward_scale = 0.001
    dataset = [{}, {}]

    def __init__(self):
        self.sample = (np.array([[1., 2.], [3., 4.], [0., 0.]], dtype=np.float32),
                       np.array([[.1], [.2], [0.]], dtype=np.float32),
                       np.array([4.7, 4.7, 0.], dtype=np.float32),
                       np.array([998, 999, 1000]), np.array([1., 1., 0.]))

    def _SequenceDataset__prepare_sample(self, trajectory, start):
        return self.sample


class ThresholdTest(unittest.TestCase):
    def test_quantiles_ties_and_bc_exact_ceil_are_distinct(self):
        partition = return_partition([1, 1, 2, 2, 3, 3, 4, 4, 5, 5], [10] * 10)
        self.assertEqual(partition["thresholds"], [1., 3., 4.2, 5.])
        self.assertEqual(partition["eligible_counts"], [10, 6, 2, 2])
        self.assertEqual(partition["top_bc_trajectory_ids"], [8])
        self.assertEqual(partition["candidate_returns"][-2:], [6000., 12000.])
        self.assertEqual(len(return_partition(np.arange(202), [1000] * 202)
                             ["top_bc_trajectory_ids"]), 21)
        for invalid in ([float("nan")], [float("inf")], []):
            with self.assertRaises(ValueError):
                return_partition(invalid, [1] * len(invalid))

    def test_sampler_balanced_eligible_paired_and_rng_independent(self):
        partition = return_partition(np.arange(20), np.arange(1, 21))
        b = iter(PairedBatchSampler(partition, "matched_dt", 64, 0, 8))
        c = iter(PairedBatchSampler(partition, "threshold_dt", 64, 0, 8))
        for _ in range(8):
            before = rng_state()
            left = next(b)
            self.assertEqual(random.getstate(), before["python"])
            np.testing.assert_array_equal(np.random.get_state()[1], before["numpy"][1])
            random.random()
            np.random.rand(30)
            torch.rand(50)
            right = next(c)
            self.assertEqual(left, right)
            rows = np.array(left)
            np.testing.assert_array_equal(np.bincount(rows[:, 2]), [16] * 4)
            for trajectory, start, group in left:
                self.assertGreaterEqual(partition["trajectory_returns"][trajectory],
                                        partition["thresholds"][group])
                self.assertLess(start, partition["trajectory_lengths"][trajectory])
        with self.assertRaises(ValueError):
            PairedBatchSampler(partition, "threshold_dt", 63, 0, 1)

    def test_original_length_weighting_uniform_starts_and_top_bc_support(self):
        partition = return_partition([10, 20], [1, 3])
        rows = np.array(next(iter(PairedBatchSampler(partition, "dt", 20000, 7, 1))))
        self.assertLess(abs((rows[:, 0] == 1).mean() - .75), .02)
        starts = rows[rows[:, 0] == 1, 1]
        np.testing.assert_allclose(np.bincount(starts) / len(starts),
                                   [1 / 3] * 3, atol=.02)
        top = next(iter(PairedBatchSampler(partition, "top_bc", 100, 7, 1)))
        self.assertTrue(all(row[0] == 1 for row in top))

    def test_only_condition_changes_and_padding_remains_zero(self):
        base = FixedSample()
        original = copy.deepcopy(base.sample)
        partition = return_partition([4000, 4700], [1000, 1000])
        results = {arm: ConditionedDataset(base, partition, arm)[(1, 998, 3)]
                   for arm in ARMS}
        for arm in ARMS:
            for position in (0, 1, 3, 4, 5):
                np.testing.assert_array_equal(results[arm][position],
                                              results["dt"][position])
        np.testing.assert_array_equal(results["dt"][2], results["matched_dt"][2])
        np.testing.assert_allclose(results["threshold_dt"][2], [4.63, 4.63, 0.])
        np.testing.assert_array_equal(results["top_bc"][2], results["threshold_dt"][2])
        for before, after in zip(original, base.sample):
            np.testing.assert_array_equal(before, after)

    def test_loss_and_gradient_are_corl_padded_mean(self):
        predictions = torch.tensor([[[1., 2.], [8., 9.]], [[2., 3.], [1., 1.]]],
                                   requires_grad=True)
        actions = torch.zeros_like(predictions)
        mask = torch.tensor([[1., 0.], [1., 1.]])
        loss = action_loss(predictions, actions, mask)
        self.assertEqual(loss.item(), 20. / 8)
        loss.backward()
        expected = predictions.detach() * mask[:, :, None] / 4
        torch.testing.assert_close(predictions.grad, expected, rtol=0, atol=0)

    def test_loader_worker_count_preserves_batches_and_model_rng(self):
        partition = return_partition([4000, 4700], [1000, 1000])
        batches = {}
        for workers in (0, 1):
            dataset = ConditionedDataset(FixedSample(), partition, "threshold_dt")
            sampler = PairedBatchSampler(partition, "threshold_dt", 16, 0, 5)
            loader = DataLoader(dataset, batch_sampler=sampler, num_workers=workers,
                                generator=torch.Generator().manual_seed(0))
            before = torch_rng_hash()
            batches[workers] = list(loader)
            self.assertEqual(before, torch_rng_hash())
        for left, right in zip(batches[0], batches[1]):
            for a, b in zip(left, right):
                torch.testing.assert_close(a, b, rtol=0, atol=0)

    def test_evaluation_restores_all_rng_and_mode_even_on_error(self):
        model = torch.nn.Sequential(torch.nn.Linear(2, 2), torch.nn.Dropout(.5)).train()
        before = rng_state()
        torch_before = torch_rng_hash()
        with self.assertRaisesRegex(RuntimeError, "evaluation failed"):
            with isolated_evaluation(model):
                self.assertFalse(model.training)
                self.assertFalse(torch.is_grad_enabled())
                random.random()
                np.random.rand()
                torch.rand(10)
                raise RuntimeError("evaluation failed")
        self.assertTrue(model.training)
        self.assertTrue(torch.is_grad_enabled())
        self.assertEqual(torch_rng_hash(), torch_before)
        self.assertEqual(random.getstate(), before["python"])
        after = np.random.get_state()
        np.testing.assert_array_equal(after[1], before["numpy"][1])
        self.assertEqual(after[2:], before["numpy"][2:])

    def test_selection_is_stable_and_profiles_separate_data(self):
        candidates = [{"target_return": 10., "mean_score": 3.},
                      {"target_return": 20., "mean_score": 3.}]
        self.assertEqual(select_target(candidates), 10.)
        candidates[1]["mean_score"] = 4.
        self.assertEqual(select_target(candidates), 20.)
        self.assertEqual(PROFILES["pilot"]["window"],
                         [30000, 35000, 40000, 45000, 50000])
        self.assertEqual(PROFILES["confirm"]["window"],
                         [80000, 85000, 90000, 95000, 100000])
        for profile in PROFILES.values():
            development = set(range(31415, 31415 + profile["development_episodes"]))
            first_seed = profile["evaluation_seed"]
            heldout = set(range(first_seed, first_seed + profile["evaluation_episodes"]))
            self.assertFalse(development & heldout)

    def test_single_seed_gate_requires_both_controls_and_never_auto_launches(self):
        good = campaign.screen_result(
            {"dt": 38., "matched_dt": 39., "threshold_dt": 40.}
        )
        self.assertTrue(good["positive_single_seed_signal"])
        self.assertFalse(good["automatic_confirmation"])
        for scores in ({"dt": 38., "matched_dt": 40., "threshold_dt": 40.},
                       {"dt": 40., "matched_dt": 38., "threshold_dt": 40.}):
            result = campaign.screen_result(scores)
            self.assertFalse(result["positive_single_seed_signal"])

    def test_frozen_campaign_detects_source_tampering(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "campaign"
            with redirect_stdout(io.StringIO()):
                campaign.initialize(root)
            self.assertEqual(campaign.verify(root)["seeds"], [0])
            protocol = campaign.verify(root)
            self.assertEqual(protocol["expected_gpu"], "RTX 3090")
            self.assertEqual(protocol["execution"]["num_workers"], 0)
            source = root / "source/algorithms/offline/threshold_dt.py"
            source.write_text(source.read_text() + "\n# changed\n")
            with self.assertRaisesRegex(AssertionError, "Frozen source"):
                campaign.verify(root)

    def test_evaluation_audit_rejects_target_or_seed_leakage(self):
        profile = PROFILES["smoke"]
        partition = return_partition([1., 2., 3.], [10] * 3)
        target = partition["primary_threshold"]
        selection = {"target_return": target, "candidates": []}
        evaluations = [{"completed_updates": step, "target_return": target,
                        "mean_score": 4., "episodes": [{"episode_seed": 271828,
                        "normalized_score": 4.}]} for step in profile["window"]]
        summary = {"profile": "smoke", "arm": "threshold_dt", "selection": selection,
                   "window": profile["window"], "evaluations": evaluations,
                   "primary_score": 4.}
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "evaluation").mkdir()
            write_json(root / "evaluation/selection.json", selection)
            self.assertEqual(read_json(root / "evaluation/selection.json"), selection)
            campaign.validate_evaluation(root, summary, partition)
            bad = copy.deepcopy(summary)
            bad["evaluations"][0]["target_return"] += 1
            with self.assertRaisesRegex(AssertionError, "Condition changed"):
                campaign.validate_evaluation(root, bad, partition)
            bad = copy.deepcopy(summary)
            bad["evaluations"][0]["episodes"][0]["episode_seed"] = 31415
            with self.assertRaisesRegex(AssertionError, "Held-out episode seeds"):
                campaign.validate_evaluation(root, bad, partition)


if __name__ == "__main__":
    unittest.main()
