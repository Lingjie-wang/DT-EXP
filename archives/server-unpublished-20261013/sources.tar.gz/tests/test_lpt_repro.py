import copy
import importlib.util
from pathlib import Path
import sys
import unittest

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'algorithms/offline'))
import lpt_compat as compat
import lpt_repro as run

torch.set_num_threads(2)


def model_and_data():
    p = dict(trajectories=3, max_len=16, window_size=32, hidden_size=128,
             n_layer=3, nominal_batch_size=500, epochs=2000)
    run.seed_all(5)
    model = compat.make_model(p, ROOT / 'third_party/Latent-Plan-Transformer', 'cpu')
    gen = np.random.default_rng(7)
    rewards = gen.normal(size=(3, 16))
    delayed = run.delayed_rewards(rewards)
    total = rewards.sum(1).astype(np.float32) / 1000
    data = dict(states=gen.normal(size=(3, 16, 17)).astype(np.float32),
                actions=gen.normal(size=(3, 16, 6)).astype(np.float32),
                dense_totals=total, delayed_totals=delayed.sum(1).astype(np.float32) / 1000,
                dense_rtg=(run.returns_to_go(rewards) / 1000).astype(np.float32),
                delayed_rtg=(run.returns_to_go(delayed) / 1000).astype(np.float32))
    return model, data


class LPTTests(unittest.TestCase):
    def test_banded_attention_matches_full_mask_and_gradients(self):
        torch.manual_seed(1)
        q, k, v = [torch.randn(2, 11, 2, 8, requires_grad=True) for _ in range(3)]
        expected_scores = q.transpose(1, 2) @ k.transpose(1, 2).transpose(-1, -2)
        qi, ki = torch.arange(11)[:, None], torch.arange(11)[None, :]
        allowed = (ki <= qi) & (ki >= qi - 3)
        probs = expected_scores.masked_fill(~allowed, -torch.inf).softmax(-1)
        expected = (probs @ v.transpose(1, 2)).transpose(1, 2)
        actual = compat.local_attention(q, k, v, 3, scale=1., block=4)
        torch.testing.assert_close(actual, expected, atol=1e-6, rtol=1e-5)
        weights = torch.randn_like(actual)
        original = torch.autograd.grad((expected * weights).sum(), (q, k, v), retain_graph=True)
        portable = torch.autograd.grad((actual * weights).sum(), (q, k, v))
        for a, b in zip(original, portable):
            torch.testing.assert_close(a, b, atol=3e-6, rtol=1e-4)

    def test_delayed_invariance_matches_official_collator(self):
        spec = importlib.util.spec_from_file_location('lpt_collator', ROOT / 'third_party/Latent-Plan-Transformer/model/utils_train.py')
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        gen = np.random.default_rng(1)
        observations, actions, rewards = gen.normal(size=(3, 16, 17)), gen.normal(size=(3, 16, 6)), gen.normal(size=(3, 16))

        class Dataset:
            def __init__(self, rewards):
                self.rows = [dict(observations=observations[i].tolist(), actions=actions[i].tolist(),
                                 rewards=rewards[i].tolist(), dones=[False] * 16) for i in range(3)]

            def __getitem__(self, index):
                return [row[index] for row in self.rows] if isinstance(index, str) else self.rows[index]

        outputs = []
        for reward in [rewards, run.delayed_rewards(rewards)]:
            collator = module.LPTGymDataCollator(Dataset(reward), max_len=16, scale=1000., sample_by_length=True)
            np.random.seed(21)
            outputs.append(collator([None] * 3))
        for key in ['states', 'actions', 'rewards', 'attention_mask', 'batch_inds']:
            torch.testing.assert_close(outputs[0][key], outputs[1][key], rtol=0, atol=0)
        self.assertFalse(torch.equal(outputs[0]['returns_to_go'], outputs[1]['returns_to_go']))

    def test_dense_delayed_loss_gradients_pmc_and_best_index(self):
        model, data = model_and_data()
        initial, latent, rng = copy.deepcopy(model.state_dict()), compat.latent_state(model), run.rng_state()
        # The max is at batch offset 1 but trajectory ID 2; exercise the index fix.
        data['dense_totals'] = data['delayed_totals'] = np.array([1., 2., 3.], dtype=np.float32)
        values = []
        for arm in ['dense', 'delayed']:
            model.load_state_dict(initial)
            compat.restore_latents(model, latent)
            run.restore_rng(rng)
            model.zero_grad()
            loss = compat.logical_backward(model, data, np.array([0, 2, 0]), arm, 2, 'cpu')
            grads = {n: p.grad.clone() for n, p in model.named_parameters() if p.grad is not None}
            values.append((loss, grads, compat.latent_state(model)))
        self.assertEqual(values[0][0], values[1][0])
        for key in values[0][1]:
            torch.testing.assert_close(values[0][1][key], values[1][1][key], rtol=0, atol=0)
        torch.testing.assert_close(values[0][2]['buffer'], values[1][2]['buffer'], rtol=0, atol=0)
        self.assertEqual(model.z_best_idx, 2)

    def test_pmc_optimizer_resume_reproduces_update(self):
        model, data = model_and_data()
        optimizer = compat.optimizer_for(model, 1e-4)

        def step():
            optimizer.zero_grad()
            loss = compat.logical_backward(model, data, np.array([0, 1]), 'dense', 2, 'cpu')
            optimizer.step()
            return loss, run.model_sha(model), compat.latent_state(model)

        step()
        state = copy.deepcopy(dict(model=model.state_dict(), optimizer=optimizer.state_dict(),
                                   latent=compat.latent_state(model), rng=run.rng_state()))
        expected = step()
        model.load_state_dict(state['model'])
        optimizer.load_state_dict(state['optimizer'])
        compat.restore_latents(model, state['latent'])
        run.restore_rng(state['rng'])
        actual = step()
        self.assertEqual(expected[:2], actual[:2])
        torch.testing.assert_close(expected[2]['buffer'], actual[2]['buffer'], rtol=0, atol=0)

    def test_microbatch_preserves_objective_without_stochastic_noise(self):
        model, data = model_and_data()
        model.z_with_noise = False
        for sub in model.modules():
            if isinstance(sub, torch.nn.Dropout):
                sub.p = 0.
            if hasattr(sub, 'attn_dropout_ratio'):
                sub.attn_dropout_ratio = 0.
        initial, latent = copy.deepcopy(model.state_dict()), compat.latent_state(model)
        results = []
        for size in [2, 1]:
            model.load_state_dict(initial)
            compat.restore_latents(model, latent)
            model.zero_grad()
            loss = compat.logical_backward(model, data, np.array([0, 0]), 'dense', size, 'cpu')
            grads = {n: p.grad.clone() for n, p in model.named_parameters() if p.grad is not None}
            results.append((loss, grads, compat.latent_state(model)))
        self.assertAlmostEqual(results[0][0], results[1][0], places=5)
        for key in results[0][1]:
            torch.testing.assert_close(results[0][1][key], results[1][1][key], rtol=3e-3, atol=2e-5)
        torch.testing.assert_close(results[0][2]['buffer'], results[1][2]['buffer'], rtol=1e-4, atol=2e-5)


if __name__ == '__main__':
    unittest.main()
