# 状态分歧与高回报动作共识诊断

独立入口为 `algorithms/offline/action_consensus_diagnostic.py`，只有
`analyze`、`branch`、`summarize` 三个模式。没有训练接口，不生成 AWR 权重。

离线阶段直接读取 HDF5，将密集奖励一次性汇总为 float32 终局总回报后丢弃。
只使用状态、动作、时间和总回报；按 seed 20261002 划分 141/61 条轨迹。
验证查询的邻居仅来自发现集，归一化与 q80 高回报标签门槛也仅由发现集确定。
邻域、分歧与共识阈值全部按方案固定。距离或 medoid 成本并列时按原轨迹编号、
时间顺序确定结果。独立验证主指标为全部受支持查询的轨迹均衡 Brier 差值，
另报告高分歧区域和候选区域；无受支持查询的验证轨迹不计算 Brier，并报告数量。
动作邻域为空时使用加一平滑的 1/2，不回退到另一个人为选择的预测器。

`analyze` 创建新目录，冻结源代码、数据与 checkpoint 哈希，保存发现/验证划分、
状态统计、轨迹回报、所有查询与拒绝原因、与查询行对齐的压缩邻居索引。
已存在的冻结协议不会被覆盖。后续从该目录的 `source` 运行。

```bash
python algorithms/offline/action_consensus_diagnostic.py analyze --output results/action-consensus-20261002
sbatch scripts/dt_experiments/run_action_consensus.sbatch "$PWD/results/action-consensus-20261002"
```

分支阶段用 checkpoint 自带统计给 DT 归一化，用发现集统计给邻域归一化。
固定 DT seed 0 / 50k / RTG 12000，每步条件不递减。先在额外 seed 424241、
第 500 步完成原动作恢复短测，再执行 seeds 424242–424261 的正式 20 episodes。
正式基准轨迹在 20–945 步每步查询，每 100 步至多选首个合格位置。
每个 episode 先完整运行基准，将全部候选、动作与哈希写盘，再计算分支结果。
每个分支恢复同一模拟器状态、完整 DT 历史、环境/动作空间与 Python/NumPy/Torch
随机状态。只替换一次动作，后续采用同一冻结 DT。全部原动作分支对照完整基准
终局 normalized score，绝对误差必须 ≤1e-6。

分支统计先按 episode 内位置取平均，再对全部 20 episodes 平均；没有位置的
episode 计零收益。bootstrap 单位为 episode（10000 次），验证集 bootstrap
单位为轨迹。至少 40 个位置且覆盖 10 episodes；离线动作 Brier 改善为正，
相对 DT 与同幅度随机动作均值均 ≥0.1 且各自 95% CI 下界 >0，才通过初筛。
最近高回报邻居对照单独报告，不能把不胜过它的结果解释成共识的额外收益。

`summarize --upload` 保存中文报告与汇总，上传到 CORL-DDR 的独立诊断组，
包含逐分支表格、逐 episode 曲线、离线证据与冻结源码 artifact，并读回验证。
Slurm 申请任意 NVIDIA 单卡、2 CPU、4GB、3 小时，依次执行短测、正式分支、汇总上传。
中断的正式任务可按已完整写盘的 episode 恢复；未完成的 episode 从固定种子重放。
