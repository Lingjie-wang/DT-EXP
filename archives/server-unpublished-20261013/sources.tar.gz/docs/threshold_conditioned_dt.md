# 回报门槛条件 DT：单 seed 探索

2026-10-01。用户将首轮改为只跑 seed 0；没有授权自动扩展到多个 seed。
本轮实现保留四种训练模式，正式只启动普通 DT、matched DT、threshold DT。
单 seed 可以支持低成本筛选，不能确立跨 seed 的有效性或无效性。

## 方法与对照

只用 delayed terminal-sum 的轨迹总回报。门槛为轨迹回报的
0/50/80/90 百分位，满足 `R >= g` 的所有轨迹均入池（包括边界并列值）。
每个 4096 batch 的四种门槛各 1024 条序列；池内按轨迹长度采样，再均匀
采样起点。B/C 共用完全相同的私有采样随机流；不读取评测结果更新采样。

| arm | 采样 | 有效 token 的条件 |
|---|---|---|
| dt / A | 原 CORL 长度比例 + 均匀起点分布 | recorded terminal return |
| matched_dt / B | 四门槛均衡 | recorded terminal return |
| threshold_dt / C | 与 B 完全相同 | 当前采样门槛 |
| top_bc / 后续对照 | 恰好 ceil(0.1*N) 条最高回报轨迹 | 固定 q90 门槛 |

Top BC 按回报降序、轨迹编号稳定处理并列值；不同于门槛池包含所有并列值。
主干与原 CORL 一致：context20、hidden128、3 层/1 head、dropout .1、
AdamW lr .0008、batch4096、warmup10k、clip .25。所有 arm 只优化
`mean(mask * (predicted_action-action)^2)`，保留 padding 在分母中的原归一化。
回报条件仍用原始回报单位乘 .001；padding 的回报 token 为 0。

## 更新后的运行协议

1. 完整 batch 和原模型的 GPU smoke：四种 arm 各 3 次更新，保存 0/1/2/3，
   并短跑旧 checkpoint 扫描。审计 B/C 累计采样流、实际 batch 抽查、
   dropout RNG、初始模型、数据/源码/硬件一致性。smoke 数据不进入正式结果。
2. 只读扫描原 seed-0 的 50k DT checkpoint：q50/q80/q90/q95/max/6000/12000，
   每条件 20 episodes。逐 episode seed 为 31415+i，无 optimizer updates。
3. A/B/C seed 0 从头各训练 50000 次更新。训练期间不调用环境评测。
   保存 0、10k、20k、30k、35k、40k、45k、50k 模型及优化器/scheduler/RNG。
4. 训练完成后，A/B 各自在 50k checkpoint 上用同一 RTG 网格和开发 seeds
   31415+i（20 episodes）选条件；同分取候选列表中第一个。C 固定 q90。
   在读取任何最终评测结果之前写出不可混淆的 `evaluation/selection.json`。
5. 固定该条件，评测 30/35/40/45/50k，每个 checkpoint 100 episodes，
   每条 seed 为 271828+i，三组共用相同环境 seeds，delayed 条件保持不变。
   主指标为五次评测均分；50k 是辅助指标，不使用 best 作判断。

用户允许其他卡型。当前优先使用可分配的 RTX3090（运行时检查），
Slurm GPUNorm、单卡、2 CPUs；内存申请须由完整 batch GPU smoke 验证。
DataLoader 使用 0 个子进程，batch4096 和所有学习参数不变；单元测试验证
0/1 worker 的 batch 和模型 RNG 一致。A/B/C 使用相同卡型和运行环境。
账号并发最多 2，正式 array 为 `0-2%2`。采用已验证的 adt-delayed 环境。
只记录本地 JSON/JSONL/checkpoint；没有新建 W&B online run 或周期监控。

## 单 seed 筛选与停止

只有 C-A 和 C-B 的后期均分差值均至少 +1 分，才标记
`positive_single_seed_signal=true`。这是工程筛选阈值，不是显著性检验。
未达到就先停；不能由一次 seed 的结果断言方法普遍无效。
无论达到与否，都不自动启动新 seed、100k 复验或其他环境。
实现中的 confirm profile 只是保留计划定义（80–100k、161803+i），
本 campaign 的 worker 明确限制 seed0 / pilot / A-B-C。

## 隔离、产物和恢复边界

`threshold_campaign.py init --root ...` 创建全新目录并冻结训练器、原 DT、
配置、runner、launcher 和测试源码。每个 worker 检查全部文件哈希以及
原 checkpoint 哈希；历史训练器、checkpoint 和结果不改写。
需要匹配源码及 GPU 的 smoke gate，且只读扫描成功后才能启动正式训练。

各 arm 保留 `partition.json`（每条轨迹总回报/长度、门槛与入池编号）、
`config.json`、`metrics.jsonl`、`pairing_audit.json`、`training_summary.json`、
checkpoint、开发及最终逐 episode 记录、`summary.json`。最后完成的 arm
自动审计三组并写 campaign `summary.json` 和 `report_zh.md`。
缺组或审计失败时不产生有效/无效结论。

快照未保存 DataLoader 预取队列；入口只支持从头训练，不承诺精确续训。
每次运行要求新目录，失败运行保留以便审查，不覆盖重跑。

## 验证和提交

```bash
/labmount/users/202615385/miniforge3/envs/adt-delayed/bin/python \
  -m unittest discover -s tests -p test_threshold_dt.py -v
python scripts/dt_experiments/threshold_campaign.py init --root /absolute/new/campaign
# smoke -> afterok sweep -> afterok --array=0-2%2 train
sbatch --time=00:30:00 scripts/dt_experiments/run_threshold_dt.sbatch smoke /absolute/new/campaign
```

Slurm 依赖控制调度，worker 内的 smoke/source/sweep 检查再次防止绕过门槛。
提交记录另写于 campaign 的 `submission.json`。

## 本次验证与提交记录

- 10 个新协议单元测试通过，Python / shell 语法与 whitespace 检查通过。
- 登录节点的真实 CPU 集成测试因缺少 `GL/osmesa.h` 未进入训练；没有安装
  新依赖或据此标记端到端通过。完整 GPU smoke 仍是正式作业的必要前置条件。
- Campaign：`results/threshold-dt-seed0-20261001/`，源码已冻结。
- GPU smoke：`11820`；只读 RTG sweep：`11821`（afterok:11820）；
  seed-0 A/B/C 正式 array：`11822`（afterok:11821，0-2%2）。
- 下游使用 `--kill-on-invalid-dep=yes`；上游失败不会误启正式训练。
- 提交时处于排队状态，尚无新方法效果结果。调度器初始预计 smoke 在
  2026-10-03 07:59:09 开始，该估计可能变化。
- 机器可读作业记录：campaign `submission.json`。

补充 CPU 验证：在真实 202 条轨迹上使用未修改的 CORL 主干及序列准备函数，
B/C 各 3 次小 batch 更新通过；初始化、实际输入样本、dropout RNG 匹配，
loss/gradient 有限。该检查没有 MuJoCo rollout，不替代待运行的完整 GPU smoke。
记录见 campaign `cpu_interface_check.json`。

## 2026-10-01 资源调整

gn3 有一张未分配的 RTX3090 24GB，但 Slurm 仅剩 2381MB 可申请内存。
只读硬件探测 11825 已完成。原 PyTorch 1.11.0+cu113 环境在 2300MB
限制下初始化 CUDA 时 OOM（11827，尚未写出初始化 checkpoint 或完成更新）。
11826 则因节点没有 /usr/bin/time 在启动训练前退出。失败记录均保留。

为减少 CUDA 启动内存，独立安装 PyTorch 1.13.1+cu117 至项目
`.runtime/threshold-cu117/`，配合 `CUDA_MODULE_LOADING=LAZY`。
原 adt-delayed 环境不修改。安装包来自 PyTorch 官方源，SHA256：
`b3ac139e0d4a0b303cc16f51eb77146ec7d14c0b1e702ad638613628f5086af7`。
三组从头使用统一新运行库；不把跨运行库的历史 checkpoint 成绩当作新的 A 组。
旧 checkpoint RTG 扫描仍只是固定权重诊断。GPU smoke 必须在该运行库重做，
确认训练、MuJoCo rollout、B/C 初值/采样/dropout 配对和总内存约束全部通过。

每个训练日志增加实际 elapsed_seconds、host_peak_rss_kib 和
cuda_peak_allocated_mib。Slurm 的 MaxRSS 同时检查整个作业的内存。
这次修改只涉及执行资源、运行库和记录，不调整方法或筛选门槛。

替代流水线已于同日提交，campaign 为
`results/threshold-dt-seed0-3090-20261001/`（重新冻结源码）：
GPU smoke 11828，RTG sweep 11829，训练 array 11830（0=dt，1=matched_dt，
2=threshold_dt；最多并发 2，只有一张可用卡时顺序执行）。
原 11820/11821/11822 已在排队状态取消，原 campaign 保留为历史记录。
11 个协议测试在新运行库中全部通过。smoke 申请 2300MB，后续扫描及训练
通过 `scontrol update MinMemoryNode=2380` 增加 80MB 余量；不改变冻结源码。
下游仍由 afterok 依赖和 worker 审计共同控制。

完整 GPU smoke 11828 已成功结束（2 分 55 秒，exit 0）。四种模式均完成
3 次完整 batch 更新及短评测，B/C 的初值、样本和 dropout RNG 审计通过；
只读历史 checkpoint smoke 扫描也通过。资源记录见新 campaign 的
`resource_validation.json`；11829 正在执行正式 7 条件 × 20 episodes 扫描。

固定权重 RTG 扫描 11829 已完成（6 分 35 秒，exit 0），每条件 20 个开发 episodes：

| 条件 | 原始回报条件 | 平均 normalized score |
|---|---:|---:|
| q50 | 3786.995 | 36.278 |
| q80 | 4452.646 | 39.320 |
| q90 | 4590.974 | 39.078 |
| q95 | 4683.500 | 39.742 |
| max | 4985.142 | 39.741 |
| 6000 | 6000.000 | 37.511 |
| 12000 | 12000.000 | 40.531 |

该诊断中 12000 的均分最高；不能据此将 RTG 超出数据范围认定为主要瓶颈。
这些是旧 checkpoint 的开发集结果，不是新方法收益或新 A 组成绩。
2026-10-01 17:11:12 CST，正式 A 组 11830_0（内部 JobId 11831）
已在 gn3 / RTX3090 启动；B/C 为 11830_1/11830_2，按资源自动接续。

启动验收：A 组已实际完成 300 次更新，loss 和 gradient 有限，
内存峰值在初始更新后保持稳定；B/C 已排队，无需再次手动提交。
每组目标仍为 50000 completed updates。该状态仅证明实验已启动，尚无方法收益结论。

2026-10-01 23:50 CST 进度：A 的完整主指标 39.3468、50k 分数 39.4529，
开发集选定条件 12000；最终评测及 seeds 审计通过。B 完成 50k，
开发集选择条件 4985.1416，正在评测。C 原因调度排队尚未开始；
根据 A/B 实际训练约 4.4 小时，将尚未启动的 C 作业时限由 24h 改为
8h，并刷新原并发上限 2（学习参数不变）。C 随后于 23:49:14 在 gn5
启动，已核验初始模型及前三次实际训练输入、dropout RNG 与 B 匹配。
在 C 完成最终评测前不作方法增益判断。

## 50k 初筛最终结果（2026-10-02）

A/B/C 均以 exit 0 完成，最后 C 于 05:12:20 CST 结束。
配对、条件选择和评测审计通过，最终报告见新 campaign 的 `report_zh.md`。

| 组别 | 主指标：30/35/40/45/50k 均分 | 50k 得分 | 条件 |
|---|---:|---:|---:|
| A 普通 DT | 39.3468 | 39.4529 | 12000（开发集选择） |
| B matched DT | 39.7274 | 39.9101 | 4985.1416（开发集选择） |
| C threshold DT | 37.9665 | 39.2047 | 4590.9743（预先固定 q90） |

C−A = −1.3804，C−B = −1.7609，未通过预设单 seed 初筛。
B−A = +0.3805，收益较小；本轮未观察到门槛条件带来的额外收益。
C 的五个 checkpoint 分别为 36.82、38.80、37.98、37.03、39.20，
每个点均低于两个对照。50k 追近 A，但后期曲线波动，不能据最后一个点
认定持续追赶或推断 100k 一定改善。这也不证明跨 seed 或 100k 下普遍无效。
后期曲线数据在 campaign `analysis/late_window_scores.csv`。
按用户约定，先审阅 50k 效果；未自动启动 100k 延长或其他 seed。

## W&B 补传（2026-10-02）

按用户要求，已将本轮三组结果补传至现有 CORL-DDR 项目。
实验组：[Threshold-DT-HCMR-delayed-seed0-50k-20261001](https://wandb.ai/2820402607-shandong-university/CORL-DDR/groups/Threshold-DT-HCMR-delayed-seed0-50k-20261001)。

- [dt](https://wandb.ai/2820402607-shandong-university/CORL-DDR/runs/b459d5e5e36d1a5c)
- [matched_dt](https://wandb.ai/2820402607-shandong-university/CORL-DDR/runs/ed8e0cab16574490)
- [threshold_dt](https://wandb.ai/2820402607-shandong-university/CORL-DDR/runs/e6f5aa9a333fa8b5)

每组 503 条训练记录及五个最终评测点，使用 completed_updates 作为横轴。
关键曲线为 eval/normalized_score_mean，主指标为 result/primary_score。
逐 episode 结果、配置、原始 JSON/JSONL、配对审计和报告保存在表格及结果 artifact。
这是已完成实验的补传；没有重新训练、评测或启动 100k。
已从云端读回并逐项核验全部训练 loss/更新步数、五个评测点和主指标。
机器可读记录：campaign wandb_upload/manifest.json 和 verification.json。
可重复补传入口：scripts/dt_experiments/upload_threshold_wandb.py，稳定 run ID 避免重复创建。
