# 连续片段行为分析

本实验分析 HalfCheetah-medium-replay-v2 高回报轨迹的持续行为差异。
不训练策略、不执行模拟器、不生成逐步奖励或 AWR 权重。

使用202条完整轨迹。每条含1000组动作及1001个对齐的状态（最后一个来自
next_observations），逐项核验所有episode内部的 next_observations 与下一条
observations 完全一致。原始奖励只汇总一次为float32终局总回报，随后丢弃。

沿用seed20261002的141/61轨迹划分，发现集q80确定高回报组，归一化只使用发现集。
61条验证轨迹已用于之前的共识诊断，本次是探索性验证，不称为新独立复验。
20步主分析每条50个不重叠片段，50步敏感性分析每条20个片段。
每个片段指标基于执行H个动作后的H个状态，速度变化明确减去起始速度。

固定指标包括速度均值、相对起点的平均速度增量、末端速度变化、速度标准差，
躯干高度、绝对倾角、倾角圆标准差、关节角标准差，动作RMS、相邻动作差RMS，
以及前后腿对应thigh/shin/foot动作的相关系数。后者只是协调模式描述，
不等同于步态质量；动作恒定时相关系数按0记录，不解释为协调证据。
姿态、动作平滑度、速度等均不转换为奖励标签。

匹配使用起点完整17维状态。参考轨迹只来自发现集，排除查询轨迹，时间差≤5步，
发现集标准化状态RMSE≤0.5，每条参考轨迹仅提供最近的一个起点，最多32个邻居。
至少12个邻居且高回报和其他组各不少于4个，才算受支持窗口。
对每个指标计算“实际片段指标−邻居片段指标均值”，再比较高回报和其他查询轨迹。
这是固定发现集参考下的局部基准扣除，不是随机实验或真实局部优势估计。
同时保存匹配前原始差异、匹配子集原始差异、扣除后的差异及残留起点不平衡。

先按轨迹平均，再做10000次组内轨迹bootstrap。匹配分析要求轨迹至少20%的窗口
有支持（H20至少10个，H50至少4个），每组至少10条轨迹才允许提出规律候选。
bootstrap条件于固定发现集参考，不包含参考轨迹抽样的不确定性。
13个固定指标用bootstrap最大标准化偏差构造同时95%区间，减少多指标筛选误判。
发现集H20扣除后同时区间不跨0的方向，先写入discovery_lock.json；随后检查
验证集H20同时区间是否同向，H50普通95%区间只作敏感性检查。
不能用探索性关联证明关键片段、因果效应或AWR训练收益。

入口：

```bash
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \
  /labmount/users/202615385/miniforge3/envs/adt-delayed/bin/python \
  algorithms/offline/segment_behavior_analysis.py --output results/segment-behavior-20261002
MPLCONFIGDIR=/tmp/segment-behavior-matplotlib OPENBLAS_NUM_THREADS=2 \
  python3 results/segment-behavior-20261002/source/scripts/dt_experiments/plot_segment_behavior.py \
  --root results/segment-behavior-20261002
```

上传从登录节点执行冻结的upload_segment_behavior.py，避免计算节点的本机代理问题。
图表用系统Python的matplotlib生成PNG和PDF，分析用原conda环境NumPy/h5py，
无需安装依赖或改动训练环境。冻结源码、协议、划分、候选方向、窗口索引、
邻居索引、排除原因、CSV与统计表均保存，可同步至CORL-DDR独立分析组。
