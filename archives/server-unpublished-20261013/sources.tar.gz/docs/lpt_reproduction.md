# LPT：HalfCheetah-medium-replay-v2 原始奖励 / 整局延迟奖励复现

[论文](https://arxiv.org/abs/2402.04647)，NeurIPS 2024；[官方代码](https://github.com/mingluzhao/Latent-Plan-Transformer)，固定提交 `c4e77cb464c6360733a9ce76d8870f076c76d0aa`。

本轮复现基础 **LPT**，两种奖励设置各独立运行 seed 0，使用同一批 202 条完整的 1000 步 HalfCheetah-medium-replay-v2 轨迹。LPT-EI 是另一个包含 expert iteration 的扩展，不属于本轮基础方法。论文基础 LPT 对应得分 **39.64±0.83（5 个训练 seed 的标准差）**；40.66±0.12 是 LPT-EI，不混作本轮对标值。

## 为什么这两种奖励设置应当等价

LPT 通过潜变量关联完整轨迹与总回报。训练时从状态、动作和轨迹总回报推断潜变量，再训练动作解码器和回报预测器；执行前根据目标总回报推断一个潜在计划，整个 episode 使用这个计划。它不是逐步 RTG 条件化的 DT。

原始组保留逐步奖励；延迟组前 999 步为零，最后一步为全轨迹奖励之和。官方 collator 虽然还计算了 `returns_to_go`，但模型没有消费这个字段，只使用总回报。因此在总回报、采样、初始权重和随机流一致时，两组应该产生相同的训练信号。实施中仍传入各自真实 RTG，通过损失、梯度及 PMC 缓存的一致性测试验证它被忽略，不伪造两个不同方法，也不把两个相同 seed 当成独立证据。

## 固定实验设置

| 项目 | 设置 |
|---|---|
| 模型 | 官方 Transformer 3 层、1 head、hidden 128；U-Net 潜变量映射 |
| 潜变量 | 4 × 128 维；每条轨迹维护 persistent Markov chain 缓存 |
| 完整轨迹长度 | 1000 步，训练时不截成短片段 |
| 注意力窗口 | 官方 `window_size=32`，源码作用于交错 state/action **token**，不是另改成 32 个环境步；FlashAttention 左边界含端点 |
| Langevin | 步长 0.3；训练 3 步，推理 20 步；保留源码噪声 |
| 损失 | masked action MSE + 0.25 × 总回报预测 MSE |
| 优化器 | AdamW lr 1e-4，weight decay 1e-4，梯度裁剪 0.25 |
| 调度 | 10% warmup，线性衰减 |
| 训练预算 | 官方 2000 epochs；每个 epoch 一次更新，合计 **2000 次更新** |
| batch | 官方上限 500，但 dataset 只有 202 行且不丢尾批，实际每次按长度有放回采样 **202 条完整轨迹** |
| 显存适配 | 每 4 条完整轨迹计算一次梯度，累积到完整 202 条后更新；潜变量缓存延后到完整 batch 结束再提交 |
| 回报 | gamma=1，scale=1000，推理目标 6000/1000=6，全程不读取环境中间奖励作为条件 |
| 中间评测 | 500/1000/1500 updates 各 10 episodes，逐条 seed `271828+i` |
| 最终评测 | 2000 updates，50 episodes，逐条新 seed `161803+i`，主结果为最终均分，不选 best |

名义 batch 500 与实际 batch 202 的区别来自官方 Trainer/DataCollator 的行为，不能误报为 2000×500 条轨迹更新。每个 epoch 的有放回采样也不保证遍历每条轨迹。

## 官方实现的必要修复与适配

原始文件不修改，复制到 campaign 的 `source/upstream` 并保存哈希。适配集中在 `algorithms/offline/lpt_compat.py`、`lpt_repro.py`：

1. 官方代码强制使用未在环境文件中完整配置的 FlashAttention。用分块局部因果注意力实现同一数学算子，保留 `softmax_scale=1.0`、窗口端点和源码 Q/K/V 半精度转换；FP32 累积，支持现有 GPU 和 CPU 短测。通过与完整 masked attention 的输出和梯度比较验证。它不是 FlashAttention 内核的逐位复刻。
2. `z_best_idx` 原实现保存的是 batch 内偏移，修为真实轨迹 ID。PMC 缓存原本是普通 Python 字典，不在 `state_dict` 内；所有 checkpoint 额外保存它、最高回报、最佳轨迹 ID，以及优化器、调度器和随机状态。
3. 原采样会包含重复轨迹索引。为避免 GPU 高级索引重复写的未定义行为，明确采用样本顺序中最后一次写入。分批时冻结整个逻辑 batch 的初始 PMC，最后统一提交，避免提前写入改变后续样本的潜变量初始化。
4. 官方 `infer_z_given_y` 退出时调用 `train()`；评测显式恢复 `eval()`，防止动作执行阶段意外启用 dropout。执行动作填回当前历史位置，再给下一步添加零占位，修复官方评测中历史动作整体错位一步的问题。
5. 使用实际训练集的归一化参数，逐 episode 显式设置随机种子，评测前后恢复训练随机状态。官方 HalfCheetah-v3 与此前 D4RL 环境的同种子转移通过短测核验。环境奖励仅用于报告分数，不进入训练。

这些都是公开记录的适配和修复，因此称为**基于官方实现、带修复的复现**，不称未经修改的源码逐位复现。分批改变噪声/dropout 随机数顺序，但两组使用完全相同的分批规则；无噪声测试核验分批与整批目标/梯度一致。论文正文提到 PMC 训练 2 步，发布实现为 3 步，本轮采用发布实现。

## 验收与记录

测试覆盖局部注意力的输出/梯度、官方 collator 标签一致性、原始/延迟损失与梯度相同、重复轨迹 PMC 更新、最佳轨迹索引、优化器＋潜变量缓存恢复。Slurm CPU 短测使用完整网络及真实 1000 步轨迹，验证两组梯度/PMC 相同，重复短 rollout 完全一致。

每 50 次更新保存可恢复 checkpoint；每个评测点保留独立权重及 PMC。保存逐 batch 轨迹索引、逐 episode 回报、训练日志、数据/代码哈希和中文报告。`prepare / smoke / train / summarize` 为独立入口，不修改历史 DT 或 DD 实验。

W&B 项目 **CORL-DDR**，独立组 `LPT-HCMR-dense-vs-delayed-seed0-20261002`。从登录节点仅同步必要超参数、数值曲线、逐 episode 结果表；不上传源码、完整协议、数据或模型。两组各申请任意 NVIDIA GPU 1 张、2 CPU、8 GB，最长 72 小时，CPU 短测成功后才启动。
