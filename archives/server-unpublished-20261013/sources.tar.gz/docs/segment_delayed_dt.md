# 片段级 delayed DT

本轮只跑HalfCheetah-medium-replay-v2、seed0，从头训练50k；不自动续训或扩展seed。
普通DT复用threshold campaign已完成的A组：后期均分39.3468、50k为39.4529，
部署条件12000由此前独立开发集选定。不复用threshold DT或matched DT作为基础对照。

每次照旧按轨迹长度、均匀起点采样20步，使用该片段的原始奖励和作为所有有效位置
的RTG。等价于在片段内把奖励集中到最后一个有效位置，再计算gamma=1的RTG。
尾部不足20步时只累加实际步数并沿用原padding与masked MSE分母，不越过episode。
这需要原始逐步奖励，监督比整局terminal-only更细；不能声称同等奖励信息下改善。

所有202条轨迹的完整20步滑动片段共198162个，q90在训练及环境评测前冻结。
推理仍滑动context20、每次执行一个动作；目标为固定片段q90乘.001，整个episode不递减。
条件表达局部片段行为回报水平，不是保证未来20步回报，也不把240作为默认条件。

复用普通DT主干、batch4096、hidden128、3层/1head、dropout.1、AdamW lr.0008、
warmup10k、clip.25、reward_scale.001。使用原基线的私有采样流及初始化seed0，
审计全部索引流、轨迹采样计数和抽查状态动作、mask、时间步；唯一数据字段差异为RTG。
允许任意NVIDIA GPU，硬件与dropout随机流匹配情况单独记录，不伪称不同硬件位级等价。

先运行3步完整batch smoke和1个独立seed episode；正式训练前重新初始化。
保存0/10/20/30/35/40/45/50k checkpoint。训练后固定q90评测后五个checkpoint，
每点100局，逐episode seeds271828+i，与已有基线相同；以五点均分作为主指标，
50k单点辅助，不按best挑结果，不用这些评测选择条件或生成训练标签。

入口`segment_delayed_dt.py prepare|smoke|train --root CAMPAIGN`。
prepare直接读HDF5，无MuJoCo初始化，冻结协议、标签、源码和历史基线文件哈希。
Slurm任意单GPU、2CPU、4GB、8小时；无空闲GPU时可先用CPU跑smoke，再依赖其成功
排队正式GPU训练。CPU smoke与正式GPU训练均保留，不覆盖失败结果。
登录节点sync_segment_delayed_dt.py负责一次性有时限的在线同步；不提交、重试或扩展作业。
W&B独立组同时展示基线导入曲线和新训练曲线，基线明确标注复用并链接原run。
训练/评测横轴都是completed_updates；仅上传实验指标、必要超参数、逐episode回报和
生成的结果报告，源码、完整协议、数据集和checkpoint保留本地。
完成后读回所有训练loss、五点评测均值和表格行数核验。

本campaign的初始上传脚本因包含源码/完整协议被自动审批拒绝，尚未执行。
实际使用经过收窄的`execution/sync_results_only.py`，修改记录在`upload_amendment.json`；
冻结的科学协议及训练源码未变。短测首次CPU 4GB内存不足，保留失败目录后用16GB重试；
正式GPU训练资源不变。详情见`cpu_smoke_resource_amendment.json`和`submission.json`。
