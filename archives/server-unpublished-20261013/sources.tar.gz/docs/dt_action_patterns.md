# DT连续动作模式复现诊断

冻结threshold campaign的A组普通DT seed0/50k；不训练、不替换动作。
入口 `algorithms/offline/diagnose_dt_action_patterns.py` 有offline、rollout、summarize
三个模式。offline --prepare-only在CPU上冻结协议、源码与输入哈希，不加载模型。

离线对全部202条轨迹逐步使用真实历史，最多20步。当前动作置零，窗口不重置历史，
只取滑动上下文最后一个位置的预测。分别输入实际轨迹回报和12000，乘checkpoint
reward_scale并保持不递减。状态使用checkpoint归一化。模型见过全部数据，
原61条验证子集只是分析分组，不能称为模型泛化验证。主要组为其中18条高回报轨迹。

使用20/50步不重叠动作片段；指标包括MSE、动作幅度RMS、相邻动作差RMS的模型/参考
比值，以及前后大腿动作相关系数的模型减参考差值。复用先前片段公式；任一大腿动作
标准差小于1e-6则相关未定义，不填零。参考变化RMS小于等于1e-6时比值也未定义。
每个窗口先计算比值/差，再在每条轨迹内平均，最后等权比较轨迹。保存未定义计数。

真实rollout固定12000条件，seeds535353–535372，每局1000步，记录完整状态、动作、
回报。首局重复一次核验确定性，最大状态/动作/奖励/得分绝对误差≤1e-6。
高回报参考仅来自发现集；匹配使用发现集归一化、完整17维起始状态RMSE≤0.5、
速度差≤0.25m/s、时间差≤5。先过滤所有候选位置，再每条轨迹取一个最近起点，
最多32条且至少4条。不得按未来片段结果选择邻居。参考相关系数至少要有4条有效轨迹。
H20至少10局/100片段，H50至少10局/40片段；不足时标记支持不足，不改阈值。

主要两指标使用10000次轨迹/episode bootstrap与最大标准化偏差构造同时95%区间。
每个指标至少10个有效单位才判定；缺失不填零。变化压小标记：比值均值≤.90且
区间上界<1；负相关削弱标记：成对有效参考相关均值<0，差值≥.05且区间下界>0。
区间条件于固定发现集参考，不包含参考样本不确定性。指标只诊断模式差异，不能
证明MSE有害平均化；数据中的探索噪声也可能造成动作变化更大。

核验：当前/未来动作与未来状态不能影响当前预测（误差≤1e-6）；batch与逐样本输出
误差≤2e-5；同一轨迹的历史起点、当前零动作、末端窗口、条件缩放、因果遮罩及
前后权重/数据哈希均审计。近常量相关、缺失统计和匹配先过滤后去重有CPU单元测试。

运行：

```bash
/labmount/users/202615385/miniforge3/envs/adt-delayed/bin/python \
  algorithms/offline/diagnose_dt_action_patterns.py offline --prepare-only \
  --output results/dt-action-patterns-20261002
sbatch results/dt-action-patterns-20261002/source/scripts/dt_experiments/run_dt_action_patterns.sbatch \
  "$PWD/results/dt-action-patterns-20261002"
```

Slurm申请任意NVIDIA单卡、2CPU、4GB、1小时。计算任务只写本地结果。
登录节点执行冻结的finish_dt_action_patterns.py --root ... --wait-job JOBID，
进行一次性、最长4小时的等待，完成后生成静态PNG/PDF图表和报告、同步CORL-DDR并读回
核验。无完整GPU结果则停止，不自动提交额外任务。也可不加--wait-job直接处理已完成结果。
登录节点负责上传，避免此前计算节点无法连接本机网络代理的问题。
