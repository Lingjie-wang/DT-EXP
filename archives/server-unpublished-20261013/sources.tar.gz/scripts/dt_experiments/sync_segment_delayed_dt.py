"""One-shot login-node W&B bridge for a single authorized Slurm training job.

Records the reused baseline once; streams local training/evaluation files and
uploads completed results. Does not submit, retry or extend training jobs.
"""
import argparse
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import time

import wandb


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    tmp.replace(path)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def history(path):
    if not path.exists():
        return []
    # A line may still be being written by the compute process.
    raw = path.read_text()
    lines = raw.splitlines()
    if raw and not raw.endswith('\n'):
        lines = lines[:-1]
    return [json.loads(line) for line in lines if line.strip()]


def init_run(p, directory, identity, name, job_type, config):
    run = wandb.init(entity=p['wandb_entity'], project=p['wandb_project'],
        group=p['wandb_group'], id=identity, resume='allow', mode='online',
        dir=str(directory), name=name, job_type=job_type, config=config,
        settings=wandb.Settings(_disable_stats=True, _disable_meta=True, disable_code=True,
                               disable_git=True, console='off', start_method='thread'))
    run.define_metric('completed_updates')
    for pattern in ['train/*', 'eval/*']:
        run.define_metric(pattern, step_metric='completed_updates')
    return run


def experiment_settings(config):
    """Only experiment hyperparameters; no paths, source, hashes or full protocol."""
    keys = ['arm', 'train_seed', 'reward_mode', 'env_name', 'batch_size', 'seq_len',
            'episode_len', 'embedding_dim', 'num_layers', 'num_heads',
            'attention_dropout', 'residual_dropout', 'embedding_dropout',
            'learning_rate', 'betas', 'weight_decay', 'clip_grad', 'warmup_steps',
            'update_steps', 'reward_scale', 'target_returns', 'segment_length',
            'torch_version', 'numpy_version', 'cuda_version', 'gpu']
    return {key: config[key] for key in keys if key in config}


def log_training(run, row):
    run.log({'completed_updates': row['completed_updates'], 'train/loss': row['train_loss'],
             'train/gradient_norm': row['gradient_norm'], 'train/learning_rate': row['learning_rate'],
             'train/elapsed_seconds': row['elapsed_seconds'],
             'train/cuda_peak_allocated_mib': row['cuda_peak_allocated_mib']})


def log_evaluation(run, row):
    run.log({'completed_updates': row['completed_updates'],
             'eval/normalized_score_mean': row['mean_score'],
             'eval/target_return': row['target_return'], 'eval/episodes': len(row['episodes'])})


def verify_history(remote, rows, evaluations):
    records = list(remote.scan_history(keys=['completed_updates', 'train/loss'], page_size=1000))
    mapped = {r['completed_updates']: r['train/loss'] for r in records}
    for row in rows:
        assert math.isclose(mapped[row['completed_updates']], row['train_loss'], rel_tol=0, abs_tol=1e-8)
    scores = list(remote.scan_history(keys=['completed_updates', 'eval/normalized_score_mean'], page_size=1000))
    mapped = {r['completed_updates']: r['eval/normalized_score_mean'] for r in scores}
    for row in evaluations:
        assert math.isclose(mapped[row['completed_updates']], row['mean_score'], rel_tol=0, abs_tol=1e-8)


def baseline(p, root, directory, identity):
    marker = directory/'baseline_verification.json'
    base = Path(p['baseline'])
    summary = read(base/'summary.json')
    if marker.exists():
        return read(marker)
    run = init_run(p, directory, identity, 'A-ordinary-DT-reused-seed0-50k',
        'reused-baseline', dict(experiment_settings(read(base/'config.json')), reused_without_training=True,
                               original_run_url=p['baseline_url']))
    try:
        rows = history(base/'metrics.jsonl')
        for row in rows:
            log_training(run, row)
        for row in summary['evaluations']:
            log_evaluation(run, row)
        run.summary.update({'result/primary_score': summary['primary_score'],
            'result/final_50k_score': summary['last_score'], 'baseline/reused': True,
            'baseline/original_url': p['baseline_url'], 'status': 'completed_baseline_import'})
        table = wandb.Table(columns=['completed_updates', 'episode_seed', 'normalized_score'])
        for row in summary['evaluations']:
            for ep in row['episodes']:
                table.add_data(row['completed_updates'], ep['episode_seed'], ep['normalized_score'])
        run.log({'tables/episodes': table})
        artifact = wandb.Artifact('segment-delayed-baseline-'+identity, type='baseline-results')
        for name in ['summary.json', 'metrics.jsonl']:
            artifact.add_file(str(base/name), name=name)
        run.log_artifact(artifact)
        url = run.url
        run.finish()
    except BaseException:
        run.finish(exit_code=1)
        raise
    remote = wandb.Api(timeout=45).run(f"{p['wandb_entity']}/{p['wandb_project']}/{identity}")
    verify_history(remote, rows, summary['evaluations'])
    result = dict(id=identity, url=url, verified=True, reused=True,
                  training_rows=len(rows), evaluation_points=5, original_url=p['baseline_url'])
    write(marker, result)
    return result


def job_state(job):
    if not job:
        return 'UNKNOWN'
    result = subprocess.run(['sacct', '-n', '-X', '-j', job, '--format=State,ExitCode', '-P'],
                            check=True, capture_output=True, text=True)
    lines = [r.strip() for r in result.stdout.splitlines() if r.strip()]
    return lines[0].split('|')[0] if lines else 'PENDING_ACCOUNTING'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--job', required=True)
    parser.add_argument('--max-hours', type=float, default=48)
    args = parser.parse_args()
    root = args.root.resolve()
    p = read(root/'protocol.json')
    for name, value in p['source_sha256'].items():
        assert digest(root/'source'/name) == value
    directory = root/'wandb_sync'
    directory.mkdir(exist_ok=True)
    with (directory/'bridge.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        identity = digest(root/'protocol.json')[:12]
        ref = baseline(p, root, directory, identity+'base')
        marker = directory/'verification.json'
        if marker.exists() and read(marker)['complete']:
            print(json.dumps(read(marker)), flush=True)
            return
        run_id = identity+'seg'
        state_path = directory/'cursor.json'
        cursor = read(state_path) if state_path.exists() else dict(training_step=0, evaluation_steps=[])
        settings = dict(experiment_settings(p['training_config']),
            evaluation_episodes=p['evaluation_episodes'], evaluation_seed=p['evaluation_seed'],
            primary_window=p['primary_window'], fixed_segment_q90=p['evaluation_target'],
            uses_original_dense_rewards=True, baseline_reused=True)
        run = init_run(p, directory, run_id, 'B-segment-delayed-DT-seed0-50k',
                       'training', settings)
        write(directory/'manifest.json', dict(group=p['wandb_group'], baseline=ref,
            segment=dict(id=run_id, url=run.url), job=args.job, bridge_pid=os.getpid(),
            protocol_sha256=digest(root/'protocol.json')))
        print(json.dumps(dict(run_url=run.url, baseline_url=ref['url'], watching_job=args.job)), flush=True)
        run.summary.update({'status': 'queued', 'training/complete': False,
            'target/segment_q90': p['evaluation_target'], 'baseline/primary_score': read(root/'baseline_reference.json')['primary_score'],
            'supervision/uses_original_dense_rewards': True, 'slurm/job_id': args.job})
        started = time.monotonic()
        previous_status = None
        runtime_added = False
        try:
            while time.monotonic()-started < args.max_hours*3600:
                rows = history(root/'run/metrics.jsonl')
                for row in rows:
                    if row['completed_updates'] > cursor['training_step']:
                        log_training(run, row)
                        cursor['training_step'] = row['completed_updates']
                        write(state_path, cursor)
                evaluations = []
                for file in sorted((root/'run/evaluation').glob('heldout-*.json')):
                    row = read(file)
                    evaluations.append(row)
                    if row['completed_updates'] not in cursor['evaluation_steps']:
                        log_evaluation(run, row)
                        cursor['evaluation_steps'].append(row['completed_updates'])
                        write(state_path, cursor)
                if not runtime_added and (root/'run/config.json').exists():
                    run.config.update({'runtime': experiment_settings(read(root/'run/config.json'))}, allow_val_change=True)
                    runtime_added = True
                state = job_state(args.job)
                complete = (root/'completion.json').exists()
                status = ('completed' if complete else 'evaluating' if (root/'run/training_summary.json').exists()
                          else 'training' if rows else 'starting' if state == 'RUNNING' else 'queued')
                failed = any(state.startswith(s) for s in ['FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY', 'NODE_FAIL', 'BOOT_FAIL', 'PREEMPTED'])
                if failed and not complete:
                    status = 'job_failed'
                run.summary.update({'status': status, 'slurm/state': state,
                                    'training/completed_updates': cursor['training_step']})
                write(directory/'status.json', dict(status=status, slurm_state=state,
                    completed_updates=cursor['training_step'], evaluation_points=len(evaluations), updated_unix=time.time()))
                if status != previous_status:
                    print(json.dumps(dict(status=status, job_state=state, completed_updates=cursor['training_step'])), flush=True)
                    previous_status = status
                if complete:
                    summary = read(root/'run/summary.json')
                    assert summary['complete'] and cursor['training_step'] == 50000 and len(evaluations) == 5
                    assert [r['completed_updates'] for r in rows] == [1, 2, 3, *range(100, 50001, 100)]
                    run.summary.update({'training/complete': True, 'result/primary_score': summary['primary_score'],
                        'result/final_50k_score': summary['last_score'], 'result/delta_vs_baseline': summary['primary_delta'],
                        'audit/input_pairing_passed': summary['training']['baseline_input_pairing_passed']})
                    table = wandb.Table(columns=['completed_updates', 'episode_seed', 'return', 'normalized_score'])
                    for row in evaluations:
                        for ep in row['episodes']:
                            table.add_data(row['completed_updates'], ep['episode_seed'], ep['return'], ep['normalized_score'])
                    run.log({'tables/episodes': table})
                    artifact = wandb.Artifact('segment-delayed-'+identity, type='experiment-results')
                    # Explicit results allowlist. Never upload source, protocols,
                    # datasets, checkpoints, environment files or whole directories.
                    files = [root/'run/metrics.jsonl', root/'run/summary.json',
                             root/'segment_statistics.json', root/'report_zh.md']
                    files += sorted((root/'run/evaluation').glob('heldout-*.json'))
                    for file in files:
                        artifact.add_file(str(file), name=str(file.relative_to(root)))
                    run.log_artifact(artifact)
                    url = run.url
                    run.finish()
                    remote = wandb.Api(timeout=45).run(f"{p['wandb_entity']}/{p['wandb_project']}/{run_id}")
                    verify_history(remote, rows, evaluations)
                    assert remote.summary['tables/episodes']['nrows'] == 500
                    assert math.isclose(remote.summary['result/primary_score'], summary['primary_score'], abs_tol=1e-8)
                    write(marker, dict(complete=True, remote_verified=True, url=url,
                        training_rows=len(rows), evaluation_points=5, episode_rows=500,
                        primary_score=summary['primary_score'], delta=summary['primary_delta']))
                    print(json.dumps(read(marker)), flush=True)
                    return
                if failed or state.startswith('COMPLETED'):
                    raise RuntimeError(f'Job {args.job} ended {state} without complete results')
                time.sleep(30)
            raise TimeoutError('One-shot upload window expired; training was not changed')
        except BaseException as error:
            write(directory/'bridge_error.json', dict(error=repr(error), completed_updates=cursor['training_step']))
            run.finish(exit_code=1)
            raise


if __name__ == '__main__':
    main()
