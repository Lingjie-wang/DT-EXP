"""Import completed threshold-DT results into W&B without running training."""

import argparse
import hashlib
import importlib.util
import json
import math
import statistics
from pathlib import Path


ARMS = ("dt", "matched_dt", "threshold_dt")
NAMES = {"dt": "A-ordinary-DT", "matched_dt": "B-matched-DT",
         "threshold_dt": "C-threshold-DT"}


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def prepare(root):
    spec = importlib.util.spec_from_file_location(
        "frozen_threshold_campaign", root / "source/scripts/dt_experiments/threshold_campaign.py"
    )
    campaign = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(campaign)
    protocol = campaign.verify(root)
    audit = campaign.audit_seed(root / "pilot/seed0")
    result = read(root / "summary.json")
    if not result["pairing_passed"] or audit["summaries"] != result["summaries"]:
        raise AssertionError("Campaign result does not match completed audited runs")
    prepared = {}
    for arm in ARMS:
        directory = root / "pilot/seed0" / arm
        history = [json.loads(line) for line in
                   (directory / "metrics.jsonl").read_text().splitlines() if line.strip()]
        steps = [row["completed_updates"] for row in history]
        if steps != [1, 2, 3, *range(100, 50001, 100)]:
            raise AssertionError("Missing, repeated or incorrectly numbered updates")
        if not all(math.isfinite(value) for row in history for value in row.values()):
            raise AssertionError("Nonfinite training history")
        summary = result["summaries"][arm]
        evaluation = {row["completed_updates"]: row for row in summary["evaluations"]}
        prepared[arm] = {"config": read(directory / "config.json"),
                         "history": history, "evaluation": evaluation,
                         "summary": summary, "partition": read(directory / "partition.json")}
    return protocol, result, prepared


def table_payloads(wandb, data, result):
    selection = data["summary"]["selection"]
    heldout = wandb.Table(columns=["completed_updates", "episode_seed", "target_return",
                                  "return", "normalized_score", "length"])
    for step, row in data["evaluation"].items():
        for episode in row["episodes"]:
            heldout.add_data(step, episode["episode_seed"], row["target_return"],
                             episode["return"], episode["normalized_score"], episode["length"])
    comparison = wandb.Table(columns=["arm", "selected_condition", "primary_score", "last_score"])
    for arm in ARMS:
        item = result["summaries"][arm]
        comparison.add_data(arm, item["selection"]["target_return"],
                            item["primary_score"], item["last_score"])
    payload = {"tables/heldout_episodes": heldout, "tables/three_arm_comparison": comparison}
    candidates = selection["candidates"]
    if candidates:
        scan = wandb.Table(columns=["target_return", "normalized_score_mean", "episodes"])
        episodes = wandb.Table(columns=["target_return", "episode_seed", "return", "normalized_score"])
        for row in candidates:
            scan.add_data(row["target_return"], row["mean_score"], len(row["episodes"]))
            for episode in row["episodes"]:
                episodes.add_data(row["target_return"], episode["episode_seed"],
                                  episode["return"], episode["normalized_score"])
        payload["tables/development_rtg_scan"] = scan
        payload["tables/development_episodes"] = episodes
    return payload


def upload(args):
    root = args.root.resolve()
    protocol, result, prepared = prepare(root)
    print(json.dumps({"validated": True, "entity": args.entity, "project": args.project,
                      "group": args.group, "arms": list(prepared),
                      "history_rows_per_arm": 503, "heldout_episodes_per_arm": 500}), flush=True)
    if args.dry_run:
        return

    import wandb
    api = wandb.Api(timeout=45)
    if api.default_entity != args.entity:
        raise AssertionError("Authenticated account does not match the expected destination")
    api.project(args.project, entity=args.entity)
    destination = root / "wandb_upload"
    destination.mkdir(exist_ok=True)
    manifest_path = destination / "manifest.json"
    manifest = read(manifest_path) if manifest_path.exists() else {
        "entity": args.entity, "project": args.project, "group": args.group,
        "import_kind": "retrospective; original completed-update axis", "runs": {}}
    if any(manifest[key] != getattr(args, key) for key in ("entity", "project", "group")):
        raise AssertionError("Destination changed from the existing upload manifest")
    identity = hashlib.sha256((root.name + json.dumps(protocol["source_sha256"],
                                                      sort_keys=True)).encode()).hexdigest()[:12]
    for arm, data in prepared.items():
        run_id = hashlib.sha256(f"{identity}:{args.entity}:{args.project}:{arm}".encode()).hexdigest()[:16]
        path = f"{args.entity}/{args.project}/{run_id}"
        existing = manifest["runs"].get(arm)
        if existing and existing.get("complete"):
            remote = api.run(path)
            if remote.summary.get("import/complete"):
                print("Already uploaded:", remote.url, flush=True)
                continue
        config = {**data["config"], "original_project_config": data["config"]["project"],
                  "project": args.project, "group": args.group,
                  "import_kind": "retrospective", "campaign_identity": identity,
                  "actual_training_torch_version": data["config"]["torch_version"],
                  "primary_window": data["summary"]["window"],
                  "evaluation_condition": data["summary"]["selection"]["target_return"],
                  "condition_selection_rule": data["summary"]["selection"]["rule"],
                  "thresholds": data["partition"]["thresholds"],
                  "training_seed_count": 1, "evaluation_episodes_per_checkpoint": 100}
        run = wandb.init(entity=args.entity, project=args.project, group=args.group,
                         id=run_id, resume="allow", mode="online", dir=str(destination),
                         name=f"{NAMES[arm]}-seed0-50k", config=config,
                         job_type="completed-experiment-import",
                         tags=["threshold-dt", "delayed-reward", "seed0", "50k", "retrospective"],
                         notes="Imported from completed offline logs. Use completed_updates as x-axis. "
                         "One training seed; A/B conditions selected on development episodes, C fixed q90. "
                         "No training or new environment evaluation occurred during this upload.",
                         settings=wandb.Settings(_disable_stats=True, _disable_meta=True,
                                                 disable_code=True, disable_git=True,
                                                 console="off", start_method="thread", init_timeout=90))
        manifest["runs"][arm] = {"id": run_id, "url": run.url, "complete": False}
        write(manifest_path, manifest)
        try:
            run.define_metric("completed_updates")
            for key in ("train/*", "eval/*", "resource/*", "train_loss", "learning_rate"):
                run.define_metric(key, step_metric="completed_updates")
            start_step = run.step
            for row in data["history"]:
                step = row["completed_updates"]
                if step < start_step:
                    continue
                payload = {"completed_updates": step, "train_loss": row["train_loss"],
                           "learning_rate": row["learning_rate"],
                           "train/loss": row["train_loss"], "train/gradient_norm": row["gradient_norm"],
                           "train/learning_rate": row["learning_rate"],
                           "train/elapsed_seconds": row["elapsed_seconds"],
                           "resource/host_peak_rss_kib": row["host_peak_rss_kib"],
                           "resource/cuda_peak_allocated_mib": row["cuda_peak_allocated_mib"]}
                if step in data["evaluation"]:
                    evaluation = data["evaluation"][step]
                    scores = [item["normalized_score"] for item in evaluation["episodes"]]
                    returns = [item["return"] for item in evaluation["episodes"]]
                    payload.update({"eval/normalized_score_mean": evaluation["mean_score"],
                                    "eval/normalized_score_std": statistics.pstdev(scores),
                                    "eval/return_mean": statistics.mean(returns),
                                    "eval/target_return": evaluation["target_return"],
                                    "eval/episodes": len(scores)})
                if step == 50000:
                    payload.update(table_payloads(wandb, data, result))
                run.log(payload, step=step)

            artifact = wandb.Artifact(f"threshold-dt-{identity}-{arm}-results", type="evaluation-results",
                                     metadata={"arm": arm, "seed": 0, "updates": 50000,
                                               "pairing_passed": True, "retrospective": True})
            arm_dir = root / "pilot/seed0" / arm
            for file in sorted(arm_dir.rglob("*")):
                if file.is_file() and file.suffix in (".json", ".jsonl"):
                    artifact.add_file(str(file), name="run/" + str(file.relative_to(arm_dir)))
            for name in ("protocol.json", "summary.json", "report_zh.md", "resource_validation.json",
                         "analysis/late_window_scores.csv", "sweep/seed0/summary.json"):
                artifact.add_file(str(root / name), name="campaign/" + name)
            run.log_artifact(artifact)
            run.summary.update({"result/primary_score": data["summary"]["primary_score"],
                                "result/final_50k_score": data["summary"]["last_score"],
                                "result/primary_window": data["summary"]["window"],
                                "audit/pairing_passed": True,
                                "screen/C_minus_A": result["deltas"]["dt"],
                                "screen/C_minus_B": result["deltas"]["matched_dt"],
                                "screen/passed": result["positive_single_seed_signal"],
                                "import/history_rows": len(data["history"]),
                                "import/evaluation_checkpoints": len(data["evaluation"]),
                                "import/heldout_episodes": 500, "import/complete": True})
            run.finish(exit_code=0)
        except BaseException:
            run.finish(exit_code=1)
            raise
        manifest["runs"][arm]["complete"] = True
        write(manifest_path, manifest)
        print("Uploaded:", manifest["runs"][arm]["url"], flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--entity", default="2820402607-shandong-university")
    parser.add_argument("--project", default="CORL-DDR")
    parser.add_argument("--group", default="Threshold-DT-HCMR-delayed-seed0-50k-20261001")
    parser.add_argument("--dry-run", action="store_true")
    upload(parser.parse_args())
