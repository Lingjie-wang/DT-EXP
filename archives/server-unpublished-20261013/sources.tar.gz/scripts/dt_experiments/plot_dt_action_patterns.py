"""CPU figures/CSV/report for the completed frozen-DT reproduction check."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR','/tmp/dt-action-patterns-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def read(path):return json.loads(path.read_text())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    root=parser.parse_args().root.resolve()
    s=read(root/'summary.json')
    for name,digest in read(root/'result_manifest.json').items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    figures=root/'figures';figures.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'savefig.dpi':180})
    cases=[('Offline: actual return','actual_return'),('Offline: RTG 12000','rtg12000'),('Real rollout','rollout')]
    for h in ['20','50']:
        fig,axes=plt.subplots(1,2,figsize=(12,4.5))
        for ax,key in zip(axes,['change_ratio','corr_difference']):
            for i,(label,condition) in enumerate(cases):
                stats=s['rollout'][h] if condition=='rollout' else s['offline'][condition][h]['validation_high']
                v=stats['primary'][key]
                if v['mean'] is None:continue
                ci=v['simultaneous_ci95']
                color=['#187e96','#e28b29','#7656a6'][i]
                if ci is not None:ax.plot(ci,[i,i],color=color,lw=2)
                ax.scatter(v['mean'],i,s=45,color=color)
                ax.annotate(f" n={v['units']}",(v['mean'],i),xytext=(0,8),textcoords='offset points',fontsize=9)
            ax.set_yticks(range(3),[c[0] for c in cases]);ax.invert_yaxis();ax.set_ylim(2.6,-.6)
            ax.axvline(1 if key=='change_ratio' else 0,color='#555',lw=1)
            ax.axvline(.9 if key=='change_ratio' else .05,color='#999',ls='--',lw=1)
            ax.grid(axis='x',alpha=.2)
        axes[0].set_title('Consecutive-action change RMS ratio')
        axes[0].set_xlabel('DT / recorded reference; below 1 means smaller changes')
        axes[1].set_title('Back/front thigh correlation difference')
        axes[1].set_xlabel('DT - recorded reference; positive may weaken negative correlation')
        fig.suptitle(f'H={h}; simultaneous 95% cluster-bootstrap intervals\nOffline: 18 high-return trajectories seen in training. Rollout: matched high-return references.')
        fig.tight_layout()
        for ext in ['png','pdf']:fig.savefig(figures/f'primary_h{h}.{ext}',bbox_inches='tight')
        plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,4))
    for ax,h in zip(axes,['20','50']):
        units=read(root/'statistics'/f'rollout_h{h}_units.json')
        ax.bar([u['id'] for u in units],[u['windows'] for u in units],color='#187e96')
        ax.set_title(f'H={h}: {s["rollout"][h]["supported_windows"]} supported windows')
        ax.set_xlabel('Episode');ax.set_ylabel('Matched windows');ax.set_xticks(range(0,20,2))
    fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(figures/f'rollout_coverage.{ext}',bbox_inches='tight')
    plt.close(fig)
    with open(root/'comparisons.csv','w',newline='') as f:
        w=csv.writer(f);w.writerow(['source','horizon','group','metric','mean','units','simultaneous_ci95_low','simultaneous_ci95_high'])
        for condition in ['actual_return','rtg12000','rollout']:
            for h in ['20','50']:
                groups={'matched':s['rollout'][h]} if condition=='rollout' else s['offline'][condition][h]
                for group,stats in groups.items():
                    for metric,v in stats['primary'].items():
                        w.writerow([condition,h,group,metric,v['mean'],v['units'],*(v['simultaneous_ci95'] or [None,None])])
    def fmt(v):
        if v['mean'] is None:return '缺失'
        ci=v['simultaneous_ci95']
        return f"{v['mean']:.5f} [{ci[0]:.5f}, {ci[1]:.5f}]" if ci else f"{v['mean']:.5f}（支持不足）"
    lines=['# DT 连续动作模式复现检查','',
        '冻结普通DT seed0/50k，context20；没有训练、动作替换或新策略。',
        '离线诊断使用相同真实状态和历史动作，分别输入实际轨迹回报与RTG=12000。所有202条轨迹均在此DT的训练数据中。',
        '主要离线结果为原验证子集的18条高回报轨迹，属于复现诊断，不是泛化测试。',
        '真实rollout使用20个episode，seeds 535353–535372，恒定RTG=12000。','',
        '## 两项主要结果','',
        '| H | 对照 | 动作变化比值及同时95%区间 | 大腿相关系数差及同时95%区间 | 变化压小标记 | 负相关削弱标记 |',
        '|---|---|---|---|---|---|']
    for h in ['20','50']:
        for label,condition in cases:
            v=s['rollout'][h] if condition=='rollout' else s['offline'][condition][h]['validation_high']
            lines.append(f"| {h} | {label} | {fmt(v['primary']['change_ratio'])} | {fmt(v['primary']['corr_difference'])} | {v['change_compressed']} | {v['negative_correlation_weakened']} |")
    lines+=['','比值=DT动作变化RMS/记录动作变化RMS；每个窗口计算后先按轨迹/episode平均，再跨单位平均。',
        '工程标记：比值均值≤0.90且同时区间上界<1；数据相关为负时，相关系数差均值≥0.05且同时区间下界>0。',
        '近常量动作（对应大腿控制信号标准差<1e-6）相关系数记为未定义，不填零；完整计数在summary.json。','',
        '## 覆盖与状态匹配','']
    for h in ['20','50']:
        v=s['rollout'][h]
        lines.append(f"- H{h}：{v['supported_windows']}/{v['total_windows']}个窗口，{v['supported_episodes']}/20个episode；覆盖达标={v['coverage_sufficient']}。起始速度残差均值={v['mean_start_speed_difference']} m/s。")
    lines+=['','参考为发现集高回报轨迹。时间差≤5步、标准化状态RMSE≤0.5、起始速度差≤0.25m/s；先按这些条件过滤，再每条轨迹选择一个最近起点，至少4个邻居。',
        'bootstrap按轨迹/episode进行10000次；固定发现集参考，其抽样不确定性不包括在区间内。无支持episode记为缺失，不记零。','',
        '## 验收与解释','',f"- 预定分类：{json.dumps(s['interpretation'],ensure_ascii=False)}。",
        f"- 首个episode重复误差：{json.dumps(s['audit']['rollout']['repeat'])}。",
        f"- 两条件因果遮罩与批量推理检查：{json.dumps(s['audit']['offline']['checks'])}。",
        '- 模型、checkpoint和数据哈希检查通过；完整预测、rollout、逐窗口指标与邻居索引均保存。',
        '- 观察到变化更小或配合模式差异，不足以证明MSE做了有害平均化。数据可能包含探索噪声，较小变化也可能是合理去噪。',
        '- 本轮不检验动作分块策略收益，不自动启动训练。']
    (root/'report_zh.md').write_text('\n'.join(lines)+'\n')
    manifest={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in figures.glob('*')}
    for name in ['comparisons.csv','report_zh.md']:manifest[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
    (root/'presentation_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'plots':3,'report':str(root/'report_zh.md')}))


if __name__=='__main__':main()
