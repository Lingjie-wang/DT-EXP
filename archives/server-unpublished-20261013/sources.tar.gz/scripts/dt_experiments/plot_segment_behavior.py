"""Static scientific figures for the frozen segment analysis; system Python."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR','/tmp/segment-behavior-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def read(path):
    return json.loads(path.read_text())


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def band(values,seed=20261005):
    rng=np.random.default_rng(seed)
    n=len(values)
    weights=rng.multinomial(n,np.full(n,1/n),size=10000)/n
    ci=np.quantile(weights@values,[.025,.975],axis=0)
    return values.mean(0),ci


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args()
    root=args.root.resolve()
    summary,protocol=read(root/'summary.json'),read(root/'protocol.json')
    for name,digest in read(root/'analysis_manifest.json').items():
        assert hash_file(root/name)==digest,name
    keys=[f[0] for f in protocol['features']]
    labels=[f[1] for f in protocol['features']]
    units=[f[2] for f in protocol['features']]
    figures=root/'figures'
    figures.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'figure.dpi':120,'savefig.dpi':180})
    colors=['#147d92','#e28b29']
    def save(fig,name):
        for ext in ['png','pdf']:
            fig.savefig(figures/(name+'.'+ext),bbox_inches='tight')
        plt.close(fig)
    for split in ['discovery','validation']:
        data=np.load(root/f'{split}_h20_windows.npz')
        raw,high=data['raw_features'],data['high']
        centers=data['starts']+10
        fig,axes=plt.subplots(2,3,figsize=(13,7),sharex=True)
        panels=['speed_mean','speed_gain','pitch_abs_mean','action_rms','action_change_rms','thigh_action_corr']
        for ax,key in zip(axes.flat,panels):
            j=keys.index(key)
            for mask,color,name in [(high,colors[0],'High return'),(~high,colors[1],'Other returns')]:
                mean,ci=band(raw[mask,:,j])
                ax.plot(centers,mean,color=color,label=f'{name} (n={mask.sum()})',linewidth=1.7)
                ax.fill_between(centers,ci[0],ci[1],color=color,alpha=.16,linewidth=0)
            ax.set_title(labels[j])
            ax.set_ylabel(units[j])
            ax.grid(alpha=.18)
        axes[0,0].legend(frameon=False,fontsize=9)
        for ax in axes[-1]: ax.set_xlabel('Episode step')
        fig.suptitle(f'{split.title()}: 20-step segment profiles\nShading: pointwise 95% trajectory-bootstrap intervals; associations only')
        fig.tight_layout()
        save(fig,f'{split}_time_profiles')
    # Scale only for the forest visualization; original-unit estimates stay in CSV/JSON.
    disc=np.load(root/'discovery_h20_windows.npz')
    scales=disc['raw_features'].reshape(-1,len(keys)).std(0)
    scales=np.maximum(scales,1e-12)
    fig,axes=plt.subplots(1,2,figsize=(14,8),sharey=True)
    y=np.arange(len(keys))
    for ax,h in zip(axes,[20,50]):
        for split,offset,color in [('discovery',-.12,colors[0]),('validation',.12,colors[1])]:
            stats=summary[split][str(h)]['matched_residual']
            for j,key in enumerate(keys):
                if key not in stats['features']: continue
                value=stats['features'][key]
                point=value['difference']/scales[j]
                ci=np.asarray(value['simultaneous_ci95' if h==20 else 'ci95'])/scales[j]
                ax.plot(ci,[j+offset]*2,color=color,linewidth=1.7)
                ax.scatter(point,j+offset,color=color,s=22,label=split.title() if j==0 else None)
        ax.axvline(0,color='#555555',linewidth=1)
        ax.set_title(f'H={h}: '+('simultaneous 95% intervals' if h==20 else 'pointwise 95% sensitivity intervals'))
        ax.set_xlabel('High - other residual difference / discovery feature SD')
        ax.grid(axis='x',alpha=.2)
    axes[0].set_yticks(y,labels)
    axes[0].invert_yaxis()
    axes[0].legend(frameon=False)
    fig.suptitle('Differences after matching segment-start states\nTrajectory bootstrap, conditional on the fixed discovery reference; no causal interpretation')
    fig.tight_layout()
    save(fig,'matched_feature_differences')
    fig,axes=plt.subplots(1,2,figsize=(12,4),sharey=True)
    for ax,split in zip(axes,['discovery','validation']):
        data=np.load(root/f'{split}_h20_windows.npz')
        for mask,color,label in [(data['high'],colors[0],'High return'),(~data['high'],colors[1],'Other returns')]:
            fraction=data['supported'][mask].mean(0)
            ax.plot(data['starts']+10,100*fraction,color=color,label=label)
        ax.set_title(split.title())
        ax.set_xlabel('Episode step')
        ax.set_ylim(0,105)
        ax.grid(alpha=.2)
    axes[0].set_ylabel('Windows with a supported state neighborhood (%)')
    axes[0].legend(frameon=False)
    fig.suptitle('Matching coverage is restricted; excluded trajectories remain in the raw profiles')
    fig.tight_layout()
    save(fig,'matching_coverage')
    with open(root/'feature_comparisons.csv','w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['split','horizon','comparison','feature','high_trajectories','other_trajectories',
                         'high_mean','other_mean','difference','ci95_low','ci95_high','simultaneous_ci95_low','simultaneous_ci95_high'])
        for split in ['discovery','validation']:
            for h in ['20','50']:
                for comparison in ['all_windows','matched_windows_raw','matched_residual']:
                    s=summary[split][h][comparison]
                    for key,v in s['features'].items():
                        writer.writerow([split,h,comparison,key,s['high_trajectories'],s['other_trajectories'],
                                         v['high_mean'],v['other_mean'],v['difference'],*v['ci95'],*v['simultaneous_ci95']])
    manifest={str(p.relative_to(root)):hash_file(p) for p in figures.glob('*')}
    manifest['feature_comparisons.csv']=hash_file(root/'feature_comparisons.csv')
    (root/'figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'figures':len(list(figures.glob('*.png'))),'output':str(figures)}))


if __name__=='__main__':
    main()
