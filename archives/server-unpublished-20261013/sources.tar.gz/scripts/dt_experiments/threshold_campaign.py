"""Freeze, validate and summarize the explicitly single-seed threshold-DT pilot."""

import argparse
import fcntl
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "algorithms/offline"))
from threshold_dt import (  # noqa: E402
    ARMS,
    file_hash,
    PROFILES,
    read_json,
    select_target,
    write_json,
)

PILOT_ARMS = ARMS[:3]
SOURCES = (
    "algorithms/offline/threshold_dt.py", "algorithms/offline/dt.py",
    "configs/offline/dt/halfcheetah/medium_replay_v2.yaml",
    "scripts/dt_experiments/threshold_campaign.py",
    "scripts/dt_experiments/run_threshold_dt.sbatch",
    "tests/test_threshold_dt.py",
)


def initialize(root, expected_gpu="RTX 3090", num_workers=0):
    if not expected_gpu or num_workers < 0:
        raise ValueError("A GPU model and nonnegative loader worker count are required")
    root.mkdir(parents=True, exist_ok=False)
    hashes = {}
    for relative in SOURCES:
        target = root / "source" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
        hashes[relative] = file_hash(target)
    checkpoint = (ROOT / "checkpoints"
                  / "dt-halfcheetah-medium-replay-v2-delayed-seed0-step50000.pt")
    protocol = {
        "version": 2, "project_root": str(ROOT), "seeds": [0],
        "arms": list(PILOT_ARMS), "profile": "pilot", "source_sha256": hashes,
        "checkpoint": str(checkpoint), "checkpoint_sha256": file_hash(checkpoint),
        "expected_gpu": expected_gpu, "minimum_pilot_gain": 1.0,
        "execution": {"num_workers": num_workers, "cpu_threads": 2,
                      "torch_version": "1.13.1+cu117", "cuda_module_loading": "LAZY"},
        "automatic_confirmation": False,
        "single_seed_note": "Seed-0 screen only; neither efficacy nor failure "
        "is established across seeds. No automatic multi-seed or multi-task launch.",
        "logging": "local JSON/JSONL and checkpoints; W&B disabled",
        "profiles": PROFILES,
    }
    write_json(root / "protocol.json", protocol)
    print(json.dumps(protocol, indent=2))


def verify(root):
    protocol = read_json(root / "protocol.json")
    if protocol["seeds"] != [0] or protocol["arms"] != list(PILOT_ARMS):
        raise AssertionError("Only the approved single-seed pilot may be launched")
    for relative, expected in protocol["source_sha256"].items():
        if file_hash(root / "source" / relative) != expected:
            raise AssertionError(f"Frozen source changed: {relative}")
    if file_hash(protocol["checkpoint"]) != protocol["checkpoint_sha256"]:
        raise AssertionError("Historical checkpoint has changed")
    return protocol


def validate_evaluation(directory, summary, partition):
    profile = PROFILES[summary["profile"]]
    selection = read_json(directory / "evaluation/selection.json")
    if summary["selection"] != selection:
        raise AssertionError("Summary/committed selection mismatch")
    if summary["arm"] in ("dt", "matched_dt"):
        candidates = selection["candidates"]
        actual_targets = [row["target_return"] for row in candidates]
        if actual_targets != partition["candidate_returns"]:
            raise AssertionError("Development RTG grid mismatch")
        if selection["target_return"] != select_target(candidates):
            raise AssertionError("Target was not selected by development scores")
        for row in candidates:
            expected = list(range(31415, 31415 + profile["development_episodes"]))
            if [item["episode_seed"] for item in row["episodes"]] != expected:
                raise AssertionError("Development episode seeds mismatch")
            values = [item["normalized_score"] for item in row["episodes"]]
            mean = sum(values) / len(expected)
            if (not math.isfinite(mean)
                    or not math.isclose(mean, row["mean_score"], abs_tol=1e-10)):
                raise AssertionError("Incorrect/nonfinite development mean")
    elif selection["target_return"] != partition["primary_threshold"]:
        raise AssertionError("Fixed q90 condition changed")
    if summary["window"] != profile["window"]:
        raise AssertionError("Evaluation window mismatch")
    if [row["completed_updates"] for row in summary["evaluations"]] != profile["window"]:
        raise AssertionError("Missing or repeated checkpoint evaluation")
    scores = []
    for row in summary["evaluations"]:
        first_seed = profile["evaluation_seed"]
        expected = list(range(first_seed, first_seed + profile["evaluation_episodes"]))
        if [item["episode_seed"] for item in row["episodes"]] != expected:
            raise AssertionError("Held-out episode seeds mismatch")
        if row["target_return"] != selection["target_return"]:
            raise AssertionError("Condition changed after selection")
        mean = sum(item["normalized_score"] for item in row["episodes"]) / len(expected)
        if (not math.isfinite(mean)
                or not math.isclose(mean, row["mean_score"], abs_tol=1e-10)):
            raise AssertionError("Incorrect/nonfinite evaluation mean")
        scores.append(mean)
    if not math.isclose(sum(scores) / len(scores), summary["primary_score"],
                        abs_tol=1e-10):
        raise AssertionError("Incorrect primary score")


def audit_seed(root, arms=PILOT_ARMS):
    configs = {arm: read_json(root / arm / "config.json") for arm in arms}
    summaries = {arm: read_json(root / arm / "summary.json") for arm in arms}
    partitions = {arm: read_json(root / arm / "partition.json") for arm in arms}
    first = configs[arms[0]]
    ignored = {"arm", "slurm_job_id"}
    for arm in arms:
        for key in set(first) | set(configs[arm]):
            if key not in ignored and configs[arm].get(key) != first.get(key):
                raise AssertionError(f"Configuration mismatch {arm}: {key}")
        if partitions[arm] != partitions[arms[0]]:
            raise AssertionError("Dataset/thresholds differ between arms")
        summary = summaries[arm]
        expected_updates = PROFILES[first["profile"]]["updates"]
        if (not summary["complete"] or summary["arm"] != arm
                or summary["seed"] != first["train_seed"]
                or summary["profile"] != first["profile"]
                or summary["completed_updates"] != expected_updates):
            raise AssertionError("Incomplete or wrong-budget run")
        expected_samples = first["batch_size"] * first["update_steps"]
        if sum(summary["trajectory_sample_counts"]) != expected_samples:
            raise AssertionError("Wrong total number of training samples")
        validate_evaluation(root / arm, summary, partitions[arm])
    b, c = (summaries[arm] for arm in ("matched_dt", "threshold_dt"))
    for key in ("sample_stream_sha256", "trajectory_sample_counts",
                "condition_sample_counts"):
        if b[key] != c[key]:
            raise AssertionError(f"Full-stream B/C mismatch: {key}")
    expected_counts = [first["batch_size"] // 4 * first["update_steps"]] * 4
    if b["condition_sample_counts"] != expected_counts:
        raise AssertionError("Incorrect total threshold sampling counts")
    audits = [read_json(root / arm / "pairing_audit.json")
              for arm in ("matched_dt", "threshold_dt")]
    if not audits[0] or len(audits[0]) != len(audits[1]):
        raise AssertionError("Missing paired audits")
    for left, right in zip(*audits):
        for key in ("completed_updates", "batch_sha256", "torch_rng_sha256",
                    "sample_stream_sha256"):
            if left[key] != right[key]:
                raise AssertionError(f"B/C audit mismatch: {key}")
    return {"pairing_passed": True, "gpu": first["gpu"], "profile": first["profile"],
            "source_sha256": first["source_sha256"], "summaries": summaries}


def screen_result(scores, minimum_gain=1.0):
    deltas = {arm: scores["threshold_dt"] - scores[arm] for arm in ("dt", "matched_dt")}
    return {"deltas": deltas, "positive_single_seed_signal": all(
        delta >= minimum_gain for delta in deltas.values()),
        "minimum_gain": minimum_gain, "automatic_confirmation": False,
        "interpretation": "single-seed exploration; no multi-seed efficacy claim"}


def summarize(root, if_ready=False):
    protocol = verify(root)
    runs = root / "pilot/seed0"
    if not all((runs / arm / "summary.json").exists() for arm in PILOT_ARMS):
        if if_ready:
            print("Pilot still incomplete; no result or screening verdict emitted.")
            return
        raise AssertionError("Pilot incomplete")
    # The last array task publishes the report; simultaneous finish is harmless.
    with (root / "summary.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        result = audit_seed(runs)
        if result["profile"] != "pilot":
            raise AssertionError("Smoke cannot be reported as production")
        scores = {arm: row["primary_score"] for arm, row in result["summaries"].items()}
        result.update(screen_result(scores, protocol["minimum_pilot_gain"]))
        write_json(root / "summary.json", result)
        lines = ["# 回报门槛 DT：seed 0 探索结果", "",
                 "主指标为 30k/35k/40k/45k/50k 的平均 normalized score。",
                 "A/B 的条件仅按开发集选择；C 固定 q90。", "",
                 "| 组别 | 使用条件 | 后期均分 | 50k 最终分 |", "|---|---:|---:|---:|"]
        for arm in PILOT_ARMS:
            row = result["summaries"][arm]
            lines.append(f"| {arm} | {row['selection']['target_return']:.3f} | "
                         f"{row['primary_score']:.3f} | {row['last_score']:.3f} |")
        lines += ["", f"C−A：{result['deltas']['dt']:+.3f}；"
                  f"C−B：{result['deltas']['matched_dt']:+.3f}。",
                  "", "单 seed 筛选：" + ("达到两个对照各 +1 分的初步信号标准。"
                  if result["positive_single_seed_signal"] else "未达到预设初步信号标准。"),
                  "", "配对审计通过。单个训练 seed 不支持稳定有效或普遍无效的结论。",
                  "未自动启动更多 seed 或其他任务。", ""]
        (root / "report_zh.md").write_text("\n".join(lines))
        print(json.dumps({key: result[key] for key in
                          ("deltas", "positive_single_seed_signal", "pairing_passed")}))


def worker(args):
    root = args.root.resolve()
    protocol = verify(root)
    source = root / "source/algorithms/offline/threshold_dt.py"
    expected_gpu = protocol["expected_gpu"] if args.device.startswith("cuda") else ""
    execution = protocol["execution"]
    if args.device.startswith("cuda"):
        import torch
        if (torch.__version__ != execution["torch_version"]
                or os.environ.get("CUDA_MODULE_LOADING") != execution["cuda_module_loading"]):
            raise AssertionError("Frozen low-memory CUDA runtime mismatch")
    common = [sys.executable, str(source), "--seed", "0", "--device", args.device,
              "--expected-gpu", expected_gpu,
              "--num-workers", str(execution["num_workers"]),
              "--cpu-threads", str(execution["cpu_threads"])]

    def run(command, profile, destination, extra=()):
        verify(root)
        subprocess.run([*common, command, "--profile", profile,
                        "--output", str(destination), *extra], check=True)

    if args.stage == "smoke":
        for arm in ARMS:
            run("train", "smoke", root / "smoke/seed0" / arm, ("--arm", arm))
        run("sweep", "smoke", root / "smoke/sweep",
            ("--checkpoint", protocol["checkpoint"]))
        audit = audit_seed(root / "smoke/seed0", ARMS)
        write_json(root / "smoke_passed.json", {
            "pairing_passed": audit["pairing_passed"], "gpu": audit["gpu"],
            "source_sha256": protocol["source_sha256"],
            "profile": "smoke", "device": args.device,
        })
    else:
        gate = read_json(root / "smoke_passed.json")
        if (not gate["pairing_passed"]
                or gate["source_sha256"] != protocol["source_sha256"]
                or protocol["expected_gpu"] not in gate["gpu"]):
            raise AssertionError("Production requires a matching GPU smoke/audit gate")
        if args.stage == "sweep":
            run("sweep", "pilot", root / "sweep/seed0",
                ("--checkpoint", protocol["checkpoint"]))
        elif args.stage == "train":
            sweep = read_json(root / "sweep/seed0/summary.json")
            if (not sweep["complete"]
                    or sweep["checkpoint_sha256"] != protocol["checkpoint_sha256"]):
                raise AssertionError("Read-only RTG diagnostic must finish first")
            if args.arm not in PILOT_ARMS:
                raise ValueError("Only the three pilot arms may run in this campaign")
            run("train", "pilot", root / "pilot/seed0" / args.arm, ("--arm", args.arm))
            summarize(root, if_ready=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("init", "verify", "worker", "summarize"))
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--stage", choices=("smoke", "sweep", "train"))
    parser.add_argument("--arm", choices=ARMS, default="dt")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--if-ready", action="store_true")
    parser.add_argument("--expected-gpu", default="RTX 3090")
    parser.add_argument("--num-workers", type=int, default=0)
    args = parser.parse_args()
    if args.command == "init":
        initialize(args.root.resolve(), args.expected_gpu, args.num_workers)
    elif args.command == "verify":
        verify(args.root.resolve())
        print("Frozen sources and original checkpoint verified.")
    elif args.command == "summarize":
        summarize(args.root.resolve(), args.if_ready)
    else:
        if not args.stage:
            parser.error("worker requires --stage")
        worker(args)


if __name__ == "__main__":
    main()
