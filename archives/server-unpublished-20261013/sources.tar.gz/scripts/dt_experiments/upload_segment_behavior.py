"""Publish completed CPU segment analysis to the existing research W&B project."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def read(path):
    return json.loads(path.read_text())


def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args()
    root=args.root.resolve()
    protocol,summary=read(root/'protocol.json'),read(root/'summary.json')
    for manifest in ['analysis_manifest.json','figure_manifest.json']:
        for name,h in read(root/manifest).items():
            assert digest(root/name)==h,name
    for name,h in protocol['source_sha256'].items():
        assert digest(root/'source'/name)==h,name
    entity,project=protocol['wandb_entity'],protocol['wandb_project']
    runid=hashlib.sha256(digest(root/'protocol.json').encode()).hexdigest()[:16]
    import wandb
    api=wandb.Api(timeout=45)
    assert api.default_entity==entity
    api.project(project,entity=entity)
    dest=root/'wandb_upload'
    dest.mkdir(exist_ok=True)
    if (dest/'verification.json').exists():
        remote=api.run(f'{entity}/{project}/{runid}')
        if remote.summary.get('analysis/complete'):
            print('Already verified: '+remote.url)
            return
    run=wandb.init(entity=entity,project=project,group=protocol['wandb_group'],id=runid,
        resume='allow',name='continuous-segments-20-and-50-steps',mode='online',dir=str(dest),
        config=protocol,job_type='offline-dataset-analysis',tags=['segment-analysis','delayed-reward','no-training'],
        settings=wandb.Settings(_disable_stats=True,_disable_meta=True,disable_code=True,
                               disable_git=True,console='off',start_method='thread'))
    try:
        table=wandb.Table(columns=['split','horizon','comparison','feature','high_n','other_n','high_mean','other_mean',
                                   'difference','ci95_low','ci95_high','simultaneous_low','simultaneous_high'])
        for split in ['discovery','validation']:
            for h in ['20','50']:
                for comparison in ['all_windows','matched_windows_raw','matched_residual']:
                    stats=summary[split][h][comparison]
                    for feature,v in stats['features'].items():
                        table.add_data(split,int(h),comparison,feature,stats['high_trajectories'],stats['other_trajectories'],
                                       v['high_mean'],v['other_mean'],v['difference'],*v['ci95'],*v['simultaneous_ci95'])
        run.log({'tables/feature_comparisons':table,**{'figures/'+p.stem:wandb.Image(str(p)) for p in (root/'figures').glob('*.png')}})
        artifact=wandb.Artifact('segment-behavior-'+runid,type='dataset-analysis')
        for file in sorted(root.rglob('*')):
            if file.is_file() and 'wandb_upload' not in file.parts and '__pycache__' not in file.parts:
                artifact.add_file(str(file),name=str(file.relative_to(root)))
        run.log_artifact(artifact)
        values={'analysis/complete':True,'analysis/no_training':True,'analysis/exploratory':True,
                'result/discovery_pattern_count':len(summary['findings']['discovery_patterns']),
                'result/replicated_h20_count':len(summary['findings']['replicated_h20']),
                'result/stable_h50_count':len(summary['findings']['same_direction_h50_pointwise95']),
                'result/replicated_patterns':summary['findings']['replicated_h20'],
                'result/stable_patterns':summary['findings']['same_direction_h50_pointwise95']}
        for h in ['20','50']:
            s=summary['validation'][h]
            values[f'coverage/h{h}_high_trajectories']=s['high_coverage']['matched_trajectories']
            values[f'coverage/h{h}_other_trajectories']=s['other_coverage']['matched_trajectories']
            for feature in ['speed_mean','speed_gain','action_change_rms']:
                if feature in s['matched_residual']['features']:
                    values[f'validation/h{h}_{feature}_residual_difference']=s['matched_residual']['features'][feature]['difference']
        run.summary.update(values)
        url=run.url
        run.finish(exit_code=0)
    except BaseException:
        run.finish(exit_code=1)
        raise
    remote=wandb.Api(timeout=45).run(f'{entity}/{project}/{runid}')
    for key,value in values.items():
        actual=remote.summary.get(key)
        if isinstance(value,float):
            np.testing.assert_allclose(actual,value,rtol=0,atol=1e-8)
        else:
            assert actual==value,(key,actual,value)
    verification=dict(id=runid,url=url,group=protocol['wandb_group'],complete=True,
                      remote_summary_verified=True,summary=values)
    (dest/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    print(json.dumps(verification),flush=True)


if __name__=='__main__':
    main()
