"""One-shot login-node completion: optional bounded Slurm wait, plots and W&B.

The compute job never needs network credentials/proxy access. A stopped compute
job with complete offline and rollout audits can be summarized safely on CPU.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np


def read(path):return json.loads(path.read_text())


def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def wait_for_job(root,job,seconds):
    started=time.monotonic();previous=None
    while time.monotonic()-started<seconds:
        result=subprocess.run(['sacct','-n','-X','-j',job,'--format=State,ExitCode','-P'],
                              check=True,capture_output=True,text=True)
        lines=[line.strip() for line in result.stdout.splitlines() if line.strip()]
        state=lines[0].split('|')[0] if lines else 'NOT_YET_IN_ACCOUNTING'
        stage='rollout_complete' if (root/'rollout/audit.json').exists() else (
              'offline_complete' if (root/'offline/audit.json').exists() else 'awaiting_offline')
        current=(state,stage)
        if current!=previous:
            print(json.dumps(dict(job=job,state=state,stage=stage)),flush=True);previous=current
        if any(state.startswith(v) for v in ['COMPLETED','FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY','NODE_FAIL','BOOT_FAIL','PREEMPTED']):
            if not (root/'offline/audit.json').exists() or not (root/'rollout/audit.json').exists():
                raise RuntimeError(f'Job {job} ended {state} without completed data; inspect compute log')
            (root/'completion_job.json').write_text(json.dumps(dict(job=job,state=state,
                accounting_lines=lines,wait_seconds=time.monotonic()-started),indent=2)+'\n')
            return
        time.sleep(30)
    raise TimeoutError('Bounded completion wait expired; no extra jobs were submitted')


def upload(root):
    protocol,summary=read(root/'protocol.json'),read(root/'summary.json')
    for manifest in ['result_manifest.json','presentation_manifest.json']:
        for name,h in read(root/manifest).items():assert digest(root/name)==h,name
    for name,h in protocol['source_sha256'].items():assert digest(root/'source'/name)==h,name
    import wandb
    entity,project=protocol['wandb_entity'],protocol['wandb_project']
    api=wandb.Api(timeout=45);assert api.default_entity==entity
    api.project(project,entity=entity)
    runid=hashlib.sha256(digest(root/'protocol.json').encode()).hexdigest()[:16]
    dest=root/'wandb_upload';dest.mkdir(exist_ok=True)
    if (dest/'verification.json').exists():
        remote=api.run(f'{entity}/{project}/{runid}')
        if remote.summary.get('diagnostic/complete'):
            print('Already verified: '+remote.url,flush=True);return
    run=wandb.init(entity=entity,project=project,group=protocol['wandb_group'],id=runid,
        resume='allow',mode='online',dir=str(dest),name='DT-action-pattern-reproduction-seed0-50k',
        config=protocol,job_type='frozen-policy-diagnostic',tags=['action-patterns','no-training','delayed-reward'],
        settings=wandb.Settings(_disable_stats=True,_disable_meta=True,disable_code=True,
                               disable_git=True,console='off',start_method='thread'))
    try:
        table=wandb.Table(columns=['condition','horizon','group','metric','mean','units','simultaneous_low','simultaneous_high'])
        for condition in ['actual_return','rtg12000','rollout']:
            for h in ['20','50']:
                groups={'matched':summary['rollout'][h]} if condition=='rollout' else summary['offline'][condition][h]
                for group,stats in groups.items():
                    for metric,v in stats['primary'].items():
                        table.add_data(condition,int(h),group,metric,v['mean'],v['units'],*(v['simultaneous_ci95'] or [None,None]))
        episodes=wandb.Table(columns=['episode','episode_seed','length','raw_return','normalized_score'])
        for e in summary['episodes']:episodes.add_data(*(e[k] for k in episodes.columns))
        run.log({'tables/comparisons':table,'tables/episodes':episodes,
                 **{'figures/'+f.stem:wandb.Image(str(f)) for f in (root/'figures').glob('*.png')}})
        artifact=wandb.Artifact('dt-action-patterns-'+runid,type='diagnostic-results')
        for file in sorted(root.rglob('*')):
            if file.is_file() and 'wandb_upload' not in file.parts and '__pycache__' not in file.parts:
                artifact.add_file(str(file),name=str(file.relative_to(root)))
        run.log_artifact(artifact)
        values={'diagnostic/complete':True,'diagnostic/no_training':True,'audit/passed':True,
                'rollout/episodes':20,'rollout/mean_score':float(np.mean([e['normalized_score'] for e in summary['episodes']]))}
        for h in ['20','50']:
            for condition in ['actual_return','rtg12000','rollout']:
                stats=summary['rollout'][h] if condition=='rollout' else summary['offline'][condition][h]['validation_high']
                for metric,v in stats['primary'].items():
                    values[f'{condition}/h{h}_{metric}']=v['mean']
                    values[f'{condition}/h{h}_{metric}_ci95']=v['simultaneous_ci95']
                for flag in ['change_compressed','negative_correlation_weakened']:
                    values[f'{condition}/h{h}_{flag}']=stats[flag]
            values[f'rollout/h{h}_supported_windows']=summary['rollout'][h]['supported_windows']
            values[f'rollout/h{h}_supported_episodes']=summary['rollout'][h]['supported_episodes']
        for key,value in summary['interpretation'].items():values['interpretation/'+key]=value
        run.summary.update(values);url=run.url
        run.finish(exit_code=0)
    except BaseException:
        run.finish(exit_code=1);raise
    remote=wandb.Api(timeout=45).run(f'{entity}/{project}/{runid}')
    for key,value in values.items():
        actual=remote.summary.get(key)
        if isinstance(value,(float,list)):np.testing.assert_allclose(actual,value,rtol=0,atol=1e-8)
        else:assert actual==value,(key,actual,value)
    assert remote.summary['tables/episodes']['nrows']==20
    assert remote.summary['tables/comparisons']['nrows']==76
    verification=dict(id=runid,url=url,complete=True,remote_summary_verified=True,
        episode_table_rows=20,comparison_table_rows=76,summary=values)
    (dest/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    print(json.dumps(verification),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--wait-job')
    parser.add_argument('--max-wait-seconds',type=int,default=14400)
    parser.add_argument('--no-upload',action='store_true')
    args=parser.parse_args();root=args.root.resolve()
    if args.wait_job:wait_for_job(root,args.wait_job,args.max_wait_seconds)
    env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',
             MPLCONFIGDIR='/tmp/dt-action-patterns-matplotlib')
    if not (root/'summary.json').exists():
        subprocess.run([sys.executable,str(root/'source/algorithms/offline/diagnose_dt_action_patterns.py'),
                        'summarize','--output',str(root)],check=True,env=env)
    subprocess.run(['/usr/bin/python3',str(root/'source/scripts/dt_experiments/plot_dt_action_patterns.py'),
                    '--root',str(root)],check=True,env=env)
    if not args.no_upload:upload(root)


if __name__=='__main__':main()
