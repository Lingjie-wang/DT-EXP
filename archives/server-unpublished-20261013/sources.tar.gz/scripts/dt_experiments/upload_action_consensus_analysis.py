"""Publish completed offline analysis while the simulator job is queued.

Uses the same deterministic W&B run id as the frozen final-result uploader.
Does not change frozen selection inputs or claim branch completion.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--job-id',required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    spec = importlib.util.spec_from_file_location('frozen_consensus',
        root/'source/algorithms/offline/action_consensus_diagnostic.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    protocol = module.verify(root)
    analysis = module.read(root/'analysis.json')
    entity, project = protocol['wandb_entity'],protocol['wandb_project']
    runid = hashlib.sha256(module.file_hash(root/'protocol.json').encode()).hexdigest()[:16]
    dest = root/'wandb_upload'
    dest.mkdir(exist_ok=True)
    import wandb
    api = wandb.Api(timeout=45)
    if api.default_entity != entity:
        raise AssertionError('Unexpected W&B account')
    api.project(project,entity=entity)
    # Refuse to overwrite a completed final run with preliminary status.
    try:
        remote = api.run(f'{entity}/{project}/{runid}')
    except wandb.errors.CommError:
        remote = None
    if remote is not None and remote.summary.get('diagnostic/complete'):
        print('Final results already uploaded: '+remote.url)
        return
    run = wandb.init(entity=entity,project=project,group=protocol['wandb_group'],
        id=runid,resume='allow',dir=str(dest),mode='online',
        name='action-consensus-frozen-DT-seed0-50k',job_type='feasibility-diagnostic',
        config=protocol,tags=['action-consensus','delayed-reward','no-training'],
        settings=wandb.Settings(_disable_stats=True,_disable_meta=True,disable_code=True,
                               disable_git=True,console='off',start_method='thread'))
    try:
        table = wandb.Table(columns=['subset','queries','trajectories','state_brier',
                                    'state_action_brier','improvement','ci95_low','ci95_high'])
        for key, values in analysis['validation'].items():
            v=values['improvement']
            table.add_data(key,values['queries'],v['units'],values['state_brier'],
                           values['action_brier'],v['mean'],*v['ci95'])
        run.log({'tables/offline_validation':table})
        artifact = wandb.Artifact('action-consensus-'+runid+'-offline',type='diagnostic-offline-analysis')
        for name in ['protocol.json','preprocessing.json','analysis.json','analysis_manifest.json',
                     'queries.jsonl','candidates.jsonl','neighbors.npz','implementation_validation.json',
                     'submission.json','offline_report_zh.md']:
            artifact.add_file(str(root/name),name=name)
        for file in sorted((root/'source').rglob('*')):
            if file.is_file() and '__pycache__' not in file.parts:
                artifact.add_file(str(file),name=str(file.relative_to(root)))
        run.log_artifact(artifact)
        primary=analysis['validation']['all_supported']
        summary={'diagnostic/complete':False,'offline/complete':True,
                 'offline/discovery_candidates':analysis['counts']['discovery'].get('candidate',0),
                 'offline/validation_candidates':analysis['counts']['validation'].get('candidate',0),
                 'offline/state_brier':primary['state_brier'],
                 'offline/state_action_brier':primary['action_brier'],
                 'offline/brier_improvement':primary['improvement']['mean'],
                 'offline/brier_improvement_ci95':primary['improvement']['ci95'],
                 'slurm/job_id':args.job_id}
        run.summary.update(summary)
        url=run.url
        run.finish(exit_code=0)
    except BaseException:
        run.finish(exit_code=1)
        raise
    remote=wandb.Api(timeout=45).run(f'{entity}/{project}/{runid}')
    for key,value in summary.items():
        actual=remote.summary.get(key)
        if isinstance(value,float):
            assert abs(actual-value)<1e-8,(key,actual,value)
        else:
            assert actual==value,(key,actual,value)
    module.write(dest/'offline_verification.json',dict(id=runid,url=url,
        remote_summary_verified=True,diagnostic_complete=False,summary=summary))
    print(json.dumps(dict(url=url,verified=True,stage='offline_analysis')),flush=True)


if __name__=='__main__':
    main()
