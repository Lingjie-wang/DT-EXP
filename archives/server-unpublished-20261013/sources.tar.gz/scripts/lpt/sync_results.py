"""One-shot results-only W&B bridge for one authorized LPT job.

No job submission, code capture, directory artifacts, datasets or checkpoints.
"""
import argparse
import fcntl
import hashlib
import json
import math
from pathlib import Path
import subprocess
import time

import wandb


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def rows(path):
    if not path.exists():
        return []
    raw = path.read_text()
    lines = raw.splitlines()
    if raw and not raw.endswith('\n'):
        lines = lines[:-1]
    return [json.loads(line) for line in lines if line.strip()]


def slurm(job):
    result = subprocess.run(['squeue', '-h', '-j', job, '-o', '%T'], text=True, capture_output=True)
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip().splitlines()[0]
    result = subprocess.run(['sacct', '-n', '-P', '-j', job, '--format=JobIDRaw,State'], text=True, capture_output=True)
    for line in result.stdout.splitlines():
        fields = line.split('|')
        if fields[0] == job:
            return fields[1]
    return 'UNKNOWN'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--arm', choices=['dense', 'delayed'], required=True)
    parser.add_argument('--job', required=True)
    args = parser.parse_args()
    p = read(args.root / 'protocol.json')
    directory = args.root / 'wandb_sync' / args.arm
    directory.mkdir(parents=True, exist_ok=True)
    lock = open(directory / 'lock', 'w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    allowed = ['method', 'recipe', 'env_name', 'eval_env', 'seed', 'trajectories', 'max_len',
               'window_size', 'hidden_size', 'n_layer', 'n_head', 'n_latent', 'langevin_step_size',
               'train_langevin_steps', 'eval_langevin_steps', 'target_return', 'scale', 'reward_weight',
               'omega_cg', 'gamma', 'learning_rate', 'weight_decay', 'grad_clip', 'warmup_ratio',
               'epochs', 'nominal_batch_size', 'effective_batch_size', 'microbatch_size', 'total_updates',
               'attention_backend', 'eval_updates', 'eval_episodes', 'final_episodes', 'eval_seed_start',
               'final_seed_start', 'eval_model_seed_start']
    config = {key: p[key] for key in allowed}
    config.update(reward_mode=args.arm, upstream_commit=p['upstream_commit'],
                  reward_timing_invariant_by_design=True)
    identity = hashlib.sha256((p['wandb_group'] + args.arm).encode()).hexdigest()[:12]
    run = wandb.init(entity=p['wandb_entity'], project=p['wandb_project'], group=p['wandb_group'],
                     id=identity, name=f'LPT-HCMR-{args.arm}-seed0-2000epochs',
                     resume='allow', mode='online', dir=str(directory), config=config,
                     settings=wandb.Settings(_disable_stats=True, _disable_meta=True, disable_code=True,
                         disable_git=True, console='off', start_method='thread'))
    run.define_metric('completed_updates')
    for prefix in ['train/*', 'eval/*']:
        run.define_metric(prefix, step_metric='completed_updates')
    marker = directory / 'cursor.json'
    cursor = read(marker) if marker.exists() else dict(completed_updates=0, evaluated=[])
    work = args.root / args.arm
    run.summary.update(dict(status='queued', completed_updates=cursor['completed_updates'], slurm_job_id=args.job,
                       interpretation='Official LPT with audited repairs; total-return-only; dense and delayed inputs are equivalent; seed 0'))
    write(directory / 'manifest.json', dict(url=run.url, run_id=identity, job_id=args.job))
    # A bounded startup readback verifies identity/config/summary before waiting.
    for attempt in range(6):
        time.sleep(5)
        remote = wandb.Api(timeout=45).run(f"{p['wandb_entity']}/{p['wandb_project']}/{identity}")
        if remote.config.get('reward_mode') == args.arm and remote.summary.get('status') == 'queued':
            write(directory / 'startup_verification.json', dict(verified=True, url=run.url,
                  reward_mode=remote.config['reward_mode'], total_updates=remote.config['total_updates']))
            break
    else:
        raise RuntimeError('W&B startup readback failed')
    print(json.dumps(read(directory / 'startup_verification.json')), flush=True)
    previous_status = None
    try:
        for _ in range(21 * 24 * 60):
            history = rows(work / 'metrics.jsonl')
            for row in history:
                if row['completed_updates'] <= cursor['completed_updates']:
                    continue
                run.log({'completed_updates': row['completed_updates'], 'train/loss': row['loss'],
                         'train/gradient_norm': row['gradient_norm'], 'train/learning_rate': row['learning_rate'],
                         'train/elapsed_seconds': row['elapsed_seconds'], 'train/update_seconds': row['update_seconds'],
                         'train/cuda_peak_mib': row['cuda_peak_mib']})
                cursor['completed_updates'] = row['completed_updates']
            evaluations = [read(path) for path in sorted(work.glob('eval_*.json'))]
            for value in evaluations:
                step = value['completed_updates']
                if step in cursor['evaluated']:
                    continue
                run.log({'completed_updates': step, 'eval/normalized_score_mean': value['mean_score'],
                         'eval/normalized_score_std': value['std_score'], 'eval/episodes': len(value['episodes']),
                         'eval/target_return': value['target_return']})
                table = wandb.Table(columns=['episode_seed', 'raw_return', 'normalized_score', 'length'])
                for episode in value['episodes']:
                    table.add_data(*[episode[key] for key in table.columns])
                run.log({f'tables/episodes_{step}': table})
                artifact = wandb.Artifact(f'lpt-{args.arm}-{identity}-{step}', type='evaluation-results')
                # Only this numeric episode-result file is permitted.
                artifact.add_file(str(work / f'eval_{step:06d}.json'), name='evaluation.json')
                run.log_artifact(artifact)
                cursor['evaluated'].append(step)
            write(marker, cursor)
            state = slurm(args.job)
            local = read(work / 'status.json') if (work / 'status.json').exists() else {}
            status = local.get('status', 'starting' if state == 'RUNNING' else 'queued')
            failed = any(state.startswith(x) for x in ['FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY', 'NODE_FAIL', 'PREEMPTED', 'BOOT_FAIL'])
            if failed and status != 'completed':
                status = 'job_failed'
            run.summary.update(dict(status=status, completed_updates=cursor['completed_updates'], slurm_state=state))
            write(directory / 'status.json', dict(status=status, slurm_state=state,
                  completed_updates=cursor['completed_updates'], evaluation_points=len(evaluations), updated_unix=time.time()))
            if status != previous_status:
                print(json.dumps(read(directory / 'status.json')), flush=True)
                previous_status = status
            if status == 'completed':
                assert cursor['completed_updates'] == p['total_updates']
                assert sorted(cursor['evaluated']) == p['eval_updates']
                run.summary['result/final_normalized_score'] = evaluations[-1]['mean_score']
                url = run.url
                run.finish()
                remote = wandb.Api(timeout=45).run(f"{p['wandb_entity']}/{p['wandb_project']}/{identity}")
                assert math.isclose(remote.summary['result/final_normalized_score'], evaluations[-1]['mean_score'], abs_tol=1e-8)
                for step in p['eval_updates']:
                    assert remote.summary[f'tables/episodes_{step}']['nrows'] == (p['final_episodes'] if step == p['total_updates'] else p['eval_episodes'])
                records = list(remote.scan_history(keys=['completed_updates', 'eval/normalized_score_mean']))
                mapped = {r['completed_updates']: r['eval/normalized_score_mean'] for r in records}
                for value in evaluations:
                    assert math.isclose(mapped[value['completed_updates']], value['mean_score'], abs_tol=1e-8)
                write(directory / 'completion_verification.json', dict(verified=True, url=url,
                      completed_updates=cursor['completed_updates'], evaluation_points=len(evaluations)))
                return
            if failed or state.startswith('COMPLETED'):
                raise RuntimeError(f'Job ended {state} without complete result')
            time.sleep(60)
        raise TimeoutError('One-shot bridge window expired; no training was modified')
    except BaseException as error:
        write(directory / 'error.json', dict(error=repr(error)))
        run.finish(exit_code=1)
        raise


if __name__ == '__main__':
    main()
